<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-09-18 10:14:59 --> 404 Page Not Found --> 
ERROR - 2013-09-18 10:14:59 --> 404 Page Not Found --> 
ERROR - 2013-09-18 13:02:47 --> Query error: Unknown column 'amount_of_charge_allowance' in 'field list' - Invalid query: INSERT INTO `pmm_earnings_deduction` (`organization_id`, `salary_head_id`, `employee_id`, `remarks`, `start_date`, `end_date`, `amount_of_charge_allowance`, `created_at`, `created_by`) VALUES (1, '17', '', '', '2013-09-05', '2013-09-19', '212', '2013-09-18 13:02:47', '2')
ERROR - 2013-09-18 16:49:10 --> 404 Page Not Found --> Employeemonthly/destroy
ERROR - 2013-09-18 18:32:48 --> Could not find the language line "form_validation_date_compare"
ERROR - 2013-09-18 18:32:48 --> Could not find the language line "form_validation_date_compare"
ERROR - 2013-09-18 18:32:57 --> Could not find the language line "form_validation_date_compare"
ERROR - 2013-09-18 18:32:57 --> Could not find the language line "form_validation_date_compare"
ERROR - 2013-09-18 18:33:20 --> Could not find the language line "form_validation_date_compare"
ERROR - 2013-09-18 18:33:20 --> Could not find the language line "form_validation_date_compare"
ERROR - 2013-09-18 18:33:40 --> Could not find the language line "form_validation_date_compare"
ERROR - 2013-09-18 18:33:40 --> Could not find the language line "form_validation_date_compare"
ERROR - 2013-09-18 18:34:07 --> Could not find the language line "form_validation_date_compare"
ERROR - 2013-09-18 18:34:07 --> Could not find the language line "form_validation_date_compare"
