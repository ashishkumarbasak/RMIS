<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-09-26 09:58:33 --> 404 Page Not Found --> 
ERROR - 2013-09-26 09:58:33 --> 404 Page Not Found --> 
ERROR - 2013-09-26 09:58:36 --> 404 Page Not Found --> 
ERROR - 2013-09-26 11:01:00 --> 404 Page Not Found --> 
ERROR - 2013-09-26 11:01:00 --> 404 Page Not Found --> 
ERROR - 2013-09-26 11:01:02 --> 404 Page Not Found --> 
ERROR - 2013-09-26 11:54:38 --> 404 Page Not Found --> 
ERROR - 2013-09-26 11:54:43 --> 404 Page Not Found --> 
ERROR - 2013-09-26 11:54:50 --> 404 Page Not Found --> 
ERROR - 2013-09-26 11:55:00 --> 404 Page Not Found --> 
ERROR - 2013-09-26 11:55:18 --> 404 Page Not Found --> 
ERROR - 2013-09-26 11:55:30 --> 404 Page Not Found --> 
ERROR - 2013-09-26 17:26:00 --> Severity: 4096  --> Object of class CI_DB_pdo_result could not be converted to string D:\Zend\Apache2\htdocs\natp_barc\application\libraries\MY_Form_validation.php 175
ERROR - 2013-09-26 17:26:00 --> Severity: 4096  --> Object of class CI_DB_pdo_result could not be converted to string D:\Zend\Apache2\htdocs\natp_barc\application\libraries\MY_Form_validation.php 175
ERROR - 2013-09-26 17:36:51 --> Severity: 4096  --> Object of class stdClass could not be converted to string D:\Zend\Apache2\htdocs\natp_barc\application\libraries\MY_Form_validation.php 180
ERROR - 2013-09-26 17:36:51 --> Severity: 4096  --> Object of class stdClass could not be converted to string D:\Zend\Apache2\htdocs\natp_barc\application\libraries\MY_Form_validation.php 180
