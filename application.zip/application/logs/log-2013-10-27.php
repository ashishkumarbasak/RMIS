<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-10-27 10:26:59 --> 404 Page Not Found --> 
ERROR - 2013-10-27 10:26:59 --> 404 Page Not Found --> 
ERROR - 2013-10-27 12:01:27 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-27 12:01:27 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-27 12:01:27 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-27 12:01:27 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-27 12:01:27 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-27 12:01:27 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-27 12:01:27 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-27 12:01:27 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-27 12:01:27 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-27 17:44:07 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\report\vehicle_info.php 52
ERROR - 2013-10-27 17:44:07 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\report\vehicle_info.php 94
ERROR - 2013-10-27 17:44:07 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\report\vehicle_info.php 121
ERROR - 2013-10-27 17:44:12 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\report\vehicle_info.php 52
ERROR - 2013-10-27 17:44:12 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\report\vehicle_info.php 94
ERROR - 2013-10-27 17:44:12 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\report\vehicle_info.php 121
ERROR - 2013-10-27 17:44:18 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\report\vehicle_info.php 52
ERROR - 2013-10-27 17:44:18 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\report\vehicle_info.php 94
ERROR - 2013-10-27 17:44:18 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\report\vehicle_info.php 121
ERROR - 2013-10-27 17:47:29 --> Severity: Warning  --> require_once(http://localhost:8088/JavaBridge/java/Java.inc): failed to open stream: No connection could be made because the target machine actively refused it.
 D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Rptpayslip.php 49
ERROR - 2013-10-27 17:47:50 --> 404 Page Not Found --> Pmm/nullimg_0_0_0
ERROR - 2013-10-27 17:47:50 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-27 17:50:31 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\report\vehicle_info.php 35
ERROR - 2013-10-27 17:50:31 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\report\vehicle_info.php 69
ERROR - 2013-10-27 17:50:31 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\report\vehicle_info.php 112
ERROR - 2013-10-27 17:50:31 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\report\vehicle_info.php 128
ERROR - 2013-10-27 18:29:22 --> 404 Page Not Found --> Pmm/Rptvehicle
ERROR - 2013-10-27 18:32:47 --> 404 Page Not Found --> Vmis/nullpx
ERROR - 2013-10-27 18:32:47 --> 404 Page Not Found --> Vmis/nullimg_0_0_0
ERROR - 2013-10-27 18:40:13 --> 404 Page Not Found --> Vmis/Rptmaintence
