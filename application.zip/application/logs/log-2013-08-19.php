<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-08-19 09:49:21 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-19 09:49:21 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-19 09:49:28 --> 404 Page Not Found --> 
ERROR - 2013-08-19 09:49:28 --> 404 Page Not Found --> 
ERROR - 2013-08-19 10:46:06 --> Severity: Warning  --> Missing argument 1 for Kendo\UI\GridColumnCommandItem::click(), called in D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Role.php on line 110 and defined D:\Zend\Apache2\htdocs\natp_barc\application\third_party\kendoui\UI\GridColumnCommandItem.php 42
ERROR - 2013-08-19 10:55:47 --> Severity: Warning  --> Missing argument 1 for Kendo\UI\GridColumnCommandItem::click(), called in D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Role.php on line 108 and defined D:\Zend\Apache2\htdocs\natp_barc\application\third_party\kendoui\UI\GridColumnCommandItem.php 42
ERROR - 2013-08-19 10:56:42 --> 404 Page Not Found --> User/permission
ERROR - 2013-08-19 10:56:54 --> 404 Page Not Found --> User/permission
ERROR - 2013-08-19 10:57:13 --> 404 Page Not Found --> User/permission
ERROR - 2013-08-19 10:57:34 --> 404 Page Not Found --> User/permission
ERROR - 2013-08-19 13:27:33 --> Query error: Table 'natp_barc.rolemodels' doesn't exist - Invalid query: SELECT *
FROM `rolemodels`
ERROR - 2013-08-19 13:55:50 --> Severity: Warning  --> Missing argument 1 for Role::getAllPermissionOptions() D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Role.php 228
ERROR - 2013-08-19 15:15:52 --> Severity: Warning  --> Missing argument 1 for Role::getAllPermissionOptions() D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Role.php 228
ERROR - 2013-08-19 15:16:44 --> Severity: Warning  --> Missing argument 1 for Role::getAllPermissionOptions() D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Role.php 228
ERROR - 2013-08-19 15:17:33 --> Severity: Warning  --> Missing argument 1 for Role::getAllPermissionOptions() D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Role.php 228
ERROR - 2013-08-19 15:39:05 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `permissions` (`description`, `module`, `premission`, `section`, `weight`) VALUES ('Human Resource Management Information System','HRMIS',Array,'Employee1','3'), ('Human Resource Management Information System','HRMIS','sasas','Employee1','3')
ERROR - 2013-08-19 17:59:29 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Role.php 227
