<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-12-07 10:48:03 --> 404 Page Not Found --> FundSources/1
ERROR - 2013-12-07 10:48:29 --> 404 Page Not Found --> 
ERROR - 2013-12-07 10:48:29 --> 404 Page Not Found --> 
ERROR - 2013-12-07 10:48:29 --> 404 Page Not Found --> 
ERROR - 2013-12-07 10:48:30 --> 404 Page Not Found --> 
ERROR - 2013-12-07 10:48:35 --> 404 Page Not Found --> 
ERROR - 2013-12-07 10:48:36 --> 404 Page Not Found --> 
ERROR - 2013-12-07 10:48:36 --> 404 Page Not Found --> 
ERROR - 2013-12-07 10:48:36 --> 404 Page Not Found --> 
ERROR - 2013-12-07 10:48:36 --> 404 Page Not Found --> 
ERROR - 2013-12-07 10:48:36 --> 404 Page Not Found --> 
ERROR - 2013-12-07 10:48:36 --> 404 Page Not Found --> 
ERROR - 2013-12-07 10:48:36 --> 404 Page Not Found --> 
ERROR - 2013-12-07 10:48:41 --> 404 Page Not Found --> 
ERROR - 2013-12-07 10:48:42 --> 404 Page Not Found --> 
ERROR - 2013-12-07 10:48:42 --> 404 Page Not Found --> 
ERROR - 2013-12-07 10:48:42 --> 404 Page Not Found --> 
ERROR - 2013-12-07 10:48:49 --> 404 Page Not Found --> 
ERROR - 2013-12-07 10:48:49 --> 404 Page Not Found --> 
ERROR - 2013-12-07 10:49:21 --> 404 Page Not Found --> 
ERROR - 2013-12-07 10:49:21 --> 404 Page Not Found --> 
ERROR - 2013-12-07 10:49:22 --> 404 Page Not Found --> 
ERROR - 2013-12-07 10:49:22 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:12:39 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:12:39 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:12:39 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:12:39 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:12:41 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:12:41 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:12:42 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:12:42 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:13:54 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:13:54 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:13:58 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:13:58 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:13:59 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:13:59 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:14:03 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:14:03 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:14:03 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:14:04 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:14:11 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:14:11 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:14:12 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:14:12 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:14:18 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:14:18 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:14:19 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:14:19 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:14:22 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:14:22 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:14:22 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:14:22 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:14:25 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:14:25 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:14:25 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:14:25 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:14:28 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:14:28 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:14:28 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:14:28 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:14:32 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:14:32 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:14:32 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:14:32 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:14:35 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:14:35 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:14:35 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:14:35 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:15:56 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:15:56 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:15:56 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:15:56 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:16:02 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:16:03 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:16:03 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:16:03 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:16:07 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:16:07 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:16:07 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:16:07 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:16:19 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:16:19 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:16:19 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:16:19 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:16:56 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:16:56 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:16:56 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:16:56 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:33:57 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:33:57 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:33:58 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:33:58 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:35:05 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:35:05 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:35:06 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:35:06 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:35:47 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:35:47 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:35:47 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:35:48 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:37:16 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:37:16 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:37:16 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:37:16 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:37:34 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:37:34 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:37:35 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:37:35 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:38:34 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:38:34 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:38:35 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:38:35 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:38:56 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:38:56 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:38:56 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:38:56 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:39:06 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:39:06 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:39:07 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:39:07 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:39:46 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:39:46 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:39:46 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:39:47 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:39:58 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:39:58 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:39:58 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:39:58 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:40:26 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:40:26 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:40:26 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:40:26 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:47:49 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:47:49 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:47:49 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:47:49 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:48:36 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:48:36 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:48:37 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:48:37 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:49:21 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:49:21 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:49:21 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:49:21 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:51:10 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:51:10 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:51:11 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:51:11 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:52:13 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:52:13 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:52:13 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:52:13 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:54:54 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:54:54 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:54:54 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:54:54 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:55:46 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:55:46 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:55:47 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:55:47 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:56:21 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:56:21 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:56:21 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:56:21 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:56:25 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:57:20 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:57:20 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:57:21 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:57:21 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:57:31 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:58:28 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:58:32 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:58:32 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:58:32 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:58:32 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:58:37 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:58:59 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:59:35 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:59:35 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:59:36 --> 404 Page Not Found --> 
ERROR - 2013-12-07 11:59:36 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:00:06 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:00:06 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:00:07 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:00:07 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:01:13 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:01:13 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:01:14 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:01:14 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:22:23 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:22:23 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:22:23 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:22:23 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:22:53 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:22:53 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:22:54 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:22:54 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:25:24 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:25:24 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:25:25 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:25:25 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:26:21 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:26:21 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:26:22 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:26:22 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:28:06 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:28:06 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:28:07 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:28:07 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:28:23 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:28:23 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:28:24 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:28:24 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:29:03 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:29:03 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:29:04 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:29:04 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:30:09 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:30:10 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:30:10 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:30:10 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:32:20 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:37:14 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:37:14 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:37:14 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:37:14 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:42:40 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:42:40 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:42:40 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:42:40 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:44:37 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:44:37 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:44:37 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:44:37 --> 404 Page Not Found --> 
ERROR - 2013-12-07 12:44:43 --> 404 Page Not Found --> 
ERROR - 2013-12-07 13:32:21 --> 404 Page Not Found --> 
ERROR - 2013-12-07 13:32:21 --> 404 Page Not Found --> 
ERROR - 2013-12-07 13:32:22 --> 404 Page Not Found --> 
ERROR - 2013-12-07 13:32:22 --> 404 Page Not Found --> 
ERROR - 2013-12-07 13:37:04 --> 404 Page Not Found --> 
ERROR - 2013-12-07 13:37:04 --> 404 Page Not Found --> 
ERROR - 2013-12-07 13:37:04 --> 404 Page Not Found --> 
ERROR - 2013-12-07 13:37:04 --> 404 Page Not Found --> 
ERROR - 2013-12-07 13:37:08 --> 404 Page Not Found --> 
ERROR - 2013-12-07 14:32:59 --> 404 Page Not Found --> 
ERROR - 2013-12-07 14:33:23 --> 404 Page Not Found --> 
ERROR - 2013-12-07 14:33:23 --> 404 Page Not Found --> 
ERROR - 2013-12-07 14:33:23 --> 404 Page Not Found --> 
ERROR - 2013-12-07 14:33:23 --> 404 Page Not Found --> 
ERROR - 2013-12-07 14:33:54 --> 404 Page Not Found --> 
ERROR - 2013-12-07 14:33:54 --> 404 Page Not Found --> 
ERROR - 2013-12-07 14:33:55 --> 404 Page Not Found --> 
ERROR - 2013-12-07 14:33:55 --> 404 Page Not Found --> 
ERROR - 2013-12-07 14:34:42 --> 404 Page Not Found --> 
ERROR - 2013-12-07 14:34:42 --> 404 Page Not Found --> 
ERROR - 2013-12-07 14:34:43 --> 404 Page Not Found --> 
ERROR - 2013-12-07 14:34:43 --> 404 Page Not Found --> 
ERROR - 2013-12-07 14:34:54 --> 404 Page Not Found --> 
ERROR - 2013-12-07 14:34:54 --> 404 Page Not Found --> 
ERROR - 2013-12-07 14:34:55 --> 404 Page Not Found --> 
ERROR - 2013-12-07 14:34:55 --> 404 Page Not Found --> 
ERROR - 2013-12-07 14:34:59 --> 404 Page Not Found --> Rmis/public
ERROR - 2013-12-07 14:36:25 --> 404 Page Not Found --> 
ERROR - 2013-12-07 14:36:25 --> 404 Page Not Found --> 
ERROR - 2013-12-07 14:36:25 --> 404 Page Not Found --> 
ERROR - 2013-12-07 14:36:25 --> 404 Page Not Found --> 
ERROR - 2013-12-07 14:36:29 --> 404 Page Not Found --> Rmis/relatedDocuments
ERROR - 2013-12-07 14:36:42 --> 404 Page Not Found --> Rmis/relatedDocuments
ERROR - 2013-12-07 14:36:48 --> 404 Page Not Found --> Rmis/relatedDocuments
ERROR - 2013-12-07 14:37:01 --> 404 Page Not Found --> 
ERROR - 2013-12-07 14:37:01 --> 404 Page Not Found --> 
ERROR - 2013-12-07 14:37:01 --> 404 Page Not Found --> 
ERROR - 2013-12-07 14:37:01 --> 404 Page Not Found --> 
ERROR - 2013-12-07 14:40:43 --> 404 Page Not Found --> 
ERROR - 2013-12-07 14:40:43 --> 404 Page Not Found --> 
ERROR - 2013-12-07 14:40:43 --> 404 Page Not Found --> 
ERROR - 2013-12-07 14:40:43 --> 404 Page Not Found --> 
ERROR - 2013-12-07 14:40:46 --> Severity: Warning  --> filesize() [<a href='function.filesize'>function.filesize</a>]: stat failed for carrusel-home-data-Virtual03.png C:\wamp\www\RMIS\application\modules\Rmis\controllers\program\relatedDocuments.php 318
ERROR - 2013-12-07 14:40:46 --> Severity: Warning  --> fpassthru() expects parameter 1 to be resource, boolean given C:\wamp\www\RMIS\application\modules\Rmis\controllers\program\relatedDocuments.php 321
ERROR - 2013-12-07 14:40:46 --> Severity: Warning  --> fclose() expects parameter 1 to be resource, boolean given C:\wamp\www\RMIS\application\modules\Rmis\controllers\program\relatedDocuments.php 322
ERROR - 2013-12-07 14:41:25 --> 404 Page Not Found --> 
ERROR - 2013-12-07 14:41:25 --> 404 Page Not Found --> 
ERROR - 2013-12-07 14:41:26 --> 404 Page Not Found --> 
ERROR - 2013-12-07 14:41:26 --> 404 Page Not Found --> 
ERROR - 2013-12-07 14:41:31 --> Severity: Warning  --> filesize() [<a href='function.filesize'>function.filesize</a>]: stat failed for Personal  Information.doc C:\wamp\www\RMIS\application\modules\Rmis\controllers\program\relatedDocuments.php 318
ERROR - 2013-12-07 14:41:32 --> Severity: Warning  --> fpassthru() expects parameter 1 to be resource, boolean given C:\wamp\www\RMIS\application\modules\Rmis\controllers\program\relatedDocuments.php 321
ERROR - 2013-12-07 14:41:32 --> Severity: Warning  --> fclose() expects parameter 1 to be resource, boolean given C:\wamp\www\RMIS\application\modules\Rmis\controllers\program\relatedDocuments.php 322
ERROR - 2013-12-07 15:22:35 --> 404 Page Not Found --> 
ERROR - 2013-12-07 15:22:35 --> 404 Page Not Found --> 
ERROR - 2013-12-07 15:22:35 --> 404 Page Not Found --> 
ERROR - 2013-12-07 15:22:35 --> 404 Page Not Found --> 
ERROR - 2013-12-07 15:25:31 --> 404 Page Not Found --> 
ERROR - 2013-12-07 15:25:31 --> 404 Page Not Found --> 
ERROR - 2013-12-07 15:25:32 --> 404 Page Not Found --> 
ERROR - 2013-12-07 15:25:32 --> 404 Page Not Found --> 
ERROR - 2013-12-07 15:25:38 --> Severity: Warning  --> filesize() [<a href='function.filesize'>function.filesize</a>]: stat failed for Personal  Information.doc C:\wamp\www\RMIS\application\modules\Rmis\controllers\program\relatedDocuments.php 318
ERROR - 2013-12-07 15:25:38 --> Severity: Warning  --> fpassthru() expects parameter 1 to be resource, boolean given C:\wamp\www\RMIS\application\modules\Rmis\controllers\program\relatedDocuments.php 321
ERROR - 2013-12-07 15:25:38 --> Severity: Warning  --> fclose() expects parameter 1 to be resource, boolean given C:\wamp\www\RMIS\application\modules\Rmis\controllers\program\relatedDocuments.php 322
ERROR - 2013-12-07 15:25:50 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\program\relatedDocuments\form.php 25
ERROR - 2013-12-07 15:25:50 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\program\relatedDocuments\form.php 114
ERROR - 2013-12-07 15:25:50 --> 404 Page Not Found --> 
ERROR - 2013-12-07 15:25:50 --> 404 Page Not Found --> 
ERROR - 2013-12-07 15:25:51 --> 404 Page Not Found --> 
ERROR - 2013-12-07 15:25:51 --> 404 Page Not Found --> 
ERROR - 2013-12-07 15:26:54 --> 404 Page Not Found --> 
ERROR - 2013-12-07 15:26:54 --> 404 Page Not Found --> 
ERROR - 2013-12-07 15:26:55 --> 404 Page Not Found --> 
ERROR - 2013-12-07 15:26:55 --> 404 Page Not Found --> 
ERROR - 2013-12-07 15:27:02 --> 404 Page Not Found --> 
ERROR - 2013-12-07 15:27:02 --> 404 Page Not Found --> 
ERROR - 2013-12-07 15:27:02 --> 404 Page Not Found --> 
ERROR - 2013-12-07 15:27:02 --> 404 Page Not Found --> 
ERROR - 2013-12-07 15:31:02 --> 404 Page Not Found --> 
ERROR - 2013-12-07 15:31:02 --> 404 Page Not Found --> 
ERROR - 2013-12-07 15:31:03 --> 404 Page Not Found --> 
ERROR - 2013-12-07 15:31:03 --> 404 Page Not Found --> 
ERROR - 2013-12-07 15:32:01 --> Severity: Warning  --> filesize() [<a href='function.filesize'>function.filesize</a>]: stat failed for Personal  Information.doc C:\wamp\www\RMIS\application\modules\Rmis\controllers\program\relatedDocuments.php 318
ERROR - 2013-12-07 15:32:01 --> Severity: Warning  --> fpassthru() expects parameter 1 to be resource, boolean given C:\wamp\www\RMIS\application\modules\Rmis\controllers\program\relatedDocuments.php 321
ERROR - 2013-12-07 15:32:01 --> Severity: Warning  --> fclose() expects parameter 1 to be resource, boolean given C:\wamp\www\RMIS\application\modules\Rmis\controllers\program\relatedDocuments.php 322
ERROR - 2013-12-07 15:32:11 --> 404 Page Not Found --> 
ERROR - 2013-12-07 15:32:11 --> 404 Page Not Found --> 
ERROR - 2013-12-07 15:32:11 --> 404 Page Not Found --> 
ERROR - 2013-12-07 15:32:11 --> 404 Page Not Found --> 
ERROR - 2013-12-07 16:51:56 --> 404 Page Not Found --> 
ERROR - 2013-12-07 16:51:56 --> 404 Page Not Found --> 
ERROR - 2013-12-07 16:51:57 --> 404 Page Not Found --> 
ERROR - 2013-12-07 16:51:57 --> 404 Page Not Found --> 
ERROR - 2013-12-07 16:53:01 --> 404 Page Not Found --> 
ERROR - 2013-12-07 16:53:01 --> 404 Page Not Found --> 
ERROR - 2013-12-07 16:53:01 --> 404 Page Not Found --> 
ERROR - 2013-12-07 16:53:01 --> 404 Page Not Found --> 
ERROR - 2013-12-07 16:55:53 --> 404 Page Not Found --> 
ERROR - 2013-12-07 16:55:53 --> 404 Page Not Found --> 
ERROR - 2013-12-07 16:55:54 --> 404 Page Not Found --> 
ERROR - 2013-12-07 16:55:54 --> 404 Page Not Found --> 
ERROR - 2013-12-07 16:56:16 --> 404 Page Not Found --> 
ERROR - 2013-12-07 16:56:16 --> 404 Page Not Found --> 
ERROR - 2013-12-07 16:56:17 --> 404 Page Not Found --> 
ERROR - 2013-12-07 16:56:17 --> 404 Page Not Found --> 
ERROR - 2013-12-07 16:57:26 --> 404 Page Not Found --> 
ERROR - 2013-12-07 16:57:26 --> 404 Page Not Found --> 
ERROR - 2013-12-07 16:57:27 --> 404 Page Not Found --> 
ERROR - 2013-12-07 16:57:27 --> 404 Page Not Found --> 
ERROR - 2013-12-07 16:57:35 --> 404 Page Not Found --> 
ERROR - 2013-12-07 16:57:35 --> 404 Page Not Found --> 
ERROR - 2013-12-07 16:57:35 --> 404 Page Not Found --> 
ERROR - 2013-12-07 16:57:35 --> 404 Page Not Found --> 
ERROR - 2013-12-07 16:58:01 --> 404 Page Not Found --> 
ERROR - 2013-12-07 16:58:01 --> 404 Page Not Found --> 
ERROR - 2013-12-07 16:58:02 --> 404 Page Not Found --> 
ERROR - 2013-12-07 16:58:02 --> 404 Page Not Found --> 
ERROR - 2013-12-07 16:58:11 --> 404 Page Not Found --> 
ERROR - 2013-12-07 16:58:11 --> 404 Page Not Found --> 
ERROR - 2013-12-07 16:58:11 --> 404 Page Not Found --> 
ERROR - 2013-12-07 16:58:11 --> 404 Page Not Found --> 
ERROR - 2013-12-07 16:59:15 --> 404 Page Not Found --> 
ERROR - 2013-12-07 16:59:15 --> 404 Page Not Found --> 
ERROR - 2013-12-07 16:59:16 --> 404 Page Not Found --> 
ERROR - 2013-12-07 16:59:16 --> 404 Page Not Found --> 
ERROR - 2013-12-07 16:59:34 --> 404 Page Not Found --> 
ERROR - 2013-12-07 16:59:34 --> 404 Page Not Found --> 
ERROR - 2013-12-07 16:59:35 --> 404 Page Not Found --> 
ERROR - 2013-12-07 16:59:35 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:00:02 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:00:02 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:00:03 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:00:03 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:01:04 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:01:05 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:01:05 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:01:05 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:01:14 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:01:14 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:01:14 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:01:14 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:02:00 --> Query error: Table 'natp_rmis.rmis_program_related_documents1' doesn't exist - Invalid query: DELETE FROM `rmis_program_related_documents1`
WHERE `id` = '2'
ERROR - 2013-12-07 17:03:06 --> Severity: 4096  --> Argument 1 passed to Illuminate\Database\Connection::__construct() must be an instance of PDO, instance of Template given, called in C:\wamp\www\RMIS\vendor\cartalyst\sentry\src\Cartalyst\Sentry\Facades\ConnectionResolver.php on line 117 and defined C:\wamp\www\RMIS\vendor\illuminate\database\Illuminate\Database\Connection.php 118
ERROR - 2013-12-07 17:03:16 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:03:17 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:03:17 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:03:17 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:05:57 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:05:57 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:05:57 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:05:57 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:06:52 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:06:52 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:06:53 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:06:53 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:06:57 --> Severity: Warning  --> filesize() [<a href='function.filesize'>function.filesize</a>]: stat failed for carrusel-home-data-Virtual03.png C:\wamp\www\RMIS\application\modules\Rmis\controllers\program\relatedDocuments.php 318
ERROR - 2013-12-07 17:06:57 --> Severity: Warning  --> fpassthru() expects parameter 1 to be resource, boolean given C:\wamp\www\RMIS\application\modules\Rmis\controllers\program\relatedDocuments.php 321
ERROR - 2013-12-07 17:06:57 --> Severity: Warning  --> fclose() expects parameter 1 to be resource, boolean given C:\wamp\www\RMIS\application\modules\Rmis\controllers\program\relatedDocuments.php 322
ERROR - 2013-12-07 17:07:00 --> Severity: Warning  --> filesize() [<a href='function.filesize'>function.filesize</a>]: stat failed for 8741698297_ef4399beb9_h-1018x4610.jpg C:\wamp\www\RMIS\application\modules\Rmis\controllers\program\relatedDocuments.php 318
ERROR - 2013-12-07 17:07:00 --> Severity: Warning  --> fpassthru() expects parameter 1 to be resource, boolean given C:\wamp\www\RMIS\application\modules\Rmis\controllers\program\relatedDocuments.php 321
ERROR - 2013-12-07 17:07:00 --> Severity: Warning  --> fclose() expects parameter 1 to be resource, boolean given C:\wamp\www\RMIS\application\modules\Rmis\controllers\program\relatedDocuments.php 322
ERROR - 2013-12-07 17:07:07 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:07:07 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:07:08 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:07:08 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:07:23 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:07:23 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:07:24 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:07:24 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:08:46 --> Severity: Warning  --> filesize() [<a href='function.filesize'>function.filesize</a>]: stat failed for 8741698297_ef4399beb9_h-1018x4610.jpg C:\wamp\www\RMIS\application\modules\Rmis\controllers\program\relatedDocuments.php 318
ERROR - 2013-12-07 17:08:46 --> Severity: Warning  --> fpassthru() expects parameter 1 to be resource, boolean given C:\wamp\www\RMIS\application\modules\Rmis\controllers\program\relatedDocuments.php 321
ERROR - 2013-12-07 17:08:46 --> Severity: Warning  --> fclose() expects parameter 1 to be resource, boolean given C:\wamp\www\RMIS\application\modules\Rmis\controllers\program\relatedDocuments.php 322
ERROR - 2013-12-07 17:43:39 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:43:39 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:43:40 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:43:40 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:43:44 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:43:44 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:43:44 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:43:44 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:43:47 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:43:47 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:43:47 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:43:48 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:44:33 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:44:33 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:44:34 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:44:34 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:44:43 --> Severity: Warning  --> filesize() [<a href='function.filesize'>function.filesize</a>]: stat failed for Chrysanthemum.jpg C:\wamp\www\RMIS\application\modules\Rmis\controllers\project\relatedDocuments.php 335
ERROR - 2013-12-07 17:44:43 --> Severity: Warning  --> fpassthru() expects parameter 1 to be resource, boolean given C:\wamp\www\RMIS\application\modules\Rmis\controllers\project\relatedDocuments.php 338
ERROR - 2013-12-07 17:44:43 --> Severity: Warning  --> fclose() expects parameter 1 to be resource, boolean given C:\wamp\www\RMIS\application\modules\Rmis\controllers\project\relatedDocuments.php 339
ERROR - 2013-12-07 17:44:51 --> Severity: Warning  --> filesize() [<a href='function.filesize'>function.filesize</a>]: stat failed for Penguins.jpg C:\wamp\www\RMIS\application\modules\Rmis\controllers\project\relatedDocuments.php 335
ERROR - 2013-12-07 17:44:51 --> Severity: Warning  --> fpassthru() expects parameter 1 to be resource, boolean given C:\wamp\www\RMIS\application\modules\Rmis\controllers\project\relatedDocuments.php 338
ERROR - 2013-12-07 17:44:51 --> Severity: Warning  --> fclose() expects parameter 1 to be resource, boolean given C:\wamp\www\RMIS\application\modules\Rmis\controllers\project\relatedDocuments.php 339
ERROR - 2013-12-07 17:45:06 --> Severity: Warning  --> filesize() [<a href='function.filesize'>function.filesize</a>]: stat failed for Tulips.jpg C:\wamp\www\RMIS\application\modules\Rmis\controllers\project\relatedDocuments.php 335
ERROR - 2013-12-07 17:45:06 --> Severity: Warning  --> fpassthru() expects parameter 1 to be resource, boolean given C:\wamp\www\RMIS\application\modules\Rmis\controllers\project\relatedDocuments.php 338
ERROR - 2013-12-07 17:45:06 --> Severity: Warning  --> fclose() expects parameter 1 to be resource, boolean given C:\wamp\www\RMIS\application\modules\Rmis\controllers\project\relatedDocuments.php 339
ERROR - 2013-12-07 17:45:16 --> Severity: Warning  --> filesize() [<a href='function.filesize'>function.filesize</a>]: stat failed for Chrysanthemum.jpg C:\wamp\www\RMIS\application\modules\Rmis\controllers\project\relatedDocuments.php 335
ERROR - 2013-12-07 17:45:16 --> Severity: Warning  --> fpassthru() expects parameter 1 to be resource, boolean given C:\wamp\www\RMIS\application\modules\Rmis\controllers\project\relatedDocuments.php 338
ERROR - 2013-12-07 17:45:17 --> Severity: Warning  --> fclose() expects parameter 1 to be resource, boolean given C:\wamp\www\RMIS\application\modules\Rmis\controllers\project\relatedDocuments.php 339
ERROR - 2013-12-07 17:45:19 --> Severity: Warning  --> filesize() [<a href='function.filesize'>function.filesize</a>]: stat failed for Penguins.jpg C:\wamp\www\RMIS\application\modules\Rmis\controllers\project\relatedDocuments.php 335
ERROR - 2013-12-07 17:45:19 --> Severity: Warning  --> fpassthru() expects parameter 1 to be resource, boolean given C:\wamp\www\RMIS\application\modules\Rmis\controllers\project\relatedDocuments.php 338
ERROR - 2013-12-07 17:45:19 --> Severity: Warning  --> fclose() expects parameter 1 to be resource, boolean given C:\wamp\www\RMIS\application\modules\Rmis\controllers\project\relatedDocuments.php 339
ERROR - 2013-12-07 17:45:45 --> Severity: Warning  --> filesize() [<a href='function.filesize'>function.filesize</a>]: stat failed for 8741698297_ef4399beb9_h-1018x4610.jpg C:\wamp\www\RMIS\application\modules\Rmis\controllers\program\relatedDocuments.php 318
ERROR - 2013-12-07 17:45:45 --> Severity: Warning  --> fpassthru() expects parameter 1 to be resource, boolean given C:\wamp\www\RMIS\application\modules\Rmis\controllers\program\relatedDocuments.php 321
ERROR - 2013-12-07 17:45:45 --> Severity: Warning  --> fclose() expects parameter 1 to be resource, boolean given C:\wamp\www\RMIS\application\modules\Rmis\controllers\program\relatedDocuments.php 322
ERROR - 2013-12-07 17:45:50 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:45:50 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:45:50 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:45:50 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:45:53 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:45:53 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:45:53 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:45:53 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:45:56 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:45:56 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:45:56 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:45:56 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:45:59 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:45:59 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:46:00 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:46:00 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:46:01 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:46:01 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:46:02 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:46:02 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:46:37 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:46:37 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:46:37 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:46:37 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:46:51 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:46:51 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:46:52 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:46:52 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:47:05 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:47:05 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:47:05 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:47:05 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:48:36 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:48:36 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:48:37 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:48:37 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:49:34 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:49:34 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:49:34 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:49:34 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:50:06 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:50:06 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:50:06 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:50:06 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:50:11 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:50:11 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:50:12 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:50:12 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:50:16 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:50:16 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:50:17 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:50:17 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:50:40 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:50:41 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:50:41 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:50:41 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:55:24 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:55:24 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:55:25 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:55:25 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:55:38 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:55:38 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:55:39 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:55:39 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:56:02 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:56:02 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:56:02 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:56:02 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:56:11 --> Severity: Warning  --> filesize() [<a href='function.filesize'>function.filesize</a>]: stat failed for New-York-Public-Domain.png C:\wamp\www\RMIS\application\modules\Rmis\controllers\project\relatedDocuments.php 333
ERROR - 2013-12-07 17:56:11 --> Severity: Warning  --> fpassthru() expects parameter 1 to be resource, boolean given C:\wamp\www\RMIS\application\modules\Rmis\controllers\project\relatedDocuments.php 336
ERROR - 2013-12-07 17:56:11 --> Severity: Warning  --> fclose() expects parameter 1 to be resource, boolean given C:\wamp\www\RMIS\application\modules\Rmis\controllers\project\relatedDocuments.php 337
ERROR - 2013-12-07 17:56:39 --> Severity: Warning  --> filesize() [<a href='function.filesize'>function.filesize</a>]: stat failed for Personal  Information.doc C:\wamp\www\RMIS\application\modules\Rmis\controllers\project\relatedDocuments.php 333
ERROR - 2013-12-07 17:56:39 --> Severity: Warning  --> fpassthru() expects parameter 1 to be resource, boolean given C:\wamp\www\RMIS\application\modules\Rmis\controllers\project\relatedDocuments.php 336
ERROR - 2013-12-07 17:56:39 --> Severity: Warning  --> fclose() expects parameter 1 to be resource, boolean given C:\wamp\www\RMIS\application\modules\Rmis\controllers\project\relatedDocuments.php 337
ERROR - 2013-12-07 17:57:22 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:57:22 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:57:22 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:57:22 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:57:28 --> Severity: Warning  --> filesize() [<a href='function.filesize'>function.filesize</a>]: stat failed for New-York-Public-Domain.png C:\wamp\www\RMIS\application\modules\Rmis\controllers\project\relatedDocuments.php 333
ERROR - 2013-12-07 17:57:28 --> Severity: Warning  --> fpassthru() expects parameter 1 to be resource, boolean given C:\wamp\www\RMIS\application\modules\Rmis\controllers\project\relatedDocuments.php 336
ERROR - 2013-12-07 17:57:28 --> Severity: Warning  --> fclose() expects parameter 1 to be resource, boolean given C:\wamp\www\RMIS\application\modules\Rmis\controllers\project\relatedDocuments.php 337
ERROR - 2013-12-07 17:59:46 --> Severity: Warning  --> filesize() [<a href='function.filesize'>function.filesize</a>]: stat failed for New-York-Public-Domain.png C:\wamp\www\RMIS\application\modules\Rmis\controllers\project\relatedDocuments.php 333
ERROR - 2013-12-07 17:59:46 --> Severity: Warning  --> fpassthru() expects parameter 1 to be resource, boolean given C:\wamp\www\RMIS\application\modules\Rmis\controllers\project\relatedDocuments.php 336
ERROR - 2013-12-07 17:59:46 --> Severity: Warning  --> fclose() expects parameter 1 to be resource, boolean given C:\wamp\www\RMIS\application\modules\Rmis\controllers\project\relatedDocuments.php 337
ERROR - 2013-12-07 17:59:52 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:59:52 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:59:53 --> 404 Page Not Found --> 
ERROR - 2013-12-07 17:59:53 --> 404 Page Not Found --> 
ERROR - 2013-12-07 18:00:12 --> 404 Page Not Found --> 
ERROR - 2013-12-07 18:00:12 --> 404 Page Not Found --> 
ERROR - 2013-12-07 18:00:13 --> 404 Page Not Found --> 
ERROR - 2013-12-07 18:00:13 --> 404 Page Not Found --> 
ERROR - 2013-12-07 18:00:19 --> Severity: Warning  --> filesize() [<a href='function.filesize'>function.filesize</a>]: stat failed for the-real-truth-about-mlm-compensation-plans.jpg C:\wamp\www\RMIS\application\modules\Rmis\controllers\project\relatedDocuments.php 333
ERROR - 2013-12-07 18:00:19 --> Severity: Warning  --> fpassthru() expects parameter 1 to be resource, boolean given C:\wamp\www\RMIS\application\modules\Rmis\controllers\project\relatedDocuments.php 336
ERROR - 2013-12-07 18:00:19 --> Severity: Warning  --> fclose() expects parameter 1 to be resource, boolean given C:\wamp\www\RMIS\application\modules\Rmis\controllers\project\relatedDocuments.php 337
ERROR - 2013-12-07 18:00:38 --> 404 Page Not Found --> 
ERROR - 2013-12-07 18:00:38 --> 404 Page Not Found --> 
ERROR - 2013-12-07 18:00:38 --> 404 Page Not Found --> 
ERROR - 2013-12-07 18:00:38 --> 404 Page Not Found --> 
