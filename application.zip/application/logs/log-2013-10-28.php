<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-10-28 09:56:20 --> 404 Page Not Found --> 
ERROR - 2013-10-28 09:56:20 --> 404 Page Not Found --> 
ERROR - 2013-10-28 10:43:13 --> 404 Page Not Found --> 
ERROR - 2013-10-28 10:43:13 --> 404 Page Not Found --> 
ERROR - 2013-10-28 10:44:27 --> 404 Page Not Found --> Vmis/nullpx
ERROR - 2013-10-28 10:44:27 --> 404 Page Not Found --> Vmis/nullimg_0_0_0
ERROR - 2013-10-28 11:32:40 --> 404 Page Not Found --> 
ERROR - 2013-10-28 11:32:44 --> 404 Page Not Found --> 
ERROR - 2013-10-28 11:57:07 --> 404 Page Not Found --> Vmis/nullpx
ERROR - 2013-10-28 11:57:07 --> 404 Page Not Found --> Vmis/nullimg_0_0_0
ERROR - 2013-10-28 11:57:32 --> 404 Page Not Found --> Vmis/nullimg_0_0_0
ERROR - 2013-10-28 11:57:32 --> 404 Page Not Found --> Vmis/nullpx
ERROR - 2013-10-28 15:58:22 --> 404 Page Not Found --> Pmm/nullimg_0_0_0
ERROR - 2013-10-28 15:58:22 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-28 16:21:54 --> 404 Page Not Found --> Pmm/nullimg_0_0_0
ERROR - 2013-10-28 16:21:54 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-28 16:22:05 --> 404 Page Not Found --> Pmm/nullimg_0_0_0
ERROR - 2013-10-28 16:22:05 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-28 16:22:20 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-28 16:22:20 --> 404 Page Not Found --> Pmm/nullimg_0_0_0
ERROR - 2013-10-28 16:23:15 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-28 16:23:15 --> 404 Page Not Found --> Pmm/nullimg_0_0_0
ERROR - 2013-10-28 16:23:23 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-28 16:23:23 --> 404 Page Not Found --> Pmm/nullimg_0_0_0
ERROR - 2013-10-28 16:23:30 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-28 16:23:30 --> 404 Page Not Found --> Pmm/nullimg_0_0_0
ERROR - 2013-10-28 16:37:31 --> 404 Page Not Found --> Pmm/nullimg_0_0_0
ERROR - 2013-10-28 16:37:31 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-28 16:43:05 --> Severity: Warning  --> array_push() expects parameter 1 to be array, string given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\models\pmm_report_model.php 56
ERROR - 2013-10-28 16:43:05 --> Severity: Warning  --> array_push() expects parameter 1 to be array, string given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\models\pmm_report_model.php 56
