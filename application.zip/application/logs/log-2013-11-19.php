<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-11-19 09:47:40 --> 404 Page Not Found --> 
ERROR - 2013-11-19 09:47:40 --> 404 Page Not Found --> 
ERROR - 2013-11-19 10:26:29 --> 404 Page Not Found --> Pmm/Interestrate
ERROR - 2013-11-19 10:37:14 --> 404 Page Not Found --> Pmm/Interestrate
ERROR - 2013-11-19 11:39:41 --> 404 Page Not Found --> Pmm/Loanpolicy
ERROR - 2013-11-19 14:07:43 --> 404 Page Not Found --> 
ERROR - 2013-11-19 14:09:23 --> 404 Page Not Found --> 
ERROR - 2013-11-19 14:09:31 --> 404 Page Not Found --> User/assets
ERROR - 2013-11-19 14:09:31 --> 404 Page Not Found --> User/assets
ERROR - 2013-11-19 14:21:23 --> 404 Page Not Found --> 
ERROR - 2013-11-19 14:21:57 --> 404 Page Not Found --> 
ERROR - 2013-11-19 14:21:59 --> 404 Page Not Found --> 
ERROR - 2013-11-19 14:22:05 --> 404 Page Not Found --> 
ERROR - 2013-11-19 14:23:14 --> 404 Page Not Found --> 
ERROR - 2013-11-19 14:23:34 --> 404 Page Not Found --> 
ERROR - 2013-11-19 14:24:16 --> 404 Page Not Found --> 
ERROR - 2013-11-19 14:24:20 --> 404 Page Not Found --> 
ERROR - 2013-11-19 15:20:19 --> 404 Page Not Found --> 
ERROR - 2013-11-19 18:48:55 --> 404 Page Not Found --> 
ERROR - 2013-11-19 18:48:59 --> 404 Page Not Found --> 
ERROR - 2013-11-19 18:53:44 --> 404 Page Not Found --> 
ERROR - 2013-11-19 18:59:22 --> 404 Page Not Found --> 
ERROR - 2013-11-19 18:59:27 --> 404 Page Not Found --> 
ERROR - 2013-11-19 18:59:27 --> 404 Page Not Found --> 
ERROR - 2013-11-19 18:59:48 --> 404 Page Not Found --> 
ERROR - 2013-11-19 18:59:51 --> 404 Page Not Found --> 
ERROR - 2013-11-19 18:59:54 --> 404 Page Not Found --> 
ERROR - 2013-11-19 18:59:54 --> 404 Page Not Found --> 
