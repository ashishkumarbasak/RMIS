<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-10-05 10:50:03 --> 404 Page Not Found --> 
ERROR - 2013-10-05 10:50:03 --> 404 Page Not Found --> 
ERROR - 2013-10-05 13:34:19 --> 404 Page Not Found --> 
ERROR - 2013-10-05 17:30:36 --> 404 Page Not Found --> 
ERROR - 2013-10-05 17:30:36 --> 404 Page Not Found --> 
