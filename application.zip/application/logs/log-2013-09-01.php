<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-09-01 10:49:35 --> 404 Page Not Found --> 
ERROR - 2013-09-01 10:49:35 --> 404 Page Not Found --> 
ERROR - 2013-09-01 10:54:30 --> 404 Page Not Found --> User/assets
ERROR - 2013-09-01 10:54:30 --> 404 Page Not Found --> User/assets
ERROR - 2013-09-01 10:54:35 --> 404 Page Not Found --> User/assets
ERROR - 2013-09-01 10:54:35 --> 404 Page Not Found --> User/assets
ERROR - 2013-09-01 13:24:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 2 - Invalid query: UPDATE `groups` SET `permissions` = ''
WHERE `id` =
ERROR - 2013-09-01 14:43:22 --> Severity: Warning  --> array_diff_assoc(): Argument #1 is not an array D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\User.php 498
ERROR - 2013-09-01 15:34:30 --> 404 Page Not Found --> 
ERROR - 2013-09-01 16:03:33 --> 404 Page Not Found --> 
ERROR - 2013-09-01 16:03:38 --> 404 Page Not Found --> 
ERROR - 2013-09-01 16:05:45 --> 404 Page Not Found --> 
ERROR - 2013-09-01 16:05:51 --> 404 Page Not Found --> 
ERROR - 2013-09-01 16:25:17 --> 404 Page Not Found --> 
ERROR - 2013-09-01 16:25:19 --> 404 Page Not Found --> 
ERROR - 2013-09-01 16:25:38 --> 404 Page Not Found --> 
ERROR - 2013-09-01 16:25:45 --> 404 Page Not Found --> 
ERROR - 2013-09-01 16:25:48 --> 404 Page Not Found --> 
ERROR - 2013-09-01 16:25:51 --> 404 Page Not Found --> 
ERROR - 2013-09-01 16:26:09 --> 404 Page Not Found --> 
ERROR - 2013-09-01 17:47:18 --> 404 Page Not Found --> 
