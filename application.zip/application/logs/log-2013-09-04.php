<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-09-04 09:54:36 --> 404 Page Not Found --> 
ERROR - 2013-09-04 09:54:37 --> 404 Page Not Found --> 
ERROR - 2013-09-04 10:24:15 --> 404 Page Not Found --> 
ERROR - 2013-09-04 10:24:18 --> 404 Page Not Found --> 
ERROR - 2013-09-04 12:34:55 --> 404 Page Not Found --> 
ERROR - 2013-09-04 12:36:16 --> 404 Page Not Found --> 
ERROR - 2013-09-04 12:36:18 --> 404 Page Not Found --> 
ERROR - 2013-09-04 12:36:46 --> 404 Page Not Found --> 
ERROR - 2013-09-04 12:36:50 --> 404 Page Not Found --> 
ERROR - 2013-09-04 12:37:13 --> 404 Page Not Found --> 
ERROR - 2013-09-04 13:51:18 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\pmm\views\setup\salary_head.php 36
ERROR - 2013-09-04 13:58:53 --> 404 Page Not Found --> 
ERROR - 2013-09-04 13:58:57 --> 404 Page Not Found --> 
ERROR - 2013-09-04 15:44:09 --> 404 Page Not Found --> Pmm/houserentpolicy
ERROR - 2013-09-04 15:44:18 --> 404 Page Not Found --> 
ERROR - 2013-09-04 15:45:03 --> 404 Page Not Found --> Pmm/houserentpolicy
ERROR - 2013-09-04 18:13:06 --> 404 Page Not Found --> Houserentpolicy/createDetails
