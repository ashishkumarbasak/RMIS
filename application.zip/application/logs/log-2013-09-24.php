<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-09-24 11:23:06 --> 404 Page Not Found --> 
ERROR - 2013-09-24 11:23:06 --> 404 Page Not Found --> 
ERROR - 2013-09-24 14:13:46 --> 404 Page Not Found --> 
ERROR - 2013-09-24 14:17:14 --> 404 Page Not Found --> 
