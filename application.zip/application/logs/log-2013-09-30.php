<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-09-30 10:02:11 --> 404 Page Not Found --> 
ERROR - 2013-09-30 10:02:11 --> 404 Page Not Found --> 
ERROR - 2013-09-30 10:27:16 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\views\setup\festival_allowance_policy_form.php 71
ERROR - 2013-09-30 10:27:16 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\views\setup\festival_allowance_policy_form.php 71
ERROR - 2013-09-30 10:27:16 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\views\setup\festival_allowance_policy_form.php 71
ERROR - 2013-09-30 10:27:16 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\views\setup\festival_allowance_policy_form.php 71
ERROR - 2013-09-30 10:35:02 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\views\setup\festival_allowance_policy_form.php 71
ERROR - 2013-09-30 10:35:02 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\views\setup\festival_allowance_policy_form.php 71
ERROR - 2013-09-30 10:35:02 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\views\setup\festival_allowance_policy_form.php 71
ERROR - 2013-09-30 10:35:02 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\views\setup\festival_allowance_policy_form.php 71
ERROR - 2013-09-30 10:37:50 --> Severity: Warning  --> Creating default object from empty value D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Festivalpolicy.php 346
ERROR - 2013-09-30 10:39:04 --> Severity: Warning  --> Creating default object from empty value D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Festivalpolicy.php 346
ERROR - 2013-09-30 12:47:18 --> 404 Page Not Found --> Houserentpolicy/save
ERROR - 2013-09-30 12:47:22 --> 404 Page Not Found --> Houserentpolicy/save
ERROR - 2013-09-30 13:18:11 --> Query error: Unknown column 'house_rent_id' in 'field list' - Invalid query: INSERT INTO `pmm_festival_policy_details` (`organization_id`, `house_rent_id`, `basic_salary_from`, `basic_salary_to`, `percentage_of_current_basic`, `minimum_amount`, `is_active`, `created_at`, `created_by`) VALUES (1, 1, 1, 1000, 10, 50, 1, '2013-09-30 13:18:11', '2')
ERROR - 2013-09-30 13:57:55 --> Severity: Warning  --> Creating default object from empty value D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Houserentpolicy.php 341
ERROR - 2013-09-30 14:00:35 --> Severity: Warning  --> Creating default object from empty value D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Houserentpolicy.php 341
ERROR - 2013-09-30 14:00:36 --> Severity: Warning  --> Creating default object from empty value D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Houserentpolicy.php 341
ERROR - 2013-09-30 14:06:46 --> Severity: Warning  --> Creating default object from empty value D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Houserentpolicy.php 341
