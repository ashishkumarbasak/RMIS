<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-08-20 09:45:44 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-20 09:45:44 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-20 11:10:48 --> 404 Page Not Found --> User/menu
ERROR - 2013-08-20 11:24:34 --> 404 Page Not Found --> 
ERROR - 2013-08-20 11:24:39 --> 404 Page Not Found --> 
ERROR - 2013-08-20 11:24:51 --> 404 Page Not Found --> 
ERROR - 2013-08-20 11:24:55 --> 404 Page Not Found --> 
ERROR - 2013-08-20 12:36:12 --> 404 Page Not Found --> 
ERROR - 2013-08-20 13:57:56 --> 404 Page Not Found --> 
ERROR - 2013-08-20 16:21:53 --> 404 Page Not Found --> User/add
ERROR - 2013-08-20 16:57:44 --> 404 Page Not Found --> User/add
ERROR - 2013-08-20 16:57:53 --> 404 Page Not Found --> User/add
ERROR - 2013-08-20 17:03:22 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-20 17:03:22 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-20 18:45:40 --> 404 Page Not Found --> 
ERROR - 2013-08-20 18:45:40 --> 404 Page Not Found --> 
