<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-10-23 10:05:05 --> 404 Page Not Found --> 
ERROR - 2013-10-23 10:05:05 --> 404 Page Not Found --> 
ERROR - 2013-10-23 13:56:48 --> Severity: Warning  --> require_once(http://localhost:8088/JavaBridge/java/Java.inc): failed to open stream: No connection could be made because the target machine actively refused it.
 D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Rptpayslip.php 50
ERROR - 2013-10-23 14:57:32 --> Severity: Warning  --> require_once(http://localhost:8088/JavaBridge/java/Java.inc): failed to open stream: No connection could be made because the target machine actively refused it.
 D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Rptpayslip.php 50
ERROR - 2013-10-23 15:20:19 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-23 15:20:19 --> 404 Page Not Found --> Pmm/nullimg_0_0_0
ERROR - 2013-10-23 15:25:58 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-23 15:25:58 --> 404 Page Not Found --> Pmm/nullimg_0_0_0
ERROR - 2013-10-23 15:27:17 --> 404 Page Not Found --> Pmm/nullimg_0_0_0
ERROR - 2013-10-23 15:27:17 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-23 15:28:13 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-23 15:28:13 --> 404 Page Not Found --> Pmm/nullimg_0_0_0
ERROR - 2013-10-23 15:37:57 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-23 15:37:57 --> 404 Page Not Found --> Pmm/nullimg_0_0_0
ERROR - 2013-10-23 15:38:19 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-23 15:38:19 --> 404 Page Not Found --> Pmm/nullimg_0_0_0
ERROR - 2013-10-23 15:39:07 --> 404 Page Not Found --> Pmm/nullimg_0_0_0
ERROR - 2013-10-23 15:39:08 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-23 15:39:52 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-23 15:39:52 --> 404 Page Not Found --> Pmm/nullimg_0_0_0
ERROR - 2013-10-23 15:40:07 --> 404 Page Not Found --> Pmm/nullimg_0_0_0
ERROR - 2013-10-23 15:40:07 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-23 15:44:48 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-23 15:44:48 --> 404 Page Not Found --> Pmm/nullimg_0_0_0
ERROR - 2013-10-23 15:46:22 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-23 15:46:22 --> 404 Page Not Found --> Pmm/nullimg_0_0_0
ERROR - 2013-10-23 15:47:26 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-23 15:47:26 --> 404 Page Not Found --> Pmm/nullimg_0_0_0
ERROR - 2013-10-23 15:48:14 --> 404 Page Not Found --> Pmm/nullimg_0_0_0
ERROR - 2013-10-23 15:48:14 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-23 15:49:14 --> 404 Page Not Found --> Pmm/nullimg_0_0_0
ERROR - 2013-10-23 15:49:14 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-23 15:50:28 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-23 15:51:08 --> 404 Page Not Found --> Pmm/nullimg_0_0_0
ERROR - 2013-10-23 15:51:08 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-23 15:52:01 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-23 15:52:01 --> 404 Page Not Found --> Pmm/nullimg_0_0_0
ERROR - 2013-10-23 15:52:18 --> 404 Page Not Found --> Pmm/nullimg_0_0_0
ERROR - 2013-10-23 15:52:18 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-23 15:53:31 --> 404 Page Not Found --> Pmm/nullimg_0_0_0
ERROR - 2013-10-23 15:53:31 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-23 16:13:34 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-23 16:13:34 --> 404 Page Not Found --> Pmm/nullimg_0_0_0
ERROR - 2013-10-23 16:22:27 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-23 16:22:27 --> 404 Page Not Found --> Pmm/nullimg_0_0_0
ERROR - 2013-10-23 17:26:20 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-23 17:26:20 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-23 17:26:20 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-23 17:26:20 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-23 17:26:20 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-23 17:26:20 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-23 17:26:20 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-23 17:26:20 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-23 17:26:20 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-23 17:26:20 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-23 17:30:01 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-23 17:30:01 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-23 17:30:01 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-23 17:30:01 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-23 17:30:01 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-23 17:30:01 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-23 17:30:01 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-23 17:30:01 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-23 17:30:01 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-23 17:30:01 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-23 18:06:13 --> 404 Page Not Found --> 
ERROR - 2013-10-23 18:06:16 --> 404 Page Not Found --> 
ERROR - 2013-10-23 18:06:20 --> 404 Page Not Found --> 
