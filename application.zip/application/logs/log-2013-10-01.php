<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-10-01 11:42:28 --> 404 Page Not Found --> 
ERROR - 2013-10-01 11:42:28 --> 404 Page Not Found --> 
ERROR - 2013-10-01 12:36:10 --> 404 Page Not Found --> 
ERROR - 2013-10-01 12:36:15 --> 404 Page Not Found --> 
ERROR - 2013-10-01 12:37:35 --> 404 Page Not Found --> 
ERROR - 2013-10-01 12:37:38 --> 404 Page Not Found --> Acraerattribute/index
ERROR - 2013-10-01 12:37:42 --> 404 Page Not Found --> 
ERROR - 2013-10-01 12:37:44 --> 404 Page Not Found --> 
ERROR - 2013-10-01 12:37:48 --> 404 Page Not Found --> 
ERROR - 2013-10-01 12:40:09 --> 404 Page Not Found --> 
ERROR - 2013-10-01 13:31:24 --> 404 Page Not Found --> 
ERROR - 2013-10-01 13:34:43 --> 404 Page Not Found --> 
ERROR - 2013-10-01 14:11:35 --> Severity: Warning  --> trim() expects parameter 1 to be string, object given D:\Zend\Apache2\htdocs\natp_barc\system\libraries\Form_validation.php 718
ERROR - 2013-10-01 14:11:35 --> Severity: 4096  --> Object of class stdClass could not be converted to string D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 499
ERROR - 2013-10-01 14:11:40 --> Severity: Warning  --> trim() expects parameter 1 to be string, object given D:\Zend\Apache2\htdocs\natp_barc\system\libraries\Form_validation.php 718
ERROR - 2013-10-01 14:11:40 --> Severity: 4096  --> Object of class stdClass could not be converted to string D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 499
ERROR - 2013-10-01 15:01:08 --> 404 Page Not Found --> 
