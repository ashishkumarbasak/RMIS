<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-12-19 00:00:46 --> 404 Page Not Found --> 
ERROR - 2013-12-19 00:00:46 --> 404 Page Not Found --> 
ERROR - 2013-12-19 00:00:46 --> 404 Page Not Found --> 
ERROR - 2013-12-19 00:00:46 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:09:49 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:09:49 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:09:49 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:09:49 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:09:52 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:09:52 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:09:52 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:09:52 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:09:52 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:09:52 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:09:52 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:09:52 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:09:52 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:09:52 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:09:56 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:09:56 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:09:56 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:09:56 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:10:00 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:10:00 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:10:00 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:10:00 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:10:04 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:10:04 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:10:04 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:10:04 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:10:06 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:10:06 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:10:06 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:10:06 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:10:08 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:10:08 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:10:09 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:10:09 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:10:10 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:10:10 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:10:11 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:10:11 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:10:12 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:10:12 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:10:13 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:10:13 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:10:21 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:10:21 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:10:21 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:10:21 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:10:42 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:10:42 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:10:43 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:10:43 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:10:46 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:10:46 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:10:46 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:10:46 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:10:50 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:10:50 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:10:51 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:10:51 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:10:58 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:10:58 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:10:59 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:10:59 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:11:10 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:11:11 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:11:11 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:11:11 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:11:13 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:11:13 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:11:14 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:11:14 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:11:17 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:11:17 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:11:18 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:11:18 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:11:32 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:11:32 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:11:33 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:11:33 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:11:38 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:11:38 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:11:39 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:11:39 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:11:42 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:11:42 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:11:42 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:11:42 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:12:14 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:12:14 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:12:14 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:12:14 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:12:23 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:12:23 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:12:24 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:12:24 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:13:46 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:13:46 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:13:46 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:13:46 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:14:26 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:14:26 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:14:26 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:14:26 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:14:29 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:14:30 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:14:30 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:14:30 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:15:06 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:15:06 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:15:06 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:15:06 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:16:43 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:16:43 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:16:44 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:16:44 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:16:45 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:16:46 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:16:51 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:16:51 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:18:39 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:18:39 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:18:39 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:18:39 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:18:53 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:18:53 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:18:54 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:18:54 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:20:53 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:20:53 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:20:53 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:20:53 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:21:05 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:21:05 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:21:05 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:21:05 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:21:21 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:21:21 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:21:22 --> 404 Page Not Found --> 
ERROR - 2013-12-19 11:21:22 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:11:43 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:11:43 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:11:43 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:11:43 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:11:46 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:11:46 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:11:46 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:11:46 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:11:46 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:11:46 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:11:51 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:11:51 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:11:51 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:11:51 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:33:12 --> Query error: Table 'natp_rmis.imis_store_setup' doesn't exist - Invalid query: SELECT `id` as `value`, `store_name` as `text`
FROM `imis_store_setup`
ORDER BY `store_name` asc
ERROR - 2013-12-19 18:34:20 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 43
ERROR - 2013-12-19 18:34:20 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 58
ERROR - 2013-12-19 18:34:20 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 74
ERROR - 2013-12-19 18:34:20 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 90
ERROR - 2013-12-19 18:35:47 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 43
ERROR - 2013-12-19 18:35:47 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 58
ERROR - 2013-12-19 18:35:47 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 74
ERROR - 2013-12-19 18:35:47 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 90
ERROR - 2013-12-19 18:44:43 --> Severity: Warning  --> require_once() [<a href='function.require-once'>function.require-once</a>]: http:// wrapper is disabled in the server configuration by allow_url_include=0 C:\wamp\www\RMIS\application\modules\Rmis\controllers\Rptfixedassetinformtion.php 64
ERROR - 2013-12-19 18:44:43 --> Severity: Warning  --> require_once(http://localhost:8088/JavaBridge/java/Java.inc) [<a href='function.require-once'>function.require-once</a>]: failed to open stream: no suitable wrapper could be found C:\wamp\www\RMIS\application\modules\Rmis\controllers\Rptfixedassetinformtion.php 64
ERROR - 2013-12-19 18:46:49 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 43
ERROR - 2013-12-19 18:46:49 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 58
ERROR - 2013-12-19 18:46:49 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 74
ERROR - 2013-12-19 18:46:49 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 90
ERROR - 2013-12-19 18:47:55 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 43
ERROR - 2013-12-19 18:47:55 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 58
ERROR - 2013-12-19 18:47:55 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 74
ERROR - 2013-12-19 18:47:55 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 90
ERROR - 2013-12-19 18:48:09 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 43
ERROR - 2013-12-19 18:48:09 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 58
ERROR - 2013-12-19 18:48:09 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 74
ERROR - 2013-12-19 18:48:09 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 90
ERROR - 2013-12-19 18:48:34 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 43
ERROR - 2013-12-19 18:48:34 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 58
ERROR - 2013-12-19 18:48:34 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 74
ERROR - 2013-12-19 18:48:34 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 90
ERROR - 2013-12-19 18:48:34 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:48:34 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:48:35 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:48:35 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:50:19 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 43
ERROR - 2013-12-19 18:50:19 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 58
ERROR - 2013-12-19 18:50:19 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 74
ERROR - 2013-12-19 18:50:19 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 90
ERROR - 2013-12-19 18:50:20 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:50:20 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:50:20 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:50:20 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:51:07 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 43
ERROR - 2013-12-19 18:51:07 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 58
ERROR - 2013-12-19 18:51:07 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 74
ERROR - 2013-12-19 18:51:07 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 90
ERROR - 2013-12-19 18:51:07 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:51:07 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:51:08 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:51:08 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:52:56 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 43
ERROR - 2013-12-19 18:52:56 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 58
ERROR - 2013-12-19 18:52:56 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 74
ERROR - 2013-12-19 18:52:56 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 90
ERROR - 2013-12-19 18:52:56 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:52:56 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:52:57 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:52:57 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:53:41 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 43
ERROR - 2013-12-19 18:53:41 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 58
ERROR - 2013-12-19 18:53:41 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 74
ERROR - 2013-12-19 18:53:41 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 90
ERROR - 2013-12-19 18:53:41 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:53:41 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:53:42 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:53:42 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:53:45 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:54:21 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 43
ERROR - 2013-12-19 18:54:21 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 58
ERROR - 2013-12-19 18:54:21 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 74
ERROR - 2013-12-19 18:54:22 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 90
ERROR - 2013-12-19 18:54:22 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:54:22 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:54:22 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:54:22 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:55:02 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 43
ERROR - 2013-12-19 18:55:02 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 58
ERROR - 2013-12-19 18:55:02 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 74
ERROR - 2013-12-19 18:55:02 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 90
ERROR - 2013-12-19 18:55:02 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:55:02 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:55:03 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:55:03 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:55:24 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 43
ERROR - 2013-12-19 18:55:24 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 58
ERROR - 2013-12-19 18:55:24 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 74
ERROR - 2013-12-19 18:55:24 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 90
ERROR - 2013-12-19 18:55:24 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:55:24 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:55:25 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:55:25 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:56:21 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 43
ERROR - 2013-12-19 18:56:21 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 58
ERROR - 2013-12-19 18:56:21 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 74
ERROR - 2013-12-19 18:56:21 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 90
ERROR - 2013-12-19 18:56:21 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:56:21 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:56:21 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:56:22 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:58:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 43
ERROR - 2013-12-19 18:58:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 58
ERROR - 2013-12-19 18:58:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 74
ERROR - 2013-12-19 18:58:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 90
ERROR - 2013-12-19 18:58:18 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:58:18 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:58:19 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:58:19 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:59:07 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 43
ERROR - 2013-12-19 18:59:07 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 58
ERROR - 2013-12-19 18:59:07 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 74
ERROR - 2013-12-19 18:59:07 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 90
ERROR - 2013-12-19 18:59:07 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:59:07 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:59:07 --> 404 Page Not Found --> 
ERROR - 2013-12-19 18:59:07 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:00:02 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 43
ERROR - 2013-12-19 19:00:02 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 58
ERROR - 2013-12-19 19:00:02 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 74
ERROR - 2013-12-19 19:00:02 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 90
ERROR - 2013-12-19 19:00:02 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:00:02 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:00:03 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:00:03 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:03:05 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 43
ERROR - 2013-12-19 19:03:05 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 58
ERROR - 2013-12-19 19:03:05 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 74
ERROR - 2013-12-19 19:03:05 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 90
ERROR - 2013-12-19 19:03:05 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:03:05 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:03:06 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:03:06 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:22:10 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:22:22 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 43
ERROR - 2013-12-19 19:22:22 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 58
ERROR - 2013-12-19 19:22:22 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 74
ERROR - 2013-12-19 19:22:22 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 90
ERROR - 2013-12-19 19:22:22 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:22:22 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:22:23 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:22:23 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:23:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 43
ERROR - 2013-12-19 19:23:15 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 58
ERROR - 2013-12-19 19:23:15 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 74
ERROR - 2013-12-19 19:23:15 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\fixed_asset_information.php 90
ERROR - 2013-12-19 19:23:15 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:23:15 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:23:15 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:23:15 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:24:27 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 43
ERROR - 2013-12-19 19:24:27 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 58
ERROR - 2013-12-19 19:24:27 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 74
ERROR - 2013-12-19 19:24:27 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 90
ERROR - 2013-12-19 19:24:27 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:24:27 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:24:27 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:24:27 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:26:44 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 43
ERROR - 2013-12-19 19:26:44 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 58
ERROR - 2013-12-19 19:26:44 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 74
ERROR - 2013-12-19 19:26:44 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 90
ERROR - 2013-12-19 19:26:44 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:26:44 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:26:45 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:26:45 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:27:23 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 43
ERROR - 2013-12-19 19:27:23 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 58
ERROR - 2013-12-19 19:27:23 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 74
ERROR - 2013-12-19 19:27:23 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 90
ERROR - 2013-12-19 19:27:23 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:27:23 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:27:24 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:27:24 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:27:49 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 43
ERROR - 2013-12-19 19:27:49 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 58
ERROR - 2013-12-19 19:27:49 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 74
ERROR - 2013-12-19 19:27:49 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 90
ERROR - 2013-12-19 19:27:49 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:27:49 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:27:50 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:27:50 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:28:50 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 43
ERROR - 2013-12-19 19:28:51 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 58
ERROR - 2013-12-19 19:28:51 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 74
ERROR - 2013-12-19 19:28:51 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 90
ERROR - 2013-12-19 19:28:51 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 137
ERROR - 2013-12-19 19:28:51 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 153
ERROR - 2013-12-19 19:28:51 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:28:51 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:28:52 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:28:52 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:29:34 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 43
ERROR - 2013-12-19 19:29:34 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 58
ERROR - 2013-12-19 19:29:34 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 74
ERROR - 2013-12-19 19:29:34 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 90
ERROR - 2013-12-19 19:29:34 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 137
ERROR - 2013-12-19 19:29:34 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 153
ERROR - 2013-12-19 19:29:34 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 201
ERROR - 2013-12-19 19:29:34 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 217
ERROR - 2013-12-19 19:29:35 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:29:35 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:29:36 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:29:36 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:30:30 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 43
ERROR - 2013-12-19 19:30:30 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 58
ERROR - 2013-12-19 19:30:30 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 74
ERROR - 2013-12-19 19:30:30 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 90
ERROR - 2013-12-19 19:30:30 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 137
ERROR - 2013-12-19 19:30:31 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 153
ERROR - 2013-12-19 19:30:31 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 201
ERROR - 2013-12-19 19:30:31 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 217
ERROR - 2013-12-19 19:30:31 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:30:31 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:30:32 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:30:32 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:32:42 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 43
ERROR - 2013-12-19 19:32:42 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 58
ERROR - 2013-12-19 19:32:42 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 74
ERROR - 2013-12-19 19:32:42 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 90
ERROR - 2013-12-19 19:32:42 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 137
ERROR - 2013-12-19 19:32:42 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 187
ERROR - 2013-12-19 19:32:42 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 203
ERROR - 2013-12-19 19:32:43 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:32:43 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:32:43 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:32:43 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:39:15 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 43
ERROR - 2013-12-19 19:39:15 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 58
ERROR - 2013-12-19 19:39:15 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 74
ERROR - 2013-12-19 19:39:15 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 90
ERROR - 2013-12-19 19:39:15 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 137
ERROR - 2013-12-19 19:39:15 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 180
ERROR - 2013-12-19 19:39:15 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 196
ERROR - 2013-12-19 19:39:15 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:39:15 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:39:15 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:39:15 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:39:40 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 42
ERROR - 2013-12-19 19:39:40 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 57
ERROR - 2013-12-19 19:39:40 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 73
ERROR - 2013-12-19 19:39:40 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 89
ERROR - 2013-12-19 19:39:40 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 136
ERROR - 2013-12-19 19:39:40 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 179
ERROR - 2013-12-19 19:39:40 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 195
ERROR - 2013-12-19 19:39:40 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:39:40 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:39:41 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:39:41 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:40:07 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 42
ERROR - 2013-12-19 19:40:07 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 57
ERROR - 2013-12-19 19:40:07 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 73
ERROR - 2013-12-19 19:40:07 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 89
ERROR - 2013-12-19 19:40:07 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 136
ERROR - 2013-12-19 19:40:07 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 179
ERROR - 2013-12-19 19:40:07 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 195
ERROR - 2013-12-19 19:40:07 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:40:07 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:40:08 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:40:08 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:41:00 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 42
ERROR - 2013-12-19 19:41:00 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 57
ERROR - 2013-12-19 19:41:00 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 73
ERROR - 2013-12-19 19:41:00 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 89
ERROR - 2013-12-19 19:41:00 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 136
ERROR - 2013-12-19 19:41:00 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 173
ERROR - 2013-12-19 19:41:00 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 189
ERROR - 2013-12-19 19:41:01 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:41:01 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:41:01 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:41:01 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:41:41 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 42
ERROR - 2013-12-19 19:41:41 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 70
ERROR - 2013-12-19 19:41:41 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 86
ERROR - 2013-12-19 19:41:41 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 133
ERROR - 2013-12-19 19:41:41 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 170
ERROR - 2013-12-19 19:41:41 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 186
ERROR - 2013-12-19 19:41:41 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:41:41 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:41:42 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:41:42 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:44:41 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 42
ERROR - 2013-12-19 19:44:41 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 119
ERROR - 2013-12-19 19:44:41 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 156
ERROR - 2013-12-19 19:44:41 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 172
ERROR - 2013-12-19 19:44:41 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:44:41 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:44:42 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:44:42 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:56:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 42
ERROR - 2013-12-19 19:56:01 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:56:01 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:56:02 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:56:02 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:56:58 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 42
ERROR - 2013-12-19 19:56:58 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 42
ERROR - 2013-12-19 19:56:58 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 42
ERROR - 2013-12-19 19:56:58 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 42
ERROR - 2013-12-19 19:56:58 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 42
ERROR - 2013-12-19 19:56:58 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 42
ERROR - 2013-12-19 19:56:58 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 42
ERROR - 2013-12-19 19:56:58 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given C:\wamp\www\RMIS\application\modules\Rmis\views\reports\division_wise_report.php 42
ERROR - 2013-12-19 19:56:59 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:56:59 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:57:00 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:57:00 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:58:04 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:58:04 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:58:05 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:58:05 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:58:09 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:58:09 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:58:10 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:58:10 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:58:45 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:58:45 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:58:46 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:58:46 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:59:30 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:59:30 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:59:30 --> 404 Page Not Found --> 
ERROR - 2013-12-19 19:59:30 --> 404 Page Not Found --> 
ERROR - 2013-12-19 20:01:23 --> 404 Page Not Found --> 
ERROR - 2013-12-19 20:01:23 --> 404 Page Not Found --> 
ERROR - 2013-12-19 20:01:24 --> 404 Page Not Found --> 
ERROR - 2013-12-19 20:01:24 --> 404 Page Not Found --> 
ERROR - 2013-12-19 20:03:01 --> 404 Page Not Found --> 
ERROR - 2013-12-19 20:03:01 --> 404 Page Not Found --> 
ERROR - 2013-12-19 20:03:02 --> 404 Page Not Found --> 
ERROR - 2013-12-19 20:03:02 --> 404 Page Not Found --> 
ERROR - 2013-12-19 20:05:16 --> 404 Page Not Found --> 
ERROR - 2013-12-19 20:05:16 --> 404 Page Not Found --> 
ERROR - 2013-12-19 20:05:17 --> 404 Page Not Found --> 
ERROR - 2013-12-19 20:05:17 --> 404 Page Not Found --> 
ERROR - 2013-12-19 20:06:11 --> 404 Page Not Found --> 
ERROR - 2013-12-19 20:06:11 --> 404 Page Not Found --> 
ERROR - 2013-12-19 20:06:11 --> 404 Page Not Found --> 
ERROR - 2013-12-19 20:06:11 --> 404 Page Not Found --> 
ERROR - 2013-12-19 20:09:24 --> 404 Page Not Found --> 
ERROR - 2013-12-19 20:09:24 --> 404 Page Not Found --> 
ERROR - 2013-12-19 20:09:25 --> 404 Page Not Found --> 
ERROR - 2013-12-19 20:09:25 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:09:14 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:09:14 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:09:14 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:09:14 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:09:17 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:09:17 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:09:17 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:09:17 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:09:17 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:09:18 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:09:23 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:09:23 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:09:24 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:09:24 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:09:27 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:09:27 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:09:28 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:09:28 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:13:30 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:13:30 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:13:31 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:13:31 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:13:38 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:13:38 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:13:39 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:13:39 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:16:32 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:16:32 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:16:32 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:16:32 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:16:53 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:16:53 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:16:54 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:16:54 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:17:53 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:17:53 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:17:54 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:17:54 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:48:10 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:48:10 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:48:10 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:48:10 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:48:17 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:48:17 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:48:17 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:48:17 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:49:48 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:49:48 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:49:48 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:49:48 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:51:13 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:51:13 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:51:13 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:51:13 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:51:36 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:51:36 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:51:37 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:51:37 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:51:47 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:51:47 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:51:47 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:51:47 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:52:03 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:52:03 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:52:04 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:52:04 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:53:05 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:53:05 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:53:05 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:53:05 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:53:55 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:53:55 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:53:56 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:53:56 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:54:29 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:54:29 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:54:30 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:54:30 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:54:47 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:54:47 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:54:48 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:54:48 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:58:20 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:58:20 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:58:21 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:58:21 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:59:33 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:59:33 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:59:33 --> 404 Page Not Found --> 
ERROR - 2013-12-19 23:59:33 --> 404 Page Not Found --> 
