<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-08-26 10:10:29 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-26 10:10:29 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-26 10:11:07 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-26 10:11:07 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-26 10:11:09 --> 404 Page Not Found --> 
ERROR - 2013-08-26 10:11:09 --> 404 Page Not Found --> 
ERROR - 2013-08-26 11:25:26 --> 404 Page Not Found --> 
ERROR - 2013-08-26 11:32:52 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\views\users\changepassword.php 58
ERROR - 2013-08-26 11:33:20 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\views\users\changepassword.php 58
ERROR - 2013-08-26 11:33:20 --> 404 Page Not Found --> Profile/assets
ERROR - 2013-08-26 11:33:20 --> 404 Page Not Found --> Profile/assets
