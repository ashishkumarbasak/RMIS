<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-11-20 10:09:43 --> 404 Page Not Found --> Login/chk
ERROR - 2013-11-20 10:09:54 --> 404 Page Not Found --> 
ERROR - 2013-11-20 10:09:54 --> 404 Page Not Found --> 
ERROR - 2013-11-20 10:10:38 --> 404 Page Not Found --> Pmm/Loanpolicy
ERROR - 2013-11-20 11:02:36 --> 404 Page Not Found --> Pmm/Loanpolicy
