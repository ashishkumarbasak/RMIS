<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-09-17 09:50:24 --> 404 Page Not Found --> 
ERROR - 2013-09-17 09:50:24 --> 404 Page Not Found --> 
ERROR - 2013-09-17 12:08:36 --> 404 Page Not Found --> 
ERROR - 2013-09-17 12:08:36 --> 404 Page Not Found --> 
ERROR - 2013-09-17 12:08:39 --> 404 Page Not Found --> 
ERROR - 2013-09-17 12:08:43 --> 404 Page Not Found --> 
ERROR - 2013-09-17 13:26:06 --> Severity: Warning  --> Creating default object from empty value D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Chargeallowance.php 235
ERROR - 2013-09-17 15:01:02 --> Severity: Warning  --> Creating default object from empty value D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Chargeallowance.php 52
ERROR - 2013-09-17 15:20:06 --> Severity: Warning  --> PDOStatement::fetchAll() expects parameter 1 to be long, string given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\models\charge_allowance_model.php 64
ERROR - 2013-09-17 17:58:43 --> Severity: Warning  --> Illegal string offset '&#36;_GET['_']' D:\Zend\Apache2\htdocs\natp_barc\application\libraries\Profiler.php 228
