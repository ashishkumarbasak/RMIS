<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-09-29 10:30:49 --> 404 Page Not Found --> 
ERROR - 2013-09-29 10:30:49 --> 404 Page Not Found --> 
ERROR - 2013-09-29 10:30:59 --> 404 Page Not Found --> 
ERROR - 2013-09-29 11:26:00 --> 404 Page Not Found --> 
ERROR - 2013-09-29 11:26:00 --> 404 Page Not Found --> 
ERROR - 2013-09-29 11:26:00 --> 404 Page Not Found --> 
ERROR - 2013-09-29 11:26:00 --> 404 Page Not Found --> 
ERROR - 2013-09-29 11:26:01 --> 404 Page Not Found --> 
ERROR - 2013-09-29 11:26:01 --> 404 Page Not Found --> 
ERROR - 2013-09-29 11:26:01 --> 404 Page Not Found --> 
ERROR - 2013-09-29 11:26:01 --> 404 Page Not Found --> 
ERROR - 2013-09-29 13:16:30 --> 404 Page Not Found --> Festivalpolicy/save
ERROR - 2013-09-29 14:08:09 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Festivalpolicy.php 259
ERROR - 2013-09-29 15:45:55 --> 404 Page Not Found --> 
ERROR - 2013-09-29 15:45:58 --> 404 Page Not Found --> 
ERROR - 2013-09-29 15:46:01 --> 404 Page Not Found --> 
ERROR - 2013-09-29 15:46:03 --> 404 Page Not Found --> 
ERROR - 2013-09-29 15:46:05 --> 404 Page Not Found --> 
ERROR - 2013-09-29 15:48:24 --> 404 Page Not Found --> 
ERROR - 2013-09-29 15:48:27 --> 404 Page Not Found --> 
ERROR - 2013-09-29 15:48:29 --> 404 Page Not Found --> 
ERROR - 2013-09-29 15:48:32 --> 404 Page Not Found --> 
ERROR - 2013-09-29 15:48:36 --> 404 Page Not Found --> 
ERROR - 2013-09-29 16:47:43 --> Severity: Warning  --> Missing argument 1 for FestivalPolicyModel::getPolicyInfo(), called in D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Festivalpolicy.php on line 212 and defined D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\models\festivalpolicymodel.php 32
ERROR - 2013-09-29 16:47:47 --> Severity: Warning  --> Missing argument 1 for FestivalPolicyModel::getPolicyInfo(), called in D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Festivalpolicy.php on line 212 and defined D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\models\festivalpolicymodel.php 32
ERROR - 2013-09-29 17:04:20 --> Query error: Unknown column 'fastival_policy_info_id' in 'where clause' - Invalid query: SELECT *
FROM `pmm_festival_policy_info`
WHERE `fastival_policy_info_id` = '1'
ERROR - 2013-09-29 17:04:48 --> Query error: Unknown column 'fastival_policy_info_id' in 'where clause' - Invalid query: SELECT *
FROM `pmm_festival_policy_info`
WHERE `fastival_policy_info_id` = '1'
ERROR - 2013-09-29 17:04:54 --> Query error: Unknown column 'fastival_policy_info_id' in 'where clause' - Invalid query: SELECT *
FROM `pmm_festival_policy_info`
WHERE `fastival_policy_info_id` = '1'
ERROR - 2013-09-29 17:05:24 --> Query error: Unknown column 'fastival_policy_info_id' in 'where clause' - Invalid query: SELECT *
FROM `pmm_festival_policy_info`
WHERE `fastival_policy_info_id` = '1'
ERROR - 2013-09-29 17:06:29 --> Query error: Unknown column 'fastival_policy_info_id' in 'where clause' - Invalid query: SELECT *
FROM `pmm_festival_policy_info`
WHERE `fastival_policy_info_id` = '1'
ERROR - 2013-09-29 17:06:38 --> Query error: Unknown column 'fastival_policy_info_id' in 'where clause' - Invalid query: SELECT *
FROM `pmm_festival_policy_info`
WHERE `fastival_policy_info_id` = '1'
ERROR - 2013-09-29 18:07:20 --> 404 Page Not Found --> 
ERROR - 2013-09-29 18:07:24 --> 404 Page Not Found --> 
ERROR - 2013-09-29 18:07:27 --> 404 Page Not Found --> 
ERROR - 2013-09-29 18:07:28 --> 404 Page Not Found --> 
ERROR - 2013-09-29 18:07:30 --> 404 Page Not Found --> 
ERROR - 2013-09-29 18:09:47 --> 404 Page Not Found --> User/assets
ERROR - 2013-09-29 18:09:47 --> 404 Page Not Found --> User/assets
