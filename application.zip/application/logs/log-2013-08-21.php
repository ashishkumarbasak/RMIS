<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-08-21 09:58:47 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-21 09:58:47 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-21 09:58:53 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-21 09:58:53 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-21 09:59:45 --> 404 Page Not Found --> 
ERROR - 2013-08-21 09:59:45 --> 404 Page Not Found --> 
ERROR - 2013-08-21 11:50:05 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\views\users\user_add_form.php 60
ERROR - 2013-08-21 11:50:24 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\views\users\user_add_form.php 60
ERROR - 2013-08-21 11:51:10 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\views\users\user_add_form.php 60
ERROR - 2013-08-21 11:53:36 --> Unable to load the requested class: Url
ERROR - 2013-08-21 12:15:33 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\views\users\user_add_form.php 61
ERROR - 2013-08-21 12:15:44 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\views\users\user_add_form.php 61
ERROR - 2013-08-21 12:31:40 --> 404 Page Not Found --> 
ERROR - 2013-08-21 12:31:48 --> 404 Page Not Found --> 
ERROR - 2013-08-21 12:32:34 --> 404 Page Not Found --> 
ERROR - 2013-08-21 18:51:15 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\User.php 218
ERROR - 2013-08-21 18:51:51 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\User.php 218
