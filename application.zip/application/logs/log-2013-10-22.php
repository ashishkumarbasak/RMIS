<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-10-22 10:08:13 --> 404 Page Not Found --> 
ERROR - 2013-10-22 10:08:13 --> 404 Page Not Found --> 
ERROR - 2013-10-22 11:00:26 --> 404 Page Not Found --> 
ERROR - 2013-10-22 11:00:26 --> 404 Page Not Found --> 
ERROR - 2013-10-22 11:00:27 --> 404 Page Not Found --> 
ERROR - 2013-10-22 11:03:05 --> 404 Page Not Found --> 
ERROR - 2013-10-22 11:03:06 --> 404 Page Not Found --> 
ERROR - 2013-10-22 11:03:08 --> 404 Page Not Found --> 
ERROR - 2013-10-22 11:03:08 --> 404 Page Not Found --> 
ERROR - 2013-10-22 11:08:27 --> Severity: Warning  --> require_once(http://localhost:8088/JavaBridge/java/Java.inc): failed to open stream: No connection could be made because the target machine actively refused it.
 D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\RptFixation.php 33
ERROR - 2013-10-22 11:09:39 --> 404 Page Not Found --> Vmis/Reports
ERROR - 2013-10-22 11:14:59 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 11:14:59 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 11:29:07 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 11:29:07 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:11:38 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:11:38 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:21:35 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:21:35 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:21:37 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:21:37 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:34:24 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:34:24 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:34:29 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:34:29 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:34:31 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:34:31 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:34:32 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:34:32 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:34:32 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:34:32 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:34:33 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:34:33 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:34:34 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:34:34 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:34:35 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:34:35 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:34:35 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:34:35 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:34:37 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:34:37 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:35:39 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:35:39 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:35:40 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:35:40 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:35:40 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:35:40 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:35:41 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:35:41 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:35:42 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:35:42 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:37:01 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:37:01 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:37:02 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:37:02 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:37:03 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:37:03 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:37:36 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:37:36 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:37:37 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:37:37 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:37:38 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:37:38 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:37:39 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:37:39 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:38:05 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:38:05 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:38:06 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:38:06 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:38:08 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:38:08 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:38:09 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:38:09 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:38:09 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:38:09 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:38:16 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:38:16 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:38:22 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:38:22 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:50:47 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:50:47 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:50:49 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:50:49 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:50:50 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:50:50 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:50:50 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:50:50 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:50:51 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:50:51 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:50:52 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:50:52 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:50:53 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:50:53 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:51:09 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:51:09 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:51:15 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:51:15 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:51:16 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:51:16 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:51:17 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:51:17 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:51:18 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:51:18 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:51:18 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:51:18 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:51:19 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:51:19 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:51:20 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:51:20 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:51:20 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:51:20 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:51:21 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:51:21 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:51:44 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 13:51:44 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:58:44 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
ERROR - 2013-10-22 13:58:44 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 18:34:54 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-22 18:34:54 --> 404 Page Not Found --> Pmm/nullimg_0_0_3
