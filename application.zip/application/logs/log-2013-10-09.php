<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-10-09 09:54:26 --> 404 Page Not Found --> 
ERROR - 2013-10-09 09:54:26 --> 404 Page Not Found --> 
ERROR - 2013-10-09 12:29:12 --> 404 Page Not Found --> Processalary/rollbackProcessnull
ERROR - 2013-10-09 12:29:17 --> 404 Page Not Found --> Processalary/rollbackProcessnull
ERROR - 2013-10-09 12:52:47 --> Severity: Warning  --> Missing argument 1 for Processalary::postingProcess() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 197
ERROR - 2013-10-09 17:37:50 --> Severity: Warning  --> PDOStatement::execute(): SQLSTATE[HY093]: Invalid parameter number: number of bound variables does not match number of tokens D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\models\process_model.php 568
ERROR - 2013-10-09 17:48:04 --> 404 Page Not Found --> Profile/assets
ERROR - 2013-10-09 17:48:04 --> 404 Page Not Found --> Profile/assets
ERROR - 2013-10-09 18:15:59 --> 404 Page Not Found --> Pmm/Report
