<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-11-26 12:14:45 --> 404 Page Not Found --> 
ERROR - 2013-11-26 12:14:45 --> 404 Page Not Found --> 
ERROR - 2013-11-26 12:18:35 --> 404 Page Not Found --> 
ERROR - 2013-11-26 12:18:51 --> 404 Page Not Found --> 
ERROR - 2013-11-26 12:18:52 --> 404 Page Not Found --> 
ERROR - 2013-11-26 12:22:13 --> 404 Page Not Found --> 
ERROR - 2013-11-26 12:22:14 --> 404 Page Not Found --> 
ERROR - 2013-11-26 12:22:25 --> 404 Page Not Found --> 
ERROR - 2013-11-26 12:22:25 --> 404 Page Not Found --> 
ERROR - 2013-11-26 12:24:09 --> 404 Page Not Found --> 
ERROR - 2013-11-26 12:24:09 --> 404 Page Not Found --> 
ERROR - 2013-11-26 12:31:45 --> 404 Page Not Found --> 
ERROR - 2013-11-26 12:45:34 --> Query error: Unknown column 'requisition_information_id' in 'where clause' - Invalid query: SELECT *
FROM `imis_issue_information_detail`
WHERE `requisition_information_id` = '1'
ERROR - 2013-11-26 12:46:31 --> Severity: 4096  --> Argument 1 passed to Illuminate\Database\Connection::__construct() must be an instance of PDO, instance of Template given, called in D:\Zend\Apache2\htdocs\natp_barc\vendor\cartalyst\sentry\src\Cartalyst\Sentry\Facades\ConnectionResolver.php on line 117 and defined D:\Zend\Apache2\htdocs\natp_barc\vendor\illuminate\database\Illuminate\Database\Connection.php 118
ERROR - 2013-11-26 12:50:40 --> 404 Page Not Found --> Pmm/Cpfloaninstallment
ERROR - 2013-11-26 12:53:17 --> 404 Page Not Found --> Pmm/Cpfloaninstallment
ERROR - 2013-11-26 12:55:27 --> 404 Page Not Found --> Pmm/Cpfloaninstallment
ERROR - 2013-11-26 14:05:34 --> 404 Page Not Found --> 
ERROR - 2013-11-26 14:05:52 --> 404 Page Not Found --> 
ERROR - 2013-11-26 14:05:52 --> 404 Page Not Found --> 
ERROR - 2013-11-26 16:04:34 --> 404 Page Not Found --> 
ERROR - 2013-11-26 16:04:34 --> 404 Page Not Found --> 
ERROR - 2013-11-26 17:17:54 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`natp_barc`.`vmis_vehicle_usage`, CONSTRAINT `FK_vmis_regno_vehicle_usage` FOREIGN KEY (`registration_no`) REFERENCES `vmis_vehicles` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE) - Invalid query: INSERT INTO `vmis_vehicle_usage` (`organization_id`, `requisition_number`, `duty_start_time`, `duty_end_time`, `transport_officer_id`, `driver_id`, `mileage_on_start_time`, `mileage_on_end_time`, `registration_no`, `fuel_cupon_number`, `received_qty_of_fuel`, `opening_balance_of_fuel`, `consumption_qty_of_fuel`, `closing_balance_of_fuel`, `remarks`, `total_time`, `amt_for_milage`, `amt_for_haltage`, `total_amount`, `page_no_log_book`, `created_at`, `created_by`) VALUES (1, '7', '2013-11-27 15:05:00', '2013-11-13 10:30:00', 2, 10, 0, 0, 0, '', '', '', '', '', '', 0, 0, 0, 0, '', '2013-11-26 17:17:54', '2')
ERROR - 2013-11-26 17:27:25 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 219
ERROR - 2013-11-26 17:27:25 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 219
ERROR - 2013-11-26 17:27:25 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 219
ERROR - 2013-11-26 17:27:25 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 219
ERROR - 2013-11-26 17:27:25 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 219
ERROR - 2013-11-26 17:27:25 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 219
ERROR - 2013-11-26 17:27:25 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 219
ERROR - 2013-11-26 17:27:25 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 219
ERROR - 2013-11-26 17:27:25 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 219
ERROR - 2013-11-26 17:27:38 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 219
ERROR - 2013-11-26 17:27:38 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 219
ERROR - 2013-11-26 17:27:38 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 219
ERROR - 2013-11-26 17:27:38 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 219
ERROR - 2013-11-26 17:27:38 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 219
ERROR - 2013-11-26 17:27:38 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 219
ERROR - 2013-11-26 17:27:38 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 219
ERROR - 2013-11-26 17:27:38 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 219
ERROR - 2013-11-26 17:27:38 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 219
ERROR - 2013-11-26 17:28:13 --> Severity: Warning  --> require_once(http://localhost:8088/JavaBridge/java/Java.inc): failed to open stream: No connection could be made because the target machine actively refused it.
 D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\controllers\Rptvehicle.php 56
