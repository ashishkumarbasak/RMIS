<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-10-02 10:04:11 --> 404 Page Not Found --> 
ERROR - 2013-10-02 10:04:11 --> 404 Page Not Found --> 
ERROR - 2013-10-02 13:01:34 --> Severity: Warning  --> Missing argument 1 for Salaryscalefixation::getBasicSalary() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Salaryscalefixation.php 312
ERROR - 2013-10-02 13:01:40 --> Severity: Warning  --> Missing argument 1 for Salaryscalefixation::getBasicSalary() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Salaryscalefixation.php 312
ERROR - 2013-10-02 13:03:37 --> Severity: Warning  --> Missing argument 1 for Salaryscalefixation::getBasicSalary() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Salaryscalefixation.php 312
ERROR - 2013-10-02 15:45:17 --> Query error: Unknown column 'process_month' in 'field list' - Invalid query: INSERT INTO `pmm_salary_scale_fixation` (`organization_id`, `process_month`, `process_date`, `process_for`, `process_type`, `religion`, `created_at`, `created_by`) VALUES (1, '2013-10-02', '2013-10-02', 'All', 'Salary', 'a:3:{i:0;s:2:\" 4\";i:1;s:2:\" 2\";i:2;s:2:\" 1\";}', '2013-10-02 15:45:17', '2')
ERROR - 2013-10-02 15:48:28 --> Severity: 4096  --> Argument 1 passed to Illuminate\Database\Connection::__construct() must be an instance of PDO, instance of Template given, called in D:\Zend\Apache2\htdocs\natp_barc\vendor\cartalyst\sentry\src\Cartalyst\Sentry\Facades\ConnectionResolver.php on line 117 and defined D:\Zend\Apache2\htdocs\natp_barc\vendor\illuminate\database\Illuminate\Database\Connection.php 118
ERROR - 2013-10-02 16:44:44 --> 404 Page Not Found --> 
ERROR - 2013-10-02 16:44:46 --> 404 Page Not Found --> 
