<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-11-07 10:37:06 --> 404 Page Not Found --> 
ERROR - 2013-11-07 10:37:06 --> 404 Page Not Found --> 
ERROR - 2013-11-07 10:49:16 --> 404 Page Not Found --> Rptbasicsalary/index
ERROR - 2013-11-07 14:13:33 --> 404 Page Not Found --> Pmm/Report
ERROR - 2013-11-07 15:58:53 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-07 15:58:53 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-07 15:58:53 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-07 15:58:53 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-07 15:58:53 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-07 15:58:53 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-07 15:58:53 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-07 15:58:53 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-07 15:58:53 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-07 18:27:36 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-07 18:27:36 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-07 18:27:36 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-07 18:27:36 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-07 18:27:36 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-07 18:27:36 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-07 18:27:36 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-07 18:27:36 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-07 18:27:36 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-07 18:27:41 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-07 18:27:41 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-07 18:27:41 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-07 18:27:41 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-07 18:27:41 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-07 18:27:41 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-07 18:27:41 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-07 18:27:41 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-07 18:27:41 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-07 18:28:02 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-07 18:28:02 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-07 18:28:02 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-07 18:28:02 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-07 18:28:02 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-07 18:28:02 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-07 18:28:02 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-07 18:28:02 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-07 18:28:02 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-07 18:30:10 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-07 18:30:10 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-07 18:30:10 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-07 18:30:10 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-07 18:30:10 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-07 18:30:10 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-07 18:30:10 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-07 18:30:10 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-07 18:30:10 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
