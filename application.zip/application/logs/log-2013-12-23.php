<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-12-23 00:03:44 --> Severity: Warning  --> Illegal string offset 'data' /Applications/MAMP/htdocs/RMIS/application/modules/Rmis/views/released/technology/form.php 350
ERROR - 2013-12-23 00:03:44 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:03:44 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:08:32 --> Severity: Warning  --> Illegal string offset 'data' /Applications/MAMP/htdocs/RMIS/application/modules/Rmis/views/released/technology/form.php 350
ERROR - 2013-12-23 00:08:32 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:08:32 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:09:01 --> Severity: Warning  --> Illegal string offset 'data' /Applications/MAMP/htdocs/RMIS/application/modules/Rmis/views/released/technology/form.php 350
ERROR - 2013-12-23 00:09:01 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:09:01 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:10:26 --> Query error: Unknown column 'rmis_program_informations.program_coordinator' in 'on clause' - Invalid query: SELECT `rmis_technology_release_informations`.`id`, `rmis_technology_release_informations`.`tech_knowledge_name` as `tech_release_title`, `rmis_technology_release_informations`.`version` as `tech_release_version`, `rmis_technology_release_informations`.`date` as `tech_release_date`, `rmis_technology_release_informations`.`is_relased` as `tech_release_is_rel`, `rmis_technology_release_informations`.`is_transferred` as `tech_release_is_trnsed`, `rmis_technology_release_informations`.`project_id` as `ref_id`
FROM `rmis_technology_release_informations`
LEFT JOIN `rmis_project_informations` ON `rmis_technology_release_informations`.`project_id` = `rmis_project_informations`.`project_id`
LEFT JOIN `hrm_employees` ON `rmis_program_informations`.`program_coordinator`=`hrm_employees`.`employee_id`
WHERE `rmis_technology_release_informations`.`type` = 'Project'
ERROR - 2013-12-23 00:10:28 --> Query error: Unknown column 'rmis_program_informations.program_coordinator' in 'on clause' - Invalid query: SELECT `rmis_technology_release_informations`.`id`, `rmis_technology_release_informations`.`tech_knowledge_name` as `tech_release_title`, `rmis_technology_release_informations`.`version` as `tech_release_version`, `rmis_technology_release_informations`.`date` as `tech_release_date`, `rmis_technology_release_informations`.`is_relased` as `tech_release_is_rel`, `rmis_technology_release_informations`.`is_transferred` as `tech_release_is_trnsed`, `rmis_technology_release_informations`.`project_id` as `ref_id`
FROM `rmis_technology_release_informations`
LEFT JOIN `rmis_project_informations` ON `rmis_technology_release_informations`.`project_id` = `rmis_project_informations`.`project_id`
LEFT JOIN `hrm_employees` ON `rmis_program_informations`.`program_coordinator`=`hrm_employees`.`employee_id`
WHERE `rmis_technology_release_informations`.`type` = 'Project'
ERROR - 2013-12-23 00:10:56 --> Severity: Warning  --> Illegal string offset 'data' /Applications/MAMP/htdocs/RMIS/application/modules/Rmis/views/released/technology/form.php 350
ERROR - 2013-12-23 00:10:56 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:10:56 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:11:35 --> Severity: Warning  --> Illegal string offset 'data' /Applications/MAMP/htdocs/RMIS/application/modules/Rmis/views/released/technology/form.php 350
ERROR - 2013-12-23 00:11:35 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:11:35 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:12:38 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:12:38 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:14:03 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:14:03 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:14:12 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:14:12 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:14:47 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:14:47 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:15:11 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:15:11 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:15:21 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:15:21 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:15:22 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:15:22 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:15:29 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:15:29 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:15:43 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:15:43 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:15:44 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:15:44 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:15:54 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:15:54 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:15:55 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:15:55 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:16:00 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:16:00 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:16:01 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:16:01 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:16:38 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:16:38 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:16:40 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:16:40 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:16:52 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:16:52 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:17:04 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:17:04 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:17:39 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:17:39 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:17:48 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:17:48 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:17:50 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:17:50 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:17:55 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:17:55 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:17:57 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:17:57 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:18:00 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:18:00 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:18:07 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:18:07 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:20:30 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:20:30 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:21:12 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:21:12 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:21:30 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:21:30 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:22:04 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:22:04 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:23:13 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:23:13 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:23:16 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:23:16 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:25:11 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:25:11 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:25:12 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:25:12 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:25:15 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:25:15 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:25:20 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:25:20 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:25:37 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:25:37 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:25:39 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:25:39 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:25:44 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:25:44 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:26:04 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:26:04 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:26:05 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:26:05 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:26:06 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:26:06 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:26:06 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:26:06 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:26:17 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:26:17 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:26:27 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:26:27 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:26:33 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:26:33 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:26:35 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:26:35 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:26:44 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:26:44 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:26:45 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:26:45 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:26:58 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:26:58 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:26:59 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:26:59 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:27:07 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:27:07 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:27:17 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:27:17 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:27:18 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:27:18 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:27:25 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:27:25 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:27:27 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:27:27 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:27:35 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:27:35 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:27:36 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:27:36 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:27:43 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:27:43 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:27:45 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:27:45 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:27:53 --> 404 Page Not Found --> 
ERROR - 2013-12-23 00:27:53 --> 404 Page Not Found --> 
