<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-11-06 10:13:41 --> 404 Page Not Found --> 
ERROR - 2013-11-06 10:13:41 --> 404 Page Not Found --> 
ERROR - 2013-11-06 13:55:28 --> 404 Page Not Found --> 
