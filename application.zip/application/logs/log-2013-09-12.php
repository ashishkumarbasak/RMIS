<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-09-12 09:57:55 --> 404 Page Not Found --> 
ERROR - 2013-09-12 09:57:56 --> 404 Page Not Found --> 
ERROR - 2013-09-12 13:12:00 --> Severity: Warning  --> Creating default object from empty value D:\Zend\Apache2\htdocs\natp_barc\application\modules\pmm\controllers\houserentpolicy.php 250
ERROR - 2013-09-12 13:31:49 --> Severity: Warning  --> Creating default object from empty value D:\Zend\Apache2\htdocs\natp_barc\application\modules\pmm\controllers\houserentpolicy.php 219
ERROR - 2013-09-12 13:31:49 --> Severity: Warning  --> Creating default object from empty value D:\Zend\Apache2\htdocs\natp_barc\application\modules\pmm\controllers\houserentpolicy.php 223
ERROR - 2013-09-12 14:50:36 --> 404 Page Not Found --> 
ERROR - 2013-09-12 14:50:37 --> 404 Page Not Found --> 
ERROR - 2013-09-12 14:54:17 --> 404 Page Not Found --> 
ERROR - 2013-09-12 14:55:44 --> 404 Page Not Found --> 
ERROR - 2013-09-12 14:56:07 --> 404 Page Not Found --> 
ERROR - 2013-09-12 14:56:15 --> 404 Page Not Found --> 
ERROR - 2013-09-12 14:56:22 --> 404 Page Not Found --> 
ERROR - 2013-09-12 15:23:30 --> 404 Page Not Found --> Salaryscalefixation/index
ERROR - 2013-09-12 15:23:33 --> 404 Page Not Found --> Pmm/charge_allowance
ERROR - 2013-09-12 16:55:43 --> 404 Page Not Found --> 
ERROR - 2013-09-12 18:00:40 --> 404 Page Not Found --> 
