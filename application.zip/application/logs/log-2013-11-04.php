<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-11-04 09:51:38 --> 404 Page Not Found --> 
ERROR - 2013-11-04 09:51:38 --> 404 Page Not Found --> 
ERROR - 2013-11-04 10:32:47 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-11-04 10:32:47 --> 404 Page Not Found --> Pmm/nullimg_0_0_0
ERROR - 2013-11-04 11:46:31 --> 404 Page Not Found --> 
ERROR - 2013-11-04 11:46:35 --> 404 Page Not Found --> 
ERROR - 2013-11-04 14:04:50 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-11-04 14:04:50 --> 404 Page Not Found --> Pmm/nullimg_0_0_0
ERROR - 2013-11-04 15:27:28 --> Severity: Warning  --> array_merge(): Argument #1 is not an array D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Rptgrossnet.php 73
ERROR - 2013-11-04 18:02:46 --> 404 Page Not Found --> User/assets
ERROR - 2013-11-04 18:02:46 --> 404 Page Not Found --> User/assets
