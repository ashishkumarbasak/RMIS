<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-11-27 11:34:08 --> 404 Page Not Found --> 
ERROR - 2013-11-27 11:34:08 --> 404 Page Not Found --> 
ERROR - 2013-11-27 15:55:41 --> Could not find the language line "form_validation_"
ERROR - 2013-11-27 15:55:41 --> Could not find the language line "form_validation_"
ERROR - 2013-11-27 15:56:05 --> Could not find the language line "form_validation_"
ERROR - 2013-11-27 15:56:05 --> Could not find the language line "form_validation_"
ERROR - 2013-11-27 15:57:02 --> Could not find the language line "form_validation_"
ERROR - 2013-11-27 15:57:02 --> Could not find the language line "form_validation_"
ERROR - 2013-11-27 15:57:48 --> Query error: Unknown column 'approval_reference_no' in 'where clause' - Invalid query: SELECT `id`
FROM `cpf_loan_sanction`
WHERE `approval_reference_no` = 'sas'
 LIMIT 1
ERROR - 2013-11-27 15:57:49 --> Query error: Unknown column 'approval_reference_no' in 'where clause' - Invalid query: SELECT `id`
FROM `cpf_loan_sanction`
WHERE `approval_reference_no` = 'sas'
 LIMIT 1
ERROR - 2013-11-27 15:57:50 --> Query error: Unknown column 'approval_reference_no' in 'where clause' - Invalid query: SELECT `id`
FROM `cpf_loan_sanction`
WHERE `approval_reference_no` = 'sas'
 LIMIT 1
ERROR - 2013-11-27 15:58:02 --> Severity: 4096  --> Argument 1 passed to Illuminate\Database\Connection::__construct() must be an instance of PDO, instance of Template given, called in D:\Zend\Apache2\htdocs\natp_barc\vendor\cartalyst\sentry\src\Cartalyst\Sentry\Facades\ConnectionResolver.php on line 117 and defined D:\Zend\Apache2\htdocs\natp_barc\vendor\illuminate\database\Illuminate\Database\Connection.php 118
ERROR - 2013-11-27 15:58:09 --> Severity: 4096  --> Argument 1 passed to Illuminate\Database\Connection::__construct() must be an instance of PDO, instance of Template given, called in D:\Zend\Apache2\htdocs\natp_barc\vendor\cartalyst\sentry\src\Cartalyst\Sentry\Facades\ConnectionResolver.php on line 117 and defined D:\Zend\Apache2\htdocs\natp_barc\vendor\illuminate\database\Illuminate\Database\Connection.php 118
ERROR - 2013-11-27 15:58:13 --> Severity: 4096  --> Argument 1 passed to Illuminate\Database\Connection::__construct() must be an instance of PDO, instance of Template given, called in D:\Zend\Apache2\htdocs\natp_barc\vendor\cartalyst\sentry\src\Cartalyst\Sentry\Facades\ConnectionResolver.php on line 117 and defined D:\Zend\Apache2\htdocs\natp_barc\vendor\illuminate\database\Illuminate\Database\Connection.php 118
ERROR - 2013-11-27 15:58:55 --> Query error: Unknown column 'approval_reference_no' in 'where clause' - Invalid query: SELECT `id`
FROM `cpf_loan_sanction`
WHERE `approval_reference_no` = '323'
 LIMIT 1
ERROR - 2013-11-27 17:01:11 --> Severity: Warning  --> require_once(http://localhost:8088/JavaBridge/java/Java.inc): failed to open stream: No connection could be made because the target machine actively refused it.
 D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\controllers\Rptmaintenance.php 57
ERROR - 2013-11-27 17:48:57 --> Query error: Unknown column 'hremp_id' in 'where clause' - Invalid query: SELECT `id`
FROM `cpf_loan_sanction`
WHERE `reference_no` = 'Q111'
AND `hremp_id` = '9'
 LIMIT 1
ERROR - 2013-11-27 17:49:05 --> Query error: Unknown column 'hremp_id' in 'where clause' - Invalid query: SELECT `id`
FROM `cpf_loan_sanction`
WHERE `reference_no` = 'Q111'
AND `hremp_id` = '9'
 LIMIT 1
ERROR - 2013-11-27 17:49:15 --> Query error: Unknown column 'hremp_id' in 'where clause' - Invalid query: SELECT `id`
FROM `cpf_loan_sanction`
WHERE `reference_no` = 'Q111'
AND `hremp_id` = '9'
 LIMIT 1
ERROR - 2013-11-27 17:50:27 --> Severity: 4096  --> Argument 1 passed to Illuminate\Database\Connection::__construct() must be an instance of PDO, instance of Template given, called in D:\Zend\Apache2\htdocs\natp_barc\vendor\cartalyst\sentry\src\Cartalyst\Sentry\Facades\ConnectionResolver.php on line 117 and defined D:\Zend\Apache2\htdocs\natp_barc\vendor\illuminate\database\Illuminate\Database\Connection.php 118
ERROR - 2013-11-27 17:50:32 --> Severity: 4096  --> Argument 1 passed to Illuminate\Database\Connection::__construct() must be an instance of PDO, instance of Template given, called in D:\Zend\Apache2\htdocs\natp_barc\vendor\cartalyst\sentry\src\Cartalyst\Sentry\Facades\ConnectionResolver.php on line 117 and defined D:\Zend\Apache2\htdocs\natp_barc\vendor\illuminate\database\Illuminate\Database\Connection.php 118
ERROR - 2013-11-27 17:50:35 --> Severity: 4096  --> Argument 1 passed to Illuminate\Database\Connection::__construct() must be an instance of PDO, instance of Template given, called in D:\Zend\Apache2\htdocs\natp_barc\vendor\cartalyst\sentry\src\Cartalyst\Sentry\Facades\ConnectionResolver.php on line 117 and defined D:\Zend\Apache2\htdocs\natp_barc\vendor\illuminate\database\Illuminate\Database\Connection.php 118
