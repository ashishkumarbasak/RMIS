<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-11-21 10:06:47 --> 404 Page Not Found --> 
ERROR - 2013-11-21 10:06:47 --> 404 Page Not Found --> 
ERROR - 2013-11-21 11:21:57 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`natp_barc`.`pmm_house_maintance_policy`, CONSTRAINT `FK_pmm_house_maintance_policy` FOREIGN KEY (`salary_head_id`) REFERENCES `pmm_salary_head` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE) - Invalid query: DELETE FROM `pmm_salary_head`
WHERE `id` = 1
ERROR - 2013-11-21 11:22:46 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`natp_barc`.`pmm_house_maintance_policy`, CONSTRAINT `FK_pmm_house_maintance_policy` FOREIGN KEY (`salary_head_id`) REFERENCES `pmm_salary_head` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE) - Invalid query: DELETE FROM `pmm_salary_head`
WHERE `id` = 1
ERROR - 2013-11-21 11:23:19 --> Severity: 4096  --> Argument 1 passed to Illuminate\Database\Connection::__construct() must be an instance of PDO, instance of Template given, called in D:\Zend\Apache2\htdocs\natp_barc\vendor\cartalyst\sentry\src\Cartalyst\Sentry\Facades\ConnectionResolver.php on line 117 and defined D:\Zend\Apache2\htdocs\natp_barc\vendor\illuminate\database\Illuminate\Database\Connection.php 118
ERROR - 2013-11-21 11:23:26 --> Severity: 4096  --> Argument 1 passed to Illuminate\Database\Connection::__construct() must be an instance of PDO, instance of Template given, called in D:\Zend\Apache2\htdocs\natp_barc\vendor\cartalyst\sentry\src\Cartalyst\Sentry\Facades\ConnectionResolver.php on line 117 and defined D:\Zend\Apache2\htdocs\natp_barc\vendor\illuminate\database\Illuminate\Database\Connection.php 118
ERROR - 2013-11-21 11:23:37 --> Severity: 4096  --> Object of class stdClass could not be converted to string D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Salaryhead.php 240
ERROR - 2013-11-21 11:29:54 --> Severity: Warning  --> Missing argument 1 for Kendo\UI\Grid::editable(), called in D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Salaryhead.php on line 195 and defined D:\Zend\Apache2\htdocs\natp_barc\application\third_party\kendoui\UI\Grid.php 54
ERROR - 2013-11-21 11:29:56 --> Severity: Warning  --> Missing argument 1 for Kendo\UI\Grid::editable(), called in D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Salaryhead.php on line 195 and defined D:\Zend\Apache2\htdocs\natp_barc\application\third_party\kendoui\UI\Grid.php 54
ERROR - 2013-11-21 11:30:33 --> Severity: Warning  --> Missing argument 1 for Kendo\UI\Grid::editable(), called in D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Salaryhead.php on line 195 and defined D:\Zend\Apache2\htdocs\natp_barc\application\third_party\kendoui\UI\Grid.php 54
ERROR - 2013-11-21 12:04:53 --> Severity: Warning  --> Creating default object from empty value D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Salaryhead.php 224
ERROR - 2013-11-21 12:05:46 --> Severity: Warning  --> Creating default object from empty value D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Salaryhead.php 224
ERROR - 2013-11-21 15:04:14 --> Severity: Warning  --> Creating default object from empty value D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Salaryhead.php 224
ERROR - 2013-11-21 15:04:36 --> Severity: Warning  --> Creating default object from empty value D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Salaryhead.php 224
ERROR - 2013-11-21 15:05:37 --> Severity: Warning  --> Creating default object from empty value D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Salaryhead.php 224
ERROR - 2013-11-21 16:46:59 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\setup\vehicle_type.php 43
ERROR - 2013-11-21 16:47:03 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\setup\vehicle_type.php 43
ERROR - 2013-11-21 17:28:17 --> 404 Page Not Found --> 
ERROR - 2013-11-21 19:20:25 --> Severity: Warning  --> Illegal string offset 'request_number' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\vehicle_usage_form.php 39
ERROR - 2013-11-21 19:20:25 --> Severity: Warning  --> Illegal string offset 'request_number' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\vehicle_usage_form.php 41
ERROR - 2013-11-21 19:20:25 --> Severity: Warning  --> Illegal string offset 'request_number' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\vehicle_usage_form.php 41
