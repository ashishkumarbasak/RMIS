<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-11-24 10:40:06 --> 404 Page Not Found --> 
ERROR - 2013-11-24 10:40:06 --> 404 Page Not Found --> 
ERROR - 2013-11-24 16:55:48 --> 404 Page Not Found --> 
ERROR - 2013-11-24 16:56:10 --> Severity: Warning  --> require_once(http://localhost:8088/JavaBridge/java/Java.inc): failed to open stream: No connection could be made because the target machine actively refused it.
 D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\controllers\Rptlogbook.php 48
ERROR - 2013-11-24 17:51:24 --> 404 Page Not Found --> User/assets
ERROR - 2013-11-24 17:51:24 --> 404 Page Not Found --> User/assets
