<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-10-24 09:47:20 --> 404 Page Not Found --> 
ERROR - 2013-10-24 09:47:20 --> 404 Page Not Found --> 
ERROR - 2013-10-24 09:47:36 --> Severity: Warning  --> require_once(http://localhost:8088/JavaBridge/java/Java.inc): failed to open stream: No connection could be made because the target machine actively refused it.
 D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Rptpayslip.php 49
ERROR - 2013-10-24 09:54:41 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-24 09:54:41 --> 404 Page Not Found --> Pmm/nullimg_0_0_0
ERROR - 2013-10-24 10:07:45 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-24 10:07:45 --> 404 Page Not Found --> Pmm/nullimg_0_0_0
ERROR - 2013-10-24 10:12:11 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-24 10:12:11 --> 404 Page Not Found --> Pmm/nullimg_0_0_0
ERROR - 2013-10-24 10:13:56 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-24 10:13:56 --> 404 Page Not Found --> Pmm/nullimg_0_0_0
ERROR - 2013-10-24 10:14:08 --> 404 Page Not Found --> Pmm/nullimg_0_0_0
ERROR - 2013-10-24 10:14:08 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-24 10:14:25 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-24 10:14:25 --> 404 Page Not Found --> Pmm/nullimg_0_0_0
ERROR - 2013-10-24 10:14:31 --> 404 Page Not Found --> Pmm/nullimg_0_0_0
ERROR - 2013-10-24 10:14:31 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-24 10:28:02 --> 404 Page Not Found --> User/assets
ERROR - 2013-10-24 10:28:02 --> 404 Page Not Found --> User/assets
ERROR - 2013-10-24 15:38:06 --> 404 Page Not Found --> Pmm/nullimg_0_0_0
ERROR - 2013-10-24 15:38:06 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-24 15:39:46 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-24 15:39:46 --> 404 Page Not Found --> Pmm/nullimg_0_0_0
ERROR - 2013-10-24 16:40:05 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-24 16:40:05 --> 404 Page Not Found --> Pmm/nullimg_0_0_0
ERROR - 2013-10-24 17:19:30 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-24 17:19:31 --> 404 Page Not Found --> Pmm/nullimg_0_0_0
ERROR - 2013-10-24 17:19:34 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-24 17:19:34 --> 404 Page Not Found --> Pmm/nullimg_0_0_0
