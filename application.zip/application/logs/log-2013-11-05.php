<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-11-05 10:12:53 --> 404 Page Not Found --> 
ERROR - 2013-11-05 10:12:53 --> 404 Page Not Found --> 
ERROR - 2013-11-05 10:31:40 --> Severity: Warning  --> fsockopen(): unable to connect to localhost:8088 (No connection could be made because the target machine actively refused it.
) http://localhost:8088/JavaBridge/java/Java.inc 994
ERROR - 2013-11-05 10:35:20 --> Severity: User Error  --> Broken local connection handle http://localhost:8088/JavaBridge/java/Java.inc 869
ERROR - 2013-11-05 10:35:20 --> Severity: Warning  --> fread(): 6 is not a valid stream resource http://localhost:8088/JavaBridge/java/Java.inc 817
ERROR - 2013-11-05 10:35:20 --> Severity: Warning  --> fclose(): 6 is not a valid stream resource http://localhost:8088/JavaBridge/java/Java.inc 820
ERROR - 2013-11-05 10:35:20 --> Severity: User Error  --> Broken local connection handle http://localhost:8088/JavaBridge/java/Java.inc 869
ERROR - 2013-11-05 10:35:33 --> Severity: User Error  --> Broken local connection handle http://localhost:8088/JavaBridge/java/Java.inc 869
ERROR - 2013-11-05 10:35:33 --> Severity: Warning  --> fread(): 6 is not a valid stream resource http://localhost:8088/JavaBridge/java/Java.inc 817
ERROR - 2013-11-05 10:35:33 --> Severity: Warning  --> fclose(): 6 is not a valid stream resource http://localhost:8088/JavaBridge/java/Java.inc 820
ERROR - 2013-11-05 10:35:33 --> Severity: User Error  --> Broken local connection handle http://localhost:8088/JavaBridge/java/Java.inc 869
ERROR - 2013-11-05 10:36:01 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-11-05 10:36:01 --> 404 Page Not Found --> Pmm/nullimg_0_0_0
ERROR - 2013-11-05 12:10:41 --> Severity: User Error  --> Broken local connection handle http://localhost:8088/JavaBridge/java/Java.inc 869
ERROR - 2013-11-05 12:10:41 --> Severity: Warning  --> fread(): 6 is not a valid stream resource http://localhost:8088/JavaBridge/java/Java.inc 817
ERROR - 2013-11-05 12:10:41 --> Severity: Warning  --> fclose(): 6 is not a valid stream resource http://localhost:8088/JavaBridge/java/Java.inc 820
ERROR - 2013-11-05 12:10:41 --> Severity: User Error  --> Broken local connection handle http://localhost:8088/JavaBridge/java/Java.inc 869
