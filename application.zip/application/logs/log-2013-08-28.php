<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-08-28 09:44:25 --> 404 Page Not Found --> 
ERROR - 2013-08-28 09:44:25 --> 404 Page Not Found --> 
ERROR - 2013-08-28 10:07:57 --> 404 Page Not Found --> Profile/assets
ERROR - 2013-08-28 10:07:57 --> 404 Page Not Found --> Profile/assets
ERROR - 2013-08-28 10:42:20 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\views\users\login.php 25
ERROR - 2013-08-28 11:14:42 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-28 11:14:42 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-28 11:14:56 --> 404 Page Not Found --> User/menu
ERROR - 2013-08-28 11:16:04 --> 404 Page Not Found --> User/login.html
ERROR - 2013-08-28 11:55:26 --> 404 Page Not Found --> User/menu
ERROR - 2013-08-28 11:58:46 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-28 11:58:46 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-28 15:14:49 --> 404 Page Not Found --> 
ERROR - 2013-08-28 15:14:57 --> 404 Page Not Found --> 
ERROR - 2013-08-28 15:15:15 --> 404 Page Not Found --> 
ERROR - 2013-08-28 15:15:21 --> 404 Page Not Found --> 
ERROR - 2013-08-28 15:15:21 --> 404 Page Not Found --> 
ERROR - 2013-08-28 15:15:22 --> 404 Page Not Found --> 
ERROR - 2013-08-28 15:15:23 --> 404 Page Not Found --> 
ERROR - 2013-08-28 15:15:33 --> 404 Page Not Found --> 
ERROR - 2013-08-28 15:25:55 --> 404 Page Not Found --> 
ERROR - 2013-08-28 15:25:56 --> 404 Page Not Found --> 
ERROR - 2013-08-28 15:25:57 --> 404 Page Not Found --> 
ERROR - 2013-08-28 15:25:57 --> 404 Page Not Found --> 
ERROR - 2013-08-28 15:25:58 --> 404 Page Not Found --> 
ERROR - 2013-08-28 15:45:37 --> 404 Page Not Found --> 
ERROR - 2013-08-28 15:54:03 --> 404 Page Not Found --> User/menu
ERROR - 2013-08-28 16:00:52 --> 404 Page Not Found --> User/login.html
ERROR - 2013-08-28 17:02:38 --> 404 Page Not Found --> 
