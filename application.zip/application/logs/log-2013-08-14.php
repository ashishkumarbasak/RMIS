<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-08-14 09:51:13 --> 404 Page Not Found --> 
ERROR - 2013-08-14 09:51:14 --> 404 Page Not Found --> 
ERROR - 2013-08-14 09:51:19 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-14 09:51:19 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-14 10:28:51 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-14 10:28:57 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-14 10:29:11 --> 404 Page Not Found --> 
ERROR - 2013-08-14 10:29:28 --> 404 Page Not Found --> 
ERROR - 2013-08-14 10:29:30 --> 404 Page Not Found --> 
ERROR - 2013-08-14 10:29:57 --> 404 Page Not Found --> 
ERROR - 2013-08-14 10:30:01 --> 404 Page Not Found --> 
ERROR - 2013-08-14 10:31:13 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-14 10:31:17 --> 404 Page Not Found --> 
ERROR - 2013-08-14 10:31:21 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-14 10:44:04 --> 404 Page Not Found --> User/login.html
ERROR - 2013-08-14 11:06:00 --> Severity: Notice  --> Undefined property: CI::$user_model D:\Zend\Apache2\htdocs\natp_barc\application\third_party\MX\Controller.php 58
ERROR - 2013-08-14 11:06:00 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Module.php 162
ERROR - 2013-08-14 11:10:21 --> Severity: Notice  --> Undefined property: CI::$modulemodel D:\Zend\Apache2\htdocs\natp_barc\application\third_party\MX\Controller.php 58
ERROR - 2013-08-14 11:10:21 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Module.php 163
ERROR - 2013-08-14 11:11:13 --> Severity: Notice  --> Undefined property: CI::$modulemodel D:\Zend\Apache2\htdocs\natp_barc\application\third_party\MX\Controller.php 58
ERROR - 2013-08-14 11:11:13 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Module.php 163
ERROR - 2013-08-14 11:12:44 --> Severity: Notice  --> Undefined property: CI::$modulemodel D:\Zend\Apache2\htdocs\natp_barc\application\third_party\MX\Controller.php 58
ERROR - 2013-08-14 11:12:44 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Module.php 160
ERROR - 2013-08-14 11:13:10 --> Severity: Notice  --> Undefined property: CI::$modulemodel D:\Zend\Apache2\htdocs\natp_barc\application\third_party\MX\Controller.php 58
ERROR - 2013-08-14 11:13:10 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Module.php 160
ERROR - 2013-08-14 11:15:53 --> Severity: Notice  --> Undefined property: CI::$modulemodel D:\Zend\Apache2\htdocs\natp_barc\application\third_party\MX\Controller.php 58
ERROR - 2013-08-14 11:15:53 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Module.php 164
ERROR - 2013-08-14 11:17:06 --> Severity: Notice  --> Undefined property: CI::$modulemodel D:\Zend\Apache2\htdocs\natp_barc\application\third_party\MX\Controller.php 58
ERROR - 2013-08-14 11:17:06 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Module.php 164
ERROR - 2013-08-14 11:17:34 --> Severity: Notice  --> Undefined property: CI::$modulemodel D:\Zend\Apache2\htdocs\natp_barc\application\third_party\MX\Controller.php 58
ERROR - 2013-08-14 11:17:34 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Module.php 164
ERROR - 2013-08-14 11:18:33 --> Severity: Notice  --> Undefined property: CI::$modulemodel D:\Zend\Apache2\htdocs\natp_barc\application\third_party\MX\Controller.php 58
ERROR - 2013-08-14 11:18:33 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Module.php 165
ERROR - 2013-08-14 11:18:49 --> Severity: Notice  --> Undefined property: CI::$modulemodel D:\Zend\Apache2\htdocs\natp_barc\application\third_party\MX\Controller.php 58
ERROR - 2013-08-14 11:18:49 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Module.php 165
ERROR - 2013-08-14 11:25:03 --> Severity: Notice  --> Undefined property: CI::$modulemodel D:\Zend\Apache2\htdocs\natp_barc\application\third_party\MX\Controller.php 58
ERROR - 2013-08-14 11:25:03 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Module.php 165
ERROR - 2013-08-14 11:26:15 --> Severity: Notice  --> Undefined property: CI::$modulemodel D:\Zend\Apache2\htdocs\natp_barc\application\third_party\MX\Controller.php 58
ERROR - 2013-08-14 11:26:15 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Module.php 165
ERROR - 2013-08-14 11:26:15 --> Severity: Notice  --> Undefined property: CI::$modulemodel D:\Zend\Apache2\htdocs\natp_barc\application\third_party\MX\Controller.php 58
ERROR - 2013-08-14 11:27:20 --> Severity: Notice  --> Undefined property: CI::$modulemodel D:\Zend\Apache2\htdocs\natp_barc\application\third_party\MX\Controller.php 58
ERROR - 2013-08-14 11:27:20 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Module.php 165
ERROR - 2013-08-14 11:27:20 --> Severity: Notice  --> Undefined property: CI::$modulemodel D:\Zend\Apache2\htdocs\natp_barc\application\third_party\MX\Controller.php 58
ERROR - 2013-08-14 11:28:03 --> Severity: Notice  --> Undefined property: CI::$modulemodel D:\Zend\Apache2\htdocs\natp_barc\application\third_party\MX\Controller.php 58
ERROR - 2013-08-14 11:28:03 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Module.php 165
ERROR - 2013-08-14 11:28:03 --> Severity: Notice  --> Undefined property: CI::$modulemodel D:\Zend\Apache2\htdocs\natp_barc\application\third_party\MX\Controller.php 58
ERROR - 2013-08-14 11:30:13 --> Severity: Notice  --> Undefined property: CI::$modulemodel D:\Zend\Apache2\htdocs\natp_barc\application\third_party\MX\Controller.php 58
ERROR - 2013-08-14 11:30:13 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Module.php 165
ERROR - 2013-08-14 11:30:13 --> Severity: Notice  --> Undefined property: CI::$modulemodel D:\Zend\Apache2\htdocs\natp_barc\application\third_party\MX\Controller.php 58
ERROR - 2013-08-14 11:30:37 --> Severity: Notice  --> Undefined property: CI::$modulemodel D:\Zend\Apache2\htdocs\natp_barc\application\third_party\MX\Controller.php 58
ERROR - 2013-08-14 11:30:37 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Module.php 165
ERROR - 2013-08-14 11:30:37 --> Severity: Notice  --> Undefined property: CI::$modulemodel D:\Zend\Apache2\htdocs\natp_barc\application\third_party\MX\Controller.php 58
ERROR - 2013-08-14 11:31:16 --> Severity: Notice  --> Undefined property: CI::$modulemodel D:\Zend\Apache2\htdocs\natp_barc\application\third_party\MX\Controller.php 58
ERROR - 2013-08-14 11:31:16 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Module.php 165
ERROR - 2013-08-14 11:31:16 --> Severity: Notice  --> Undefined property: CI::$modulemodel D:\Zend\Apache2\htdocs\natp_barc\application\third_party\MX\Controller.php 58
ERROR - 2013-08-14 11:31:42 --> Severity: Notice  --> Undefined property: CI::$modulemodel D:\Zend\Apache2\htdocs\natp_barc\application\third_party\MX\Controller.php 58
ERROR - 2013-08-14 11:31:42 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Module.php 165
ERROR - 2013-08-14 11:31:42 --> Severity: Notice  --> Undefined property: CI::$modulemodel D:\Zend\Apache2\htdocs\natp_barc\application\third_party\MX\Controller.php 58
ERROR - 2013-08-14 11:45:26 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 11:45:36 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 11:46:44 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 11:47:30 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 11:48:14 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 11:51:38 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 11:58:04 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 11:59:51 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 12:04:33 --> 404 Page Not Found --> User/login.html
ERROR - 2013-08-14 12:08:51 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 12:12:54 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 12:17:05 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 12:17:23 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 12:19:16 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 12:19:32 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 12:21:46 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 12:22:36 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 12:22:46 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 12:26:59 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 12:45:50 --> 404 Page Not Found --> 
ERROR - 2013-08-14 12:45:50 --> 404 Page Not Found --> 
ERROR - 2013-08-14 12:45:50 --> 404 Page Not Found --> 
ERROR - 2013-08-14 12:45:50 --> 404 Page Not Found --> 
ERROR - 2013-08-14 12:45:51 --> 404 Page Not Found --> 
ERROR - 2013-08-14 12:45:51 --> 404 Page Not Found --> 
ERROR - 2013-08-14 12:45:51 --> 404 Page Not Found --> 
ERROR - 2013-08-14 12:45:51 --> 404 Page Not Found --> 
ERROR - 2013-08-14 12:46:23 --> 404 Page Not Found --> 
ERROR - 2013-08-14 12:46:23 --> 404 Page Not Found --> 
ERROR - 2013-08-14 12:46:23 --> 404 Page Not Found --> 
ERROR - 2013-08-14 12:46:23 --> 404 Page Not Found --> 
ERROR - 2013-08-14 12:46:23 --> 404 Page Not Found --> 
ERROR - 2013-08-14 12:46:23 --> 404 Page Not Found --> 
ERROR - 2013-08-14 12:46:23 --> 404 Page Not Found --> 
ERROR - 2013-08-14 12:46:23 --> 404 Page Not Found --> 
ERROR - 2013-08-14 12:47:27 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-14 12:49:40 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-14 12:49:44 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-14 12:49:46 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-14 12:53:57 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 12:55:38 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 12:56:00 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 12:56:22 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 12:59:14 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 12:59:18 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 12:59:39 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 12:59:39 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 12:59:40 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 13:53:47 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 13:53:48 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 13:53:49 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 13:53:50 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 13:53:51 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 13:56:23 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 13:56:24 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 13:56:25 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 13:56:25 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 13:56:30 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 13:56:33 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 13:56:34 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 13:56:35 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 13:56:38 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 13:56:42 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 14:02:52 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-14 15:03:37 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 15:03:37 --> Query error: Unknown column 'module_name.id' in 'field list' - Invalid query: SELECT `module_name`.`id`
FROM `modules`
WHERE `module_name`.`id` = 'aaa'
 LIMIT 1
ERROR - 2013-08-14 15:04:31 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 15:04:31 --> Query error: Unknown column 'module_name.id.4' in 'field list' - Invalid query: SELECT `module_name`.`id`.`4`
FROM `modules`
WHERE `module_name`.`id`.`4` = 'aaa'
 LIMIT 1
ERROR - 2013-08-14 15:05:12 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 15:05:16 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 15:05:20 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 15:05:37 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 15:05:57 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 15:07:13 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 15:07:28 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 15:17:15 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 15:17:22 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 15:19:24 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 15:26:16 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 15:46:19 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-14 15:46:25 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-14 15:46:35 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 15:46:39 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 15:46:42 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 15:47:00 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 15:47:04 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-14 15:47:09 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-14 15:47:25 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 15:49:01 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-14 15:49:08 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-14 15:55:36 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-14 15:55:49 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 434
ERROR - 2013-08-14 15:55:49 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 434
ERROR - 2013-08-14 15:55:49 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 434
ERROR - 2013-08-14 15:55:49 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 438
ERROR - 2013-08-14 15:55:59 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 15:59:10 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-14 15:59:24 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-14 15:59:31 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 15:59:32 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 15:59:32 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 15:59:32 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 15:59:32 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 15:59:32 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 15:59:33 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 16:00:58 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-14 16:01:17 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-14 16:02:25 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-14 16:04:08 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-14 16:04:40 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-14 16:04:49 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-14 16:06:28 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-14 16:07:10 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-14 16:07:16 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 434
ERROR - 2013-08-14 16:07:16 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 434
ERROR - 2013-08-14 16:07:16 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 434
ERROR - 2013-08-14 16:07:16 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 438
ERROR - 2013-08-14 16:07:21 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 434
ERROR - 2013-08-14 16:07:21 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 434
ERROR - 2013-08-14 16:07:21 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 434
ERROR - 2013-08-14 16:07:21 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 438
ERROR - 2013-08-14 16:09:44 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-14 16:10:21 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 434
ERROR - 2013-08-14 16:10:21 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 434
ERROR - 2013-08-14 16:10:21 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 434
ERROR - 2013-08-14 16:10:21 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 438
ERROR - 2013-08-14 16:24:01 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 16:26:31 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 16:28:42 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 16:32:18 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 17:01:48 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 17:01:49 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 17:03:35 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 17:03:43 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 17:04:27 --> Severity: Notice  --> Undefined property: CI::$validation D:\Zend\Apache2\htdocs\natp_barc\system\core\Model.php 63
ERROR - 2013-08-14 17:18:37 --> 404 Page Not Found --> 
ERROR - 2013-08-14 17:18:45 --> 404 Page Not Found --> 
ERROR - 2013-08-14 17:18:46 --> 404 Page Not Found --> 
ERROR - 2013-08-14 17:18:46 --> 404 Page Not Found --> 
ERROR - 2013-08-14 17:18:46 --> 404 Page Not Found --> 
ERROR - 2013-08-14 17:18:46 --> 404 Page Not Found --> 
ERROR - 2013-08-14 17:22:26 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-14 17:29:35 --> Severity: Warning  --> implode(): Invalid arguments passed D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 378
ERROR - 2013-08-14 17:29:35 --> Severity: Warning  --> implode(): Invalid arguments passed D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 383
ERROR - 2013-08-14 17:29:42 --> Severity: Warning  --> implode(): Invalid arguments passed D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 378
ERROR - 2013-08-14 17:29:42 --> Severity: Warning  --> implode(): Invalid arguments passed D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 383
ERROR - 2013-08-14 17:35:03 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 362
ERROR - 2013-08-14 17:45:40 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-14 17:49:55 --> Severity: 4096  --> Object of class DateTime could not be converted to string D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 389
ERROR - 2013-08-14 17:53:46 --> Severity: 4096  --> Object of class DateTime could not be converted to string D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 389
ERROR - 2013-08-14 18:19:00 --> Severity: Warning  --> array_merge(): Argument #1 is not an array D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 76
ERROR - 2013-08-14 18:19:02 --> Severity: Warning  --> array_merge(): Argument #1 is not an array D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 76
ERROR - 2013-08-14 18:21:57 --> Severity: Warning  --> array_merge(): Argument #1 is not an array D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 76
ERROR - 2013-08-14 18:37:28 --> Severity: Warning  --> Creating default object from empty value D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Module.php 150
ERROR - 2013-08-14 18:37:28 --> Severity: Warning  --> array_merge(): Argument #1 is not an array D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 76
ERROR - 2013-08-14 18:37:53 --> Severity: Warning  --> Creating default object from empty value D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Module.php 150
