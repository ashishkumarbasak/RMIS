<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-11-11 10:40:13 --> 404 Page Not Found --> 
ERROR - 2013-11-11 10:40:13 --> 404 Page Not Found --> 
ERROR - 2013-11-11 15:40:52 --> 404 Page Not Found --> 
ERROR - 2013-11-11 15:41:03 --> 404 Page Not Found --> User/assets
ERROR - 2013-11-11 15:41:03 --> 404 Page Not Found --> User/assets
ERROR - 2013-11-11 16:22:46 --> 404 Page Not Found --> 
ERROR - 2013-11-11 16:44:03 --> 404 Page Not Found --> 
ERROR - 2013-11-11 16:45:12 --> 404 Page Not Found --> 
ERROR - 2013-11-11 16:45:12 --> 404 Page Not Found --> 
