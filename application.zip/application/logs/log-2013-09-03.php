<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-09-03 09:53:16 --> 404 Page Not Found --> 
ERROR - 2013-09-03 09:53:16 --> 404 Page Not Found --> 
ERROR - 2013-09-03 10:50:22 --> 404 Page Not Found --> 
ERROR - 2013-09-03 10:50:36 --> 404 Page Not Found --> 
ERROR - 2013-09-03 10:51:07 --> 404 Page Not Found --> 
ERROR - 2013-09-03 10:51:10 --> 404 Page Not Found --> 
ERROR - 2013-09-03 10:55:14 --> 404 Page Not Found --> 
ERROR - 2013-09-03 10:55:18 --> 404 Page Not Found --> 
ERROR - 2013-09-03 10:55:21 --> 404 Page Not Found --> 
ERROR - 2013-09-03 10:55:22 --> 404 Page Not Found --> 
ERROR - 2013-09-03 10:55:24 --> 404 Page Not Found --> 
ERROR - 2013-09-03 10:56:52 --> 404 Page Not Found --> 
ERROR - 2013-09-03 11:18:39 --> 404 Page Not Found --> 
ERROR - 2013-09-03 11:18:45 --> 404 Page Not Found --> 
ERROR - 2013-09-03 11:18:49 --> 404 Page Not Found --> 
ERROR - 2013-09-03 11:19:34 --> 404 Page Not Found --> 
ERROR - 2013-09-03 11:19:43 --> 404 Page Not Found --> 
ERROR - 2013-09-03 11:28:55 --> 404 Page Not Found --> 
ERROR - 2013-09-03 11:29:18 --> 404 Page Not Found --> 
ERROR - 2013-09-03 11:29:22 --> 404 Page Not Found --> 
ERROR - 2013-09-03 11:29:42 --> 404 Page Not Found --> 
ERROR - 2013-09-03 11:39:31 --> 404 Page Not Found --> 
ERROR - 2013-09-03 11:40:22 --> 404 Page Not Found --> 
ERROR - 2013-09-03 11:41:46 --> 404 Page Not Found --> 
ERROR - 2013-09-03 11:42:54 --> 404 Page Not Found --> 
ERROR - 2013-09-03 11:43:10 --> 404 Page Not Found --> 
ERROR - 2013-09-03 11:44:52 --> 404 Page Not Found --> 
ERROR - 2013-09-03 11:44:58 --> 404 Page Not Found --> 
ERROR - 2013-09-03 11:46:46 --> 404 Page Not Found --> 
ERROR - 2013-09-03 11:47:41 --> 404 Page Not Found --> 
ERROR - 2013-09-03 11:48:15 --> 404 Page Not Found --> 
ERROR - 2013-09-03 11:52:37 --> 404 Page Not Found --> 
ERROR - 2013-09-03 11:52:41 --> 404 Page Not Found --> 
ERROR - 2013-09-03 11:52:44 --> 404 Page Not Found --> 
ERROR - 2013-09-03 11:52:45 --> 404 Page Not Found --> 
ERROR - 2013-09-03 11:56:25 --> 404 Page Not Found --> 
ERROR - 2013-09-03 12:01:05 --> 404 Page Not Found --> User/assets
ERROR - 2013-09-03 12:01:05 --> 404 Page Not Found --> User/assets
ERROR - 2013-09-03 12:06:15 --> 404 Page Not Found --> 
ERROR - 2013-09-03 12:08:24 --> 404 Page Not Found --> 
ERROR - 2013-09-03 12:10:24 --> 404 Page Not Found --> 
ERROR - 2013-09-03 12:10:48 --> 404 Page Not Found --> 
ERROR - 2013-09-03 12:53:36 --> 404 Page Not Found --> 
ERROR - 2013-09-03 12:57:23 --> 404 Page Not Found --> 
ERROR - 2013-09-03 12:57:33 --> 404 Page Not Found --> 
ERROR - 2013-09-03 12:57:47 --> 404 Page Not Found --> 
ERROR - 2013-09-03 13:04:18 --> 404 Page Not Found --> 
ERROR - 2013-09-03 13:05:36 --> 404 Page Not Found --> 
ERROR - 2013-09-03 13:08:42 --> 404 Page Not Found --> 
ERROR - 2013-09-03 13:27:10 --> 404 Page Not Found --> 
ERROR - 2013-09-03 13:27:13 --> 404 Page Not Found --> 
ERROR - 2013-09-03 13:27:14 --> 404 Page Not Found --> 
ERROR - 2013-09-03 13:27:24 --> 404 Page Not Found --> 
ERROR - 2013-09-03 13:28:39 --> 404 Page Not Found --> 
ERROR - 2013-09-03 13:32:58 --> 404 Page Not Found --> 
ERROR - 2013-09-03 13:35:11 --> 404 Page Not Found --> 
ERROR - 2013-09-03 13:35:27 --> 404 Page Not Found --> 
ERROR - 2013-09-03 13:39:47 --> 404 Page Not Found --> 
ERROR - 2013-09-03 13:39:57 --> 404 Page Not Found --> 
ERROR - 2013-09-03 13:41:34 --> 404 Page Not Found --> 
ERROR - 2013-09-03 13:51:47 --> 404 Page Not Found --> 
ERROR - 2013-09-03 13:52:23 --> 404 Page Not Found --> 
ERROR - 2013-09-03 14:05:29 --> 404 Page Not Found --> 
ERROR - 2013-09-03 14:05:37 --> 404 Page Not Found --> 
ERROR - 2013-09-03 14:05:44 --> 404 Page Not Found --> 
ERROR - 2013-09-03 14:06:21 --> 404 Page Not Found --> 
ERROR - 2013-09-03 14:06:43 --> 404 Page Not Found --> 
ERROR - 2013-09-03 14:07:02 --> 404 Page Not Found --> 
ERROR - 2013-09-03 14:07:15 --> 404 Page Not Found --> 
ERROR - 2013-09-03 14:07:26 --> 404 Page Not Found --> 
ERROR - 2013-09-03 14:09:21 --> 404 Page Not Found --> 
ERROR - 2013-09-03 14:10:03 --> 404 Page Not Found --> 
ERROR - 2013-09-03 14:10:14 --> 404 Page Not Found --> 
ERROR - 2013-09-03 14:10:21 --> 404 Page Not Found --> 
ERROR - 2013-09-03 14:10:49 --> 404 Page Not Found --> 
ERROR - 2013-09-03 14:11:16 --> 404 Page Not Found --> 
ERROR - 2013-09-03 14:12:27 --> 404 Page Not Found --> 
ERROR - 2013-09-03 14:12:43 --> 404 Page Not Found --> 
ERROR - 2013-09-03 14:13:40 --> 404 Page Not Found --> 
ERROR - 2013-09-03 14:16:49 --> 404 Page Not Found --> 
ERROR - 2013-09-03 14:18:05 --> 404 Page Not Found --> 
ERROR - 2013-09-03 14:18:48 --> 404 Page Not Found --> 
ERROR - 2013-09-03 14:19:10 --> 404 Page Not Found --> 
ERROR - 2013-09-03 14:19:22 --> 404 Page Not Found --> 
ERROR - 2013-09-03 14:19:53 --> 404 Page Not Found --> 
ERROR - 2013-09-03 14:20:18 --> 404 Page Not Found --> 
ERROR - 2013-09-03 14:22:20 --> 404 Page Not Found --> 
ERROR - 2013-09-03 14:23:29 --> 404 Page Not Found --> 
ERROR - 2013-09-03 14:23:40 --> 404 Page Not Found --> 
ERROR - 2013-09-03 14:23:47 --> 404 Page Not Found --> 
ERROR - 2013-09-03 14:24:29 --> 404 Page Not Found --> 
ERROR - 2013-09-03 15:12:18 --> 404 Page Not Found --> 
ERROR - 2013-09-03 15:12:26 --> 404 Page Not Found --> 
ERROR - 2013-09-03 15:18:13 --> 404 Page Not Found --> 
ERROR - 2013-09-03 15:18:37 --> 404 Page Not Found --> 
ERROR - 2013-09-03 15:24:01 --> 404 Page Not Found --> 
ERROR - 2013-09-03 15:24:55 --> 404 Page Not Found --> 
ERROR - 2013-09-03 15:30:11 --> 404 Page Not Found --> 
ERROR - 2013-09-03 15:31:14 --> 404 Page Not Found --> 
ERROR - 2013-09-03 15:32:07 --> 404 Page Not Found --> 
ERROR - 2013-09-03 15:32:33 --> 404 Page Not Found --> 
ERROR - 2013-09-03 15:33:40 --> 404 Page Not Found --> 
ERROR - 2013-09-03 15:34:06 --> 404 Page Not Found --> 
ERROR - 2013-09-03 15:35:27 --> 404 Page Not Found --> 
ERROR - 2013-09-03 15:36:00 --> 404 Page Not Found --> 
ERROR - 2013-09-03 15:36:04 --> 404 Page Not Found --> 
ERROR - 2013-09-03 15:36:54 --> 404 Page Not Found --> 
ERROR - 2013-09-03 15:37:31 --> 404 Page Not Found --> 
ERROR - 2013-09-03 16:23:23 --> 404 Page Not Found --> 
ERROR - 2013-09-03 16:28:16 --> 404 Page Not Found --> User/assets
ERROR - 2013-09-03 16:28:16 --> 404 Page Not Found --> User/assets
ERROR - 2013-09-03 17:29:27 --> Severity: 4096  --> Object of class stdClass could not be converted to string D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 390
ERROR - 2013-09-03 17:29:27 --> Severity: 4096  --> Object of class stdClass could not be converted to string D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 390
ERROR - 2013-09-03 17:29:27 --> Severity: 4096  --> Object of class stdClass could not be converted to string D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 390
ERROR - 2013-09-03 17:29:34 --> Severity: 4096  --> Object of class stdClass could not be converted to string D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 390
ERROR - 2013-09-03 17:29:34 --> Severity: 4096  --> Object of class stdClass could not be converted to string D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 390
ERROR - 2013-09-03 17:29:34 --> Severity: 4096  --> Object of class stdClass could not be converted to string D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 390
ERROR - 2013-09-03 17:30:14 --> Severity: 4096  --> Object of class stdClass could not be converted to string D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 390
ERROR - 2013-09-03 17:30:14 --> Severity: 4096  --> Object of class stdClass could not be converted to string D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 390
ERROR - 2013-09-03 17:30:14 --> Severity: 4096  --> Object of class stdClass could not be converted to string D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 390
ERROR - 2013-09-03 17:30:34 --> Severity: 4096  --> Object of class stdClass could not be converted to string D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 390
ERROR - 2013-09-03 17:30:34 --> Severity: 4096  --> Object of class stdClass could not be converted to string D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 390
ERROR - 2013-09-03 17:30:34 --> Severity: 4096  --> Object of class stdClass could not be converted to string D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 390
ERROR - 2013-09-03 17:33:07 --> Severity: 4096  --> Object of class stdClass could not be converted to string D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 390
ERROR - 2013-09-03 17:33:07 --> Severity: 4096  --> Object of class stdClass could not be converted to string D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 390
ERROR - 2013-09-03 17:33:07 --> Severity: 4096  --> Object of class stdClass could not be converted to string D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 390
ERROR - 2013-09-03 18:25:44 --> 404 Page Not Found --> 
ERROR - 2013-09-03 18:25:49 --> 404 Page Not Found --> 
ERROR - 2013-09-03 18:27:42 --> 404 Page Not Found --> 
ERROR - 2013-09-03 18:27:45 --> 404 Page Not Found --> 
ERROR - 2013-09-03 18:27:50 --> 404 Page Not Found --> 
ERROR - 2013-09-03 18:27:51 --> 404 Page Not Found --> 
ERROR - 2013-09-03 18:31:38 --> Severity: 4096  --> Object of class stdClass could not be converted to string D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 390
ERROR - 2013-09-03 18:31:38 --> Severity: 4096  --> Object of class stdClass could not be converted to string D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 390
