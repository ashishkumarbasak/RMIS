<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-10-08 10:18:37 --> 404 Page Not Found --> 
ERROR - 2013-10-08 10:18:37 --> 404 Page Not Found --> 
ERROR - 2013-10-08 11:01:17 --> 404 Page Not Found --> 
ERROR - 2013-10-08 11:01:19 --> 404 Page Not Found --> 
ERROR - 2013-10-08 11:01:25 --> 404 Page Not Found --> 
ERROR - 2013-10-08 11:01:46 --> 404 Page Not Found --> 
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:45:47 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:46:05 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:46:05 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:46:05 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:46:05 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:46:05 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:46:05 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:46:05 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:46:05 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:46:05 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:46:05 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:46:05 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:46:05 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:46:05 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:46:05 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:46:05 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:46:05 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:46:05 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:46:05 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:46:05 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:46:05 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:46:05 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:46:05 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:46:05 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:46:05 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:46:05 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:46:05 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:46:05 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:46:05 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:46:05 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:46:05 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:46:05 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:46:05 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:46:05 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:46:05 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:46:05 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'percentage_or_fixed_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 300
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 301
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 304
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'calculation_type' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 309
ERROR - 2013-10-08 13:46:06 --> Severity: Warning  --> Illegal string offset 'maximum_amount' D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 314
ERROR - 2013-10-08 15:26:53 --> Query error: Column 'salary_head_id' cannot be null - Invalid query: INSERT INTO `pmm_salary_details` (`organization_id`, `salary_info_id`, `salary_head_id`, `salary_head_name`, `salary_head_type`, `head_amount`, `sort_order`, `created_at`, `created_by`) VALUES (1, '1', NULL, NULL, NULL, 0, NULL, '2013-10-08 15:26:53', '2')
ERROR - 2013-10-08 15:30:07 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 510
ERROR - 2013-10-08 15:30:07 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 510
ERROR - 2013-10-08 15:30:07 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 510
ERROR - 2013-10-08 15:30:07 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 510
ERROR - 2013-10-08 15:56:32 --> Severity: Warning  --> Missing argument 1 for Process_Model::getAllEmployeeList(), called in D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php on line 53 and defined D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\models\process_model.php 36
ERROR - 2013-10-08 16:25:01 --> Query error: Column 'employee_id' cannot be null - Invalid query: INSERT INTO `pmm_salary_info` (`organization_id`, `salary_process_id`, `salary_month`, `employee_id`, `salary_grade_id`, `effective_date`, `next_increament_date`, `payable_days`, `designation_id`, `department_id`, `employee_type_id`, `employee_category_id`, `employee_class_id`, `bank_id`, `bank_branch_id`, `account_no`, `tin_number`, `created_at`, `created_by`) VALUES (1, '1', '2013-10-01', NULL, '1', '2013-10-05', '2013-10-15', '11', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-10-08 16:25:01', '2')
ERROR - 2013-10-08 16:26:13 --> Query error: Column 'employee_id' cannot be null - Invalid query: INSERT INTO `pmm_salary_info` (`organization_id`, `salary_process_id`, `salary_month`, `employee_id`, `salary_grade_id`, `effective_date`, `next_increament_date`, `payable_days`, `designation_id`, `department_id`, `employee_type_id`, `employee_category_id`, `employee_class_id`, `bank_id`, `bank_branch_id`, `account_no`, `tin_number`, `created_at`, `created_by`) VALUES (1, '1', '2013-10-01', NULL, '1', '2013-10-05', '2013-10-15', '11', '2', '2', '2', '1', '1', NULL, NULL, '12125.00', '', '2013-10-08 16:26:13', '2')
ERROR - 2013-10-08 16:26:33 --> Query error: Column 'employee_id' cannot be null - Invalid query: INSERT INTO `pmm_salary_info` (`organization_id`, `salary_process_id`, `salary_month`, `employee_id`, `salary_grade_id`, `effective_date`, `next_increament_date`, `payable_days`, `designation_id`, `department_id`, `employee_type_id`, `employee_category_id`, `employee_class_id`, `bank_id`, `bank_branch_id`, `account_no`, `tin_number`, `created_at`, `created_by`) VALUES (1, '2', '2013-10-01', NULL, '1', '2013-10-05', '2013-10-15', '11', '2', '2', '2', '1', '1', NULL, NULL, '12125.00', '', '2013-10-08 16:26:33', '2')
ERROR - 2013-10-08 16:27:14 --> Query error: Column 'bank_id' cannot be null - Invalid query: INSERT INTO `pmm_salary_info` (`organization_id`, `salary_process_id`, `salary_month`, `employee_id`, `salary_grade_id`, `effective_date`, `next_increament_date`, `payable_days`, `designation_id`, `department_id`, `employee_type_id`, `employee_category_id`, `employee_class_id`, `bank_id`, `bank_branch_id`, `account_no`, `tin_number`, `created_at`, `created_by`) VALUES (1, '3', '2013-10-01', '1', '1', '2013-10-05', '2013-10-15', '11', '2', '2', '2', '1', '1', NULL, NULL, '12125.00', '', '2013-10-08 16:27:14', '2')
ERROR - 2013-10-08 17:38:49 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:38:50 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:38:51 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:38:53 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:38:53 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:38:54 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:38:55 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:38:56 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:38:57 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:38:58 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:38:59 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:00 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:01 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:02 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:03 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:04 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:05 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:06 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:07 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:08 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:09 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:10 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:11 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:12 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:13 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:14 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:15 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:16 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:17 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:18 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:19 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:20 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:21 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:22 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:23 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:24 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:25 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:26 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:27 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:28 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:29 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:30 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:31 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:32 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:33 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:34 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:35 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:36 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:37 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:38 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:39 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:40 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:41 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:42 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:43 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:44 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:45 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:46 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:47 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:48 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:49 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:50 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:51 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:52 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:53 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:54 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:55 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:56 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:57 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:58 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:39:59 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:40:00 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:40:01 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:40:02 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:40:03 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:40:04 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:40:05 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:40:06 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:40:07 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:40:08 --> 404 Page Not Found --> 
ERROR - 2013-10-08 17:40:09 --> 404 Page Not Found --> 
ERROR - 2013-10-08 18:08:59 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:00 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:01 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:10 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:10 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:11 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:12 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:13 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:14 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:15 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:16 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:17 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:18 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:20 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:20 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:21 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:22 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:23 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:24 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:25 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:26 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:27 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:28 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:29 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:30 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:32 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:32 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:34 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:34 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:35 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:36 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:38 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:38 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:40 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:40 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:41 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:43 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:44 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:44 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:46 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:46 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:47 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:48 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:50 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:50 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:52 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:52 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:53 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:54 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:56 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:57 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:57 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:09:58 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:00 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:00 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:02 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:03 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:03 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:04 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:05 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:06 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:08 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:08 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:09 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:10 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:11 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:12 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:13 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:14 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:15 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:16 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:17 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:19 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:19 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:21 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:22 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:22 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:23 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:25 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:25 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:27 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:28 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:28 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:29 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:30 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:31 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:33 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:33 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:35 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:35 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:36 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:37 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:39 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:40 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:40 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:41 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:42 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:43 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:45 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:45 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:46 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:48 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:49 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:49 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:51 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:51 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:52 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:53 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:54 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:55 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:57 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:57 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:58 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:10:59 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:00 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:01 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:03 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:03 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:04 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:05 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:06 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:07 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:09 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:10 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:10 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:11 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:13 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:13 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:15 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:15 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:16 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:17 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:19 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:19 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:21 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:22 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:22 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:23 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:24 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:25 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:27 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:28 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:28 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:29 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:30 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:31 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:33 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:33 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:34 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:35 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:36 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:37 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:39 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:40 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:40 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:41 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:42 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:43 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:45 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:45 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:47 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:47 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:48 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:49 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:50 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:51 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:53 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:54 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:54 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:55 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:57 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:58 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:58 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:11:59 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:00 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:02 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:03 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:03 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:04 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:05 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:07 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:07 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:09 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:10 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:10 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:11 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:12 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:13 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:15 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:15 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:16 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:17 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:18 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:19 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:21 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:21 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:22 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:23 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:25 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:25 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:27 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:28 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:28 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:29 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:31 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:31 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:33 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:34 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:34 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:35 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:36 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:37 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:38 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:40 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:41 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:42 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:43 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:43 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:44 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:46 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:47 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:47 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:49 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:49 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:50 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:52 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:52 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:53 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:55 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:55 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 18:12:57 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 95
ERROR - 2013-10-08 19:04:04 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 98
ERROR - 2013-10-08 19:04:05 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 98
ERROR - 2013-10-08 19:04:06 --> Severity: Warning  --> Division by zero D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php 98
