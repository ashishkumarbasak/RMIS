<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-12-12 15:20:16 --> 404 Page Not Found --> 
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-12-12 15:20:16 --> 404 Page Not Found --> 
ERROR - 2013-12-12 15:20:16 --> 404 Page Not Found --> 
ERROR - 2013-12-12 15:20:16 --> 404 Page Not Found --> 
ERROR - 2013-12-12 15:20:33 --> 404 Page Not Found --> 
ERROR - 2013-12-12 15:20:33 --> 404 Page Not Found --> 
ERROR - 2013-12-12 15:20:33 --> 404 Page Not Found --> 
ERROR - 2013-12-12 15:20:33 --> 404 Page Not Found --> 
ERROR - 2013-12-12 15:20:33 --> 404 Page Not Found --> 
ERROR - 2013-12-12 15:20:33 --> 404 Page Not Found --> 
ERROR - 2013-12-12 15:20:33 --> 404 Page Not Found --> 
ERROR - 2013-12-12 15:20:40 --> 404 Page Not Found --> 
ERROR - 2013-12-12 15:20:40 --> 404 Page Not Found --> 
ERROR - 2013-12-12 15:20:40 --> 404 Page Not Found --> 
ERROR - 2013-12-12 15:20:40 --> 404 Page Not Found --> 
