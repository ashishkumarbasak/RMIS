<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-08-29 11:09:52 --> 404 Page Not Found --> 
ERROR - 2013-08-29 11:09:52 --> 404 Page Not Found --> 
ERROR - 2013-08-29 11:09:57 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-29 11:09:57 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-29 11:10:06 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-29 11:10:06 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-29 12:22:41 --> 404 Page Not Found --> 
ERROR - 2013-08-29 12:22:46 --> 404 Page Not Found --> 
ERROR - 2013-08-29 12:32:54 --> 404 Page Not Found --> 
ERROR - 2013-08-29 12:33:43 --> 404 Page Not Found --> 
ERROR - 2013-08-29 12:33:57 --> 404 Page Not Found --> 
ERROR - 2013-08-29 12:40:46 --> 404 Page Not Found --> 
ERROR - 2013-08-29 12:40:49 --> 404 Page Not Found --> 
ERROR - 2013-08-29 12:42:13 --> 404 Page Not Found --> 
ERROR - 2013-08-29 12:42:17 --> 404 Page Not Found --> 
ERROR - 2013-08-29 12:45:09 --> 404 Page Not Found --> 
ERROR - 2013-08-29 12:45:14 --> 404 Page Not Found --> 
ERROR - 2013-08-29 12:50:04 --> 404 Page Not Found --> 
ERROR - 2013-08-29 15:07:52 --> 404 Page Not Found --> User/user
ERROR - 2013-08-29 15:08:45 --> 404 Page Not Found --> User/user
ERROR - 2013-08-29 15:09:05 --> 404 Page Not Found --> User/user
ERROR - 2013-08-29 17:11:32 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\views\users\user_add_form.php 77
ERROR - 2013-08-29 17:56:30 --> Severity: Warning  --> Illegal string offset '&#36;_GET['_']' D:\Zend\Apache2\htdocs\natp_barc\application\libraries\Profiler.php 228
ERROR - 2013-08-29 18:02:32 --> 404 Page Not Found --> 
ERROR - 2013-08-29 18:13:03 --> Severity: Warning  --> Creating default object from empty value D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\User.php 185
ERROR - 2013-08-29 18:14:20 --> Severity: Warning  --> Creating default object from empty value D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\User.php 186
ERROR - 2013-08-29 18:14:54 --> Severity: Warning  --> Creating default object from empty value D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\User.php 186
ERROR - 2013-08-29 18:18:17 --> Severity: Warning  --> Creating default object from empty value D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\User.php 186
ERROR - 2013-08-29 18:19:26 --> Severity: Warning  --> Creating default object from empty value D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\User.php 186
ERROR - 2013-08-29 18:20:02 --> Severity: Warning  --> Creating default object from empty value D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\User.php 186
ERROR - 2013-08-29 18:20:02 --> Severity: 4096  --> Object of class stdClass could not be converted to string D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 504
ERROR - 2013-08-29 18:21:06 --> Severity: Warning  --> Creating default object from empty value D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\User.php 187
ERROR - 2013-08-29 18:21:06 --> Severity: 4096  --> Object of class stdClass could not be converted to string D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 504
ERROR - 2013-08-29 18:21:35 --> Severity: Warning  --> Creating default object from empty value D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\User.php 187
ERROR - 2013-08-29 18:21:35 --> Severity: 4096  --> Object of class stdClass could not be converted to string D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 504
ERROR - 2013-08-29 18:25:21 --> Severity: Warning  --> Creating default object from empty value D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\User.php 187
ERROR - 2013-08-29 18:25:21 --> Severity: 4096  --> Object of class stdClass could not be converted to string D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 504
ERROR - 2013-08-29 18:25:45 --> Severity: Warning  --> Creating default object from empty value D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\User.php 187
ERROR - 2013-08-29 18:25:45 --> Severity: 4096  --> Object of class stdClass could not be converted to string D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 504
ERROR - 2013-08-29 18:57:28 --> 404 Page Not Found --> 
ERROR - 2013-08-29 18:57:29 --> 404 Page Not Found --> 
ERROR - 2013-08-29 18:57:30 --> 404 Page Not Found --> 
ERROR - 2013-08-29 18:57:42 --> 404 Page Not Found --> 
