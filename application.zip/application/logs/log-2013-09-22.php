<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-09-22 09:20:22 --> 404 Page Not Found --> 
ERROR - 2013-09-22 09:20:22 --> 404 Page Not Found --> 
ERROR - 2013-09-22 10:14:26 --> Could not find the language line "form_validation_date_compare"
ERROR - 2013-09-22 10:14:26 --> Could not find the language line "form_validation_date_compare"
ERROR - 2013-09-22 10:14:40 --> Could not find the language line "form_validation_date_compare"
ERROR - 2013-09-22 10:14:40 --> Could not find the language line "form_validation_date_compare"
ERROR - 2013-09-22 11:52:14 --> Could not find the language line "form_validation_date_compare"
ERROR - 2013-09-22 11:52:14 --> Could not find the language line "form_validation_date_compare"
ERROR - 2013-09-22 12:15:47 --> Query error: Unknown column 'start_date' in 'field list' - Invalid query: UPDATE `pmm_residence_quarter` SET `salary_head_id` = '17', `employee_id` = '', `start_date` = '2013-09-10', `end_date` = '2013-09-19', `amount` = NULL, `remarks` = NULL, `updated_at` = '2013-09-22 12:15:47', `updated_by` = '2'
WHERE `id` = '1'
ERROR - 2013-09-22 14:02:35 --> Query error: Unknown column 'value' in 'field list' - Invalid query: SELECT `id`, `value`, `name`
FROM `hrm_designations`
WHERE `is_active` = 1
ORDER BY `weight` desc, `name` asc
ERROR - 2013-09-22 14:41:41 --> 404 Page Not Found --> 
ERROR - 2013-09-22 14:41:44 --> 404 Page Not Found --> 
ERROR - 2013-09-22 16:52:35 --> Query error: Duplicate entry '0-1' for key 'PRIMARY' - Invalid query: INSERT INTO `pmm_earnings_deduction_for_group` (`organization_id`, `salary_head_id`, `start_date`, `end_date`, `designation_id`, `employee_category_id`, `employee_type_id`, `employee_class_id`, `grade_from_id`, `grade_to_id`, `amount`, `no_of_days_for_basic_deduction`, `remarks`, `created_at`, `created_by`) VALUES (1, '17', '2013-09-05', '2013-09-05', '2', '1', '1', '1', '1', '2', '1212', '2', '21212', '2013-09-22 16:52:35', '2')
