<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-11-25 09:44:26 --> 404 Page Not Found --> 
ERROR - 2013-11-25 09:44:26 --> 404 Page Not Found --> 
ERROR - 2013-11-25 10:01:34 --> 404 Page Not Found --> 
ERROR - 2013-11-25 10:01:34 --> 404 Page Not Found --> 
ERROR - 2013-11-25 13:57:54 --> Query error: Unknown column 'month_from' in 'where clause' - Invalid query: SELECT `id`
FROM `cpf_opening_balance`
WHERE `salary_head_id` = '23'
AND `month_from` = ''
 LIMIT 1
ERROR - 2013-11-25 13:57:58 --> Query error: Unknown column 'month_from' in 'where clause' - Invalid query: SELECT `id`
FROM `cpf_opening_balance`
WHERE `salary_head_id` = '23'
AND `month_from` = ''
 LIMIT 1
ERROR - 2013-11-25 13:58:08 --> Severity: 4096  --> Argument 1 passed to Illuminate\Database\Connection::__construct() must be an instance of PDO, instance of Template given, called in D:\Zend\Apache2\htdocs\natp_barc\vendor\cartalyst\sentry\src\Cartalyst\Sentry\Facades\ConnectionResolver.php on line 117 and defined D:\Zend\Apache2\htdocs\natp_barc\vendor\illuminate\database\Illuminate\Database\Connection.php 118
ERROR - 2013-11-25 13:58:20 --> Query error: Unknown column 'month_from' in 'where clause' - Invalid query: SELECT `id`
FROM `cpf_opening_balance`
WHERE `salary_head_id` = '23'
AND `month_from` = ''
 LIMIT 1
ERROR - 2013-11-25 13:58:26 --> Severity: 4096  --> Argument 1 passed to Illuminate\Database\Connection::__construct() must be an instance of PDO, instance of Template given, called in D:\Zend\Apache2\htdocs\natp_barc\vendor\cartalyst\sentry\src\Cartalyst\Sentry\Facades\ConnectionResolver.php on line 117 and defined D:\Zend\Apache2\htdocs\natp_barc\vendor\illuminate\database\Illuminate\Database\Connection.php 118
ERROR - 2013-11-25 13:58:52 --> Query error: Unknown column 'month_from' in 'where clause' - Invalid query: SELECT `id`
FROM `cpf_opening_balance`
WHERE `salary_head_id` = '11'
AND `month_from` = ''
 LIMIT 1
ERROR - 2013-11-25 13:59:07 --> Query error: Unknown column 'month_from' in 'where clause' - Invalid query: SELECT `id`
FROM `cpf_opening_balance`
WHERE `salary_head_id` = '11'
AND `month_from` = 'July 2013'
 LIMIT 1
ERROR - 2013-11-25 14:00:22 --> Severity: 4096  --> Argument 1 passed to Illuminate\Database\Connection::__construct() must be an instance of PDO, instance of Template given, called in D:\Zend\Apache2\htdocs\natp_barc\vendor\cartalyst\sentry\src\Cartalyst\Sentry\Facades\ConnectionResolver.php on line 117 and defined D:\Zend\Apache2\htdocs\natp_barc\vendor\illuminate\database\Illuminate\Database\Connection.php 118
ERROR - 2013-11-25 15:38:13 --> Query error: Unknown column 'month_from' in 'where clause' - Invalid query: SELECT `id`
FROM `cpf_opening_balance`
WHERE `salary_head_id` = '11'
AND `month_from` = '25-11-2013'
 LIMIT 1
ERROR - 2013-11-25 15:40:31 --> Severity: 4096  --> Argument 1 passed to Illuminate\Database\Connection::__construct() must be an instance of PDO, instance of Template given, called in D:\Zend\Apache2\htdocs\natp_barc\vendor\cartalyst\sentry\src\Cartalyst\Sentry\Facades\ConnectionResolver.php on line 117 and defined D:\Zend\Apache2\htdocs\natp_barc\vendor\illuminate\database\Illuminate\Database\Connection.php 118
