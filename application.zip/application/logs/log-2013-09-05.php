<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-09-05 10:01:14 --> 404 Page Not Found --> 
ERROR - 2013-09-05 10:01:14 --> 404 Page Not Found --> 
ERROR - 2013-09-05 10:11:40 --> Severity: Warning  --> Creating default object from empty value D:\Zend\Apache2\htdocs\natp_barc\application\modules\pmm\controllers\houserentpolicy.php 210
ERROR - 2013-09-05 10:11:40 --> Severity: Warning  --> Creating default object from empty value D:\Zend\Apache2\htdocs\natp_barc\application\modules\pmm\controllers\houserentpolicy.php 214
ERROR - 2013-09-05 11:48:18 --> 404 Page Not Found --> User/assets
ERROR - 2013-09-05 11:48:18 --> 404 Page Not Found --> User/assets
ERROR - 2013-09-05 11:48:24 --> 404 Page Not Found --> User/assets
ERROR - 2013-09-05 11:48:24 --> 404 Page Not Found --> User/assets
ERROR - 2013-09-05 12:47:10 --> 404 Page Not Found --> 
ERROR - 2013-09-05 12:47:14 --> 404 Page Not Found --> 
ERROR - 2013-09-05 17:13:35 --> 404 Page Not Found --> 
