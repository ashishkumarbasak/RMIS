<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-11-18 09:44:54 --> 404 Page Not Found --> 
ERROR - 2013-11-18 09:44:54 --> 404 Page Not Found --> 
ERROR - 2013-11-18 10:46:36 --> Severity: Warning  --> Missing argument 1 for Vehicle::getCountryOfOrigin() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\controllers\Vehicle.php 416
ERROR - 2013-11-18 10:46:39 --> Severity: Warning  --> Missing argument 1 for Vehicle::getCountryOfOrigin() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\controllers\Vehicle.php 416
ERROR - 2013-11-18 10:46:41 --> Severity: Warning  --> Missing argument 1 for Vehicle::getCountryOfOrigin() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\controllers\Vehicle.php 416
ERROR - 2013-11-18 10:46:53 --> Severity: Warning  --> Missing argument 1 for Vehicle::getCountryOfOrigin() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\controllers\Vehicle.php 416
ERROR - 2013-11-18 11:49:38 --> Severity: Warning  --> require_once(http://localhost:8088/JavaBridge/java/Java.inc): failed to open stream: No connection could be made because the target machine actively refused it.
 D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\controllers\Rptvehicle.php 56
ERROR - 2013-11-18 12:00:35 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 219
ERROR - 2013-11-18 12:00:35 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 219
ERROR - 2013-11-18 12:00:35 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 219
ERROR - 2013-11-18 12:00:35 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 219
ERROR - 2013-11-18 12:00:35 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 219
ERROR - 2013-11-18 12:00:35 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 219
ERROR - 2013-11-18 12:00:35 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 219
ERROR - 2013-11-18 12:00:35 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 219
ERROR - 2013-11-18 12:00:35 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 219
ERROR - 2013-11-18 12:00:58 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 219
ERROR - 2013-11-18 12:00:58 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 219
ERROR - 2013-11-18 12:00:58 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 219
ERROR - 2013-11-18 12:00:58 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 219
ERROR - 2013-11-18 12:00:58 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 219
ERROR - 2013-11-18 12:00:58 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 219
ERROR - 2013-11-18 12:00:58 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 219
ERROR - 2013-11-18 12:00:58 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 219
ERROR - 2013-11-18 12:00:58 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 219
ERROR - 2013-11-18 13:37:25 --> 404 Page Not Found --> Route/print
ERROR - 2013-11-18 13:37:39 --> 404 Page Not Found --> Route/print
ERROR - 2013-11-18 13:41:19 --> 404 Page Not Found --> 
ERROR - 2013-11-18 13:41:19 --> 404 Page Not Found --> 
ERROR - 2013-11-18 16:41:06 --> 404 Page Not Found --> Vehicle/printRoute
ERROR - 2013-11-18 17:07:49 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\setup\vehicle_print.php 16
ERROR - 2013-11-18 17:23:16 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\setup\vehicle_print.php 16
ERROR - 2013-11-18 17:23:17 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\setup\vehicle_print.php 16
