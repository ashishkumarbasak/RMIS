<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-08-13 10:19:33 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:33 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:33 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:33 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:33 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:33 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:33 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:33 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:33 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:34 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:34 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:34 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:34 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:34 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:34 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:34 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:34 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:34 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:34 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:34 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:34 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:34 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:34 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:34 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:34 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:34 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:34 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:34 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:34 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:34 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:34 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:34 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:34 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:34 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:34 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:34 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:34 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:34 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:34 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:34 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:34 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:34 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:34 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:34 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:40 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:40 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:41 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:41 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:41 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:41 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:41 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:41 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:41 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:41 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:41 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:41 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:41 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:41 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:41 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:41 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:41 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:41 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:41 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:41 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:41 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:41 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:41 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:41 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:41 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:41 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:41 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:41 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:41 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:41 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:41 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:41 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:41 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:41 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:41 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:41 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:41 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:41 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:41 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:41 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:19:41 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:21:46 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:21:46 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:21:46 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:21:46 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:21:46 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:21:46 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:21:46 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:21:46 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:21:46 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:21:46 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:21:47 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:23:01 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:34:30 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:35:09 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:35:56 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:37:11 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:38:37 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:39:54 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:40:12 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:40:57 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:43:07 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:44:59 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:46:06 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:46:10 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:48:28 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:49:49 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:50:08 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:50:20 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:50:32 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:50:40 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:50:42 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:50:52 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:51:18 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:57:38 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:58:38 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:58:48 --> 404 Page Not Found --> 
ERROR - 2013-08-13 10:59:35 --> 404 Page Not Found --> 
ERROR - 2013-08-13 11:03:05 --> 404 Page Not Found --> 
ERROR - 2013-08-13 11:07:11 --> 404 Page Not Found --> 
ERROR - 2013-08-13 11:07:34 --> 404 Page Not Found --> 
ERROR - 2013-08-13 11:08:11 --> 404 Page Not Found --> 
ERROR - 2013-08-13 11:08:36 --> 404 Page Not Found --> 
ERROR - 2013-08-13 11:08:51 --> 404 Page Not Found --> 
ERROR - 2013-08-13 11:09:23 --> 404 Page Not Found --> 
ERROR - 2013-08-13 11:09:31 --> 404 Page Not Found --> 
ERROR - 2013-08-13 11:09:45 --> 404 Page Not Found --> 
ERROR - 2013-08-13 11:11:51 --> 404 Page Not Found --> 
ERROR - 2013-08-13 11:12:06 --> 404 Page Not Found --> 
ERROR - 2013-08-13 11:12:37 --> 404 Page Not Found --> 
ERROR - 2013-08-13 11:14:41 --> 404 Page Not Found --> 
ERROR - 2013-08-13 11:17:26 --> 404 Page Not Found --> 
ERROR - 2013-08-13 11:18:48 --> 404 Page Not Found --> 
ERROR - 2013-08-13 11:19:21 --> 404 Page Not Found --> 
ERROR - 2013-08-13 11:19:38 --> 404 Page Not Found --> 
ERROR - 2013-08-13 11:19:47 --> 404 Page Not Found --> 
ERROR - 2013-08-13 11:20:52 --> 404 Page Not Found --> 
ERROR - 2013-08-13 11:20:52 --> 404 Page Not Found --> 
ERROR - 2013-08-13 11:20:53 --> 404 Page Not Found --> 
ERROR - 2013-08-13 11:21:19 --> 404 Page Not Found --> 
ERROR - 2013-08-13 11:21:50 --> 404 Page Not Found --> 
ERROR - 2013-08-13 11:22:31 --> 404 Page Not Found --> 
ERROR - 2013-08-13 11:23:17 --> 404 Page Not Found --> 
ERROR - 2013-08-13 11:24:44 --> 404 Page Not Found --> 
ERROR - 2013-08-13 11:25:22 --> 404 Page Not Found --> 
ERROR - 2013-08-13 11:25:38 --> 404 Page Not Found --> 
ERROR - 2013-08-13 11:27:31 --> 404 Page Not Found --> 
ERROR - 2013-08-13 11:27:55 --> 404 Page Not Found --> 
ERROR - 2013-08-13 11:29:06 --> 404 Page Not Found --> 
ERROR - 2013-08-13 11:33:14 --> 404 Page Not Found --> 
ERROR - 2013-08-13 11:51:27 --> 404 Page Not Found --> 
ERROR - 2013-08-13 11:51:27 --> 404 Page Not Found --> 
ERROR - 2013-08-13 11:51:27 --> 404 Page Not Found --> 
ERROR - 2013-08-13 12:13:53 --> 404 Page Not Found --> 
ERROR - 2013-08-13 12:14:02 --> 404 Page Not Found --> 
ERROR - 2013-08-13 15:21:57 --> 404 Page Not Found --> 
ERROR - 2013-08-13 15:33:08 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-13 15:45:34 --> Severity: Notice  --> Undefined property: CI::$_data D:\Zend\Apache2\htdocs\natp_barc\application\third_party\MX\Controller.php 58
ERROR - 2013-08-13 15:45:34 --> Severity: Notice  --> Indirect modification of overloaded property Module::$_data has no effect D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Module.php 16
ERROR - 2013-08-13 15:45:34 --> Severity: Notice  --> Undefined property: CI::$_data D:\Zend\Apache2\htdocs\natp_barc\application\third_party\MX\Controller.php 58
ERROR - 2013-08-13 15:45:34 --> Severity: Notice  --> Indirect modification of overloaded property Module::$_data has no effect D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Module.php 17
ERROR - 2013-08-13 15:45:34 --> Severity: Notice  --> Undefined property: CI::$_data D:\Zend\Apache2\htdocs\natp_barc\application\third_party\MX\Controller.php 58
ERROR - 2013-08-13 15:45:34 --> Severity: Notice  --> Indirect modification of overloaded property Module::$_data has no effect D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Module.php 18
ERROR - 2013-08-13 15:45:34 --> Severity: Notice  --> Undefined property: CI::$_data D:\Zend\Apache2\htdocs\natp_barc\application\third_party\MX\Controller.php 58
ERROR - 2013-08-13 15:45:34 --> Severity: Notice  --> Indirect modification of overloaded property Module::$_data has no effect D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Module.php 19
ERROR - 2013-08-13 15:45:34 --> Severity: Notice  --> Undefined property: CI::$_data D:\Zend\Apache2\htdocs\natp_barc\application\third_party\MX\Controller.php 58
ERROR - 2013-08-13 15:45:34 --> Severity: Notice  --> Undefined property: CI::$_data D:\Zend\Apache2\htdocs\natp_barc\application\third_party\MX\Controller.php 58
ERROR - 2013-08-13 15:45:34 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\Zend\Apache2\htdocs\natp_barc\system\core\Exceptions.php:186) D:\Zend\Apache2\htdocs\natp_barc\system\core\Common.php 548
ERROR - 2013-08-13 15:54:43 --> Severity: Notice  --> Undefined property: CI::$grid D:\Zend\Apache2\htdocs\natp_barc\application\third_party\MX\Controller.php 58
ERROR - 2013-08-13 15:55:58 --> Severity: Notice  --> Undefined property: CI::$grid D:\Zend\Apache2\htdocs\natp_barc\application\third_party\MX\Controller.php 58
ERROR - 2013-08-13 16:40:55 --> 404 Page Not Found --> 
ERROR - 2013-08-13 16:40:55 --> 404 Page Not Found --> 
ERROR - 2013-08-13 16:41:00 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-13 16:41:00 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-13 17:40:49 --> Severity: Notice  --> Undefined variable: trainingProgramType D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Module.php 119
ERROR - 2013-08-13 17:40:49 --> Severity: Notice  --> Undefined variable: status D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Module.php 119
ERROR - 2013-08-13 18:05:31 --> Severity: Notice  --> Undefined property: stdClass::$models D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Module.php 152
ERROR - 2013-08-13 18:05:31 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 353
ERROR - 2013-08-13 18:05:31 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 353
ERROR - 2013-08-13 18:05:31 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 353
ERROR - 2013-08-13 18:05:33 --> Severity: Notice  --> Undefined property: stdClass::$models D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Module.php 152
ERROR - 2013-08-13 18:05:33 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 353
ERROR - 2013-08-13 18:05:33 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 353
ERROR - 2013-08-13 18:05:33 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 353
ERROR - 2013-08-13 18:05:50 --> Severity: Notice  --> Undefined property: stdClass::$models D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Module.php 152
ERROR - 2013-08-13 18:05:50 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 353
ERROR - 2013-08-13 18:05:50 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 353
ERROR - 2013-08-13 18:05:50 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 353
ERROR - 2013-08-13 18:05:51 --> Severity: Notice  --> Undefined property: stdClass::$models D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Module.php 152
ERROR - 2013-08-13 18:05:51 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 353
ERROR - 2013-08-13 18:05:51 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 353
ERROR - 2013-08-13 18:05:51 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 353
ERROR - 2013-08-13 18:11:53 --> Severity: Notice  --> Undefined property: stdClass::$models D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Module.php 150
ERROR - 2013-08-13 18:12:14 --> Severity: Notice  --> Undefined property: stdClass::$models D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Module.php 150
ERROR - 2013-08-13 18:12:14 --> Severity: Notice  --> Undefined property: stdClass::$models D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Module.php 150
ERROR - 2013-08-13 18:13:09 --> Severity: Notice  --> Undefined property: stdClass::$models D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Module.php 150
ERROR - 2013-08-13 18:13:09 --> Severity: Notice  --> Undefined property: stdClass::$models D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Module.php 153
ERROR - 2013-08-13 18:13:09 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 353
ERROR - 2013-08-13 18:13:09 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 353
ERROR - 2013-08-13 18:13:09 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 353
ERROR - 2013-08-13 18:13:41 --> Severity: Notice  --> Undefined property: stdClass::$models D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Module.php 150
ERROR - 2013-08-13 18:13:41 --> Severity: Notice  --> Undefined property: stdClass::$models D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Module.php 153
ERROR - 2013-08-13 18:13:41 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 353
ERROR - 2013-08-13 18:13:41 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 353
ERROR - 2013-08-13 18:13:41 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 353
ERROR - 2013-08-13 18:14:25 --> Severity: Notice  --> Undefined property: stdClass::$models D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Module.php 150
ERROR - 2013-08-13 18:14:25 --> Severity: Notice  --> Undefined property: stdClass::$models D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Module.php 150
ERROR - 2013-08-13 18:21:15 --> Severity: Notice  --> Undefined property: stdClass::$models D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Module.php 154
ERROR - 2013-08-13 18:21:15 --> Severity: Notice  --> Undefined property: stdClass::$models D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Module.php 154
ERROR - 2013-08-13 18:22:33 --> Severity: Notice  --> Undefined property: stdClass::$models D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Module.php 156
ERROR - 2013-08-13 18:22:33 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 353
ERROR - 2013-08-13 18:22:33 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 353
ERROR - 2013-08-13 18:22:33 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 353
ERROR - 2013-08-13 18:22:40 --> Severity: Notice  --> Undefined property: stdClass::$models D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Module.php 156
ERROR - 2013-08-13 18:22:40 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 353
ERROR - 2013-08-13 18:22:40 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 353
ERROR - 2013-08-13 18:22:40 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 353
ERROR - 2013-08-13 18:24:59 --> Severity: Notice  --> Undefined property: stdClass::$models D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Module.php 156
ERROR - 2013-08-13 18:24:59 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 353
ERROR - 2013-08-13 18:24:59 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 353
ERROR - 2013-08-13 18:24:59 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 353
ERROR - 2013-08-13 18:26:24 --> Severity: Notice  --> Undefined property: stdClass::$models D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Module.php 156
ERROR - 2013-08-13 18:26:24 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 353
ERROR - 2013-08-13 18:26:24 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 353
ERROR - 2013-08-13 18:26:24 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 353
ERROR - 2013-08-13 18:27:32 --> Severity: Notice  --> Undefined property: stdClass::$models D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Module.php 156
ERROR - 2013-08-13 18:27:32 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 353
ERROR - 2013-08-13 18:27:32 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 353
ERROR - 2013-08-13 18:27:32 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 353
ERROR - 2013-08-13 18:28:41 --> Severity: Notice  --> Undefined property: stdClass::$models D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Module.php 145
ERROR - 2013-08-13 18:28:41 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 434
ERROR - 2013-08-13 18:28:41 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 434
ERROR - 2013-08-13 18:28:41 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 434
ERROR - 2013-08-13 18:28:41 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 438
ERROR - 2013-08-13 18:28:42 --> Severity: Notice  --> Undefined property: stdClass::$models D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Module.php 145
ERROR - 2013-08-13 18:28:42 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 434
ERROR - 2013-08-13 18:28:42 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 434
ERROR - 2013-08-13 18:28:42 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 434
ERROR - 2013-08-13 18:28:42 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 438
ERROR - 2013-08-13 18:28:42 --> Severity: Notice  --> Undefined property: stdClass::$models D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Module.php 145
ERROR - 2013-08-13 18:28:42 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 434
ERROR - 2013-08-13 18:28:42 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 434
ERROR - 2013-08-13 18:28:42 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 434
ERROR - 2013-08-13 18:28:42 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 438
ERROR - 2013-08-13 18:29:28 --> Severity: Notice  --> Undefined property: stdClass::$models D:\Zend\Apache2\htdocs\natp_barc\application\modules\user\controllers\Module.php 136
ERROR - 2013-08-13 18:29:28 --> Severity: Notice  --> Trying to get property of non-object D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 399
