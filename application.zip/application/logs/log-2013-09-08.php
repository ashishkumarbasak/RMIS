<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-09-08 10:43:20 --> 404 Page Not Found --> 
ERROR - 2013-09-08 10:43:20 --> 404 Page Not Found --> 
ERROR - 2013-09-08 11:33:11 --> Could not find the language line "form_validation_duplicate"
ERROR - 2013-09-08 11:33:11 --> Could not find the language line "form_validation_duplicate"
ERROR - 2013-09-08 11:33:57 --> Could not find the language line "form_validation_duplicate"
ERROR - 2013-09-08 11:33:57 --> Could not find the language line "form_validation_duplicate"
ERROR - 2013-09-08 11:48:07 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 11:48:07 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 11:48:24 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 11:48:24 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 11:50:21 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 11:50:21 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 11:51:52 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 11:51:52 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 11:51:58 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 11:51:58 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 11:52:18 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 11:52:18 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 11:52:26 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 11:52:26 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 11:52:35 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 11:52:35 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 12:55:14 --> Severity: 4096  --> Object of class stdClass could not be converted to string D:\Zend\Apache2\htdocs\natp_barc\application\libraries\MY_Form_validation.php 147
ERROR - 2013-09-08 12:55:14 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 12:55:14 --> Severity: 4096  --> Object of class stdClass could not be converted to string D:\Zend\Apache2\htdocs\natp_barc\application\libraries\MY_Form_validation.php 147
ERROR - 2013-09-08 12:55:14 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 12:55:51 --> Severity: 4096  --> Object of class stdClass could not be converted to string D:\Zend\Apache2\htdocs\natp_barc\application\libraries\MY_Form_validation.php 148
ERROR - 2013-09-08 12:55:51 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 12:55:51 --> Severity: 4096  --> Object of class stdClass could not be converted to string D:\Zend\Apache2\htdocs\natp_barc\application\libraries\MY_Form_validation.php 148
ERROR - 2013-09-08 12:55:51 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 12:58:26 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 12:58:26 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 12:58:31 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 12:58:31 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 13:02:04 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\libraries\MY_Form_validation.php 145
ERROR - 2013-09-08 13:02:04 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 13:02:04 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\libraries\MY_Form_validation.php 145
ERROR - 2013-09-08 13:02:04 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 13:04:02 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\libraries\MY_Form_validation.php 145
ERROR - 2013-09-08 13:04:02 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 13:04:02 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\libraries\MY_Form_validation.php 145
ERROR - 2013-09-08 13:04:02 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 13:04:47 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 13:04:47 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 13:04:57 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 13:04:57 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 13:05:13 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 13:05:13 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 13:05:26 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 13:05:26 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 13:05:29 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 13:05:29 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 13:06:00 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 13:06:00 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 13:06:05 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 13:06:05 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 13:06:07 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 13:06:07 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 13:06:19 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 13:06:19 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 13:06:39 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 13:06:39 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 13:06:54 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 13:06:54 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 13:07:00 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 13:07:00 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 13:07:03 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 13:07:03 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 13:10:30 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 13:10:30 --> Could not find the language line "form_validation_is_duplicate"
ERROR - 2013-09-08 13:22:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'LIMIT 1' at line 6 - Invalid query: SELECT `id`
FROM `pmm_map_salary_scale_heads`
WHERE `salary_grade_id` = 2
AND `salary_head_id` = 4
AND 3 !=
 LIMIT 1
ERROR - 2013-09-08 13:23:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'LIMIT 1' at line 6 - Invalid query: SELECT `id`
FROM `pmm_map_salary_scale_heads`
WHERE `salary_grade_id` = 2
AND `salary_head_id` = 4
AND 3 !=
 LIMIT 1
ERROR - 2013-09-08 13:23:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'LIMIT 1' at line 6 - Invalid query: SELECT `id`
FROM `pmm_map_salary_scale_heads`
WHERE `salary_grade_id` = 2
AND `salary_head_id` = 4
AND 3 !=
 LIMIT 1
ERROR - 2013-09-08 13:24:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'LIMIT 1' at line 6 - Invalid query: SELECT `id`
FROM `pmm_map_salary_scale_heads`
WHERE `salary_grade_id` = 2
AND `salary_head_id` = 4
AND 3 !=
 LIMIT 1
ERROR - 2013-09-08 13:48:46 --> 404 Page Not Found --> 
ERROR - 2013-09-08 13:48:54 --> 404 Page Not Found --> 
ERROR - 2013-09-08 16:50:41 --> 404 Page Not Found --> Pmm/fastivalpolicy
ERROR - 2013-09-08 17:06:26 --> Severity: Warning  --> Creating default object from empty value D:\Zend\Apache2\htdocs\natp_barc\application\modules\pmm\controllers\festivalpolicy.php 110
ERROR - 2013-09-08 17:07:13 --> Severity: Warning  --> json_decode() expects at least 1 parameter, 0 given D:\Zend\Apache2\htdocs\natp_barc\application\modules\pmm\controllers\festivalpolicy.php 109
ERROR - 2013-09-08 17:07:13 --> Severity: Warning  --> Creating default object from empty value D:\Zend\Apache2\htdocs\natp_barc\application\modules\pmm\controllers\festivalpolicy.php 110
ERROR - 2013-09-08 17:07:13 --> Severity: Warning  --> json_decode() expects at least 1 parameter, 0 given D:\Zend\Apache2\htdocs\natp_barc\application\modules\pmm\controllers\festivalpolicy.php 109
ERROR - 2013-09-08 17:07:13 --> Severity: Warning  --> Creating default object from empty value D:\Zend\Apache2\htdocs\natp_barc\application\modules\pmm\controllers\festivalpolicy.php 110
ERROR - 2013-09-08 17:07:29 --> Severity: Warning  --> Creating default object from empty value D:\Zend\Apache2\htdocs\natp_barc\application\modules\pmm\controllers\festivalpolicy.php 110
ERROR - 2013-09-08 17:16:02 --> Severity: Warning  --> Creating default object from empty value D:\Zend\Apache2\htdocs\natp_barc\application\modules\pmm\controllers\festivalpolicy.php 110
ERROR - 2013-09-08 18:44:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'LIMIT 1' at line 6 - Invalid query: SELECT `id`
FROM `salary_head_id`
WHERE `salary_head_id` = 17
AND `effective_date` = '2013-09-08T12:44:04.829Z'
AND `id` !=
 LIMIT 1
ERROR - 2013-09-08 18:45:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'LIMIT 1' at line 6 - Invalid query: SELECT `id`
FROM `salary_head_id`
WHERE `salary_head_id` = 2
AND `effective_date` = '2013-09-02T12:45:34.567Z'
AND `id` !=
 LIMIT 1
ERROR - 2013-09-08 18:49:28 --> Severity: Warning  --> Creating default object from empty value D:\Zend\Apache2\htdocs\natp_barc\application\modules\pmm\controllers\festivalpolicy.php 220
ERROR - 2013-09-08 18:49:28 --> Severity: Warning  --> Creating default object from empty value D:\Zend\Apache2\htdocs\natp_barc\application\modules\pmm\controllers\festivalpolicy.php 224
ERROR - 2013-09-08 18:49:52 --> Severity: Warning  --> Creating default object from empty value D:\Zend\Apache2\htdocs\natp_barc\application\modules\pmm\controllers\festivalpolicy.php 220
ERROR - 2013-09-08 18:49:52 --> Severity: Warning  --> Creating default object from empty value D:\Zend\Apache2\htdocs\natp_barc\application\modules\pmm\controllers\festivalpolicy.php 224
ERROR - 2013-09-08 22:23:34 --> 404 Page Not Found --> 
ERROR - 2013-09-08 22:23:34 --> 404 Page Not Found --> 
ERROR - 2013-09-08 11:40:50 --> 404 Page Not Found --> Festivalpolicy/index
ERROR - 2013-09-08 11:41:12 --> 404 Page Not Found --> Festivalpolicy/index
ERROR - 2013-09-08 11:41:31 --> 404 Page Not Found --> Festivalpolicy/read
ERROR - 2013-09-08 11:42:00 --> 404 Page Not Found --> Festivalpolicy/create
ERROR - 2013-09-08 11:42:13 --> 404 Page Not Found --> Festivalpolicy/create
ERROR - 2013-09-08 13:33:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'LIMIT 1' at line 6 - Invalid query: SELECT `id`
FROM `pmm_festival_policy_info`
WHERE `effective_date` = '2013-02-05T07:32:53.865Z'
AND `salary_head_id` = 2
AND `id` !=
 LIMIT 1
ERROR - 2013-09-08 13:34:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'LIMIT 1' at line 6 - Invalid query: SELECT `id`
FROM `pmm_map_salary_scale_heads`
WHERE `salary_grade_id` = 2
AND `salary_head_id` = 4
AND `id` !=
 LIMIT 1
ERROR - 2013-09-08 15:34:52 --> 404 Page Not Found --> 
ERROR - 2013-09-08 15:51:35 --> Severity: Warning  --> Creating default object from empty value D:\Zend\Apache2\htdocs\natp_barc\application\modules\pmm\controllers\festivalpolicy.php 262
ERROR - 2013-09-08 15:54:10 --> Severity: Warning  --> Creating default object from empty value D:\Zend\Apache2\htdocs\natp_barc\application\modules\pmm\controllers\festivalpolicy.php 262
