<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-09-02 10:38:19 --> 404 Page Not Found --> 
ERROR - 2013-09-02 10:38:19 --> 404 Page Not Found --> 
ERROR - 2013-09-02 10:39:29 --> 404 Page Not Found --> User/assets
ERROR - 2013-09-02 10:39:29 --> 404 Page Not Found --> User/assets
ERROR - 2013-09-02 10:55:53 --> 404 Page Not Found --> User/assets
ERROR - 2013-09-02 10:55:53 --> 404 Page Not Found --> User/assets
ERROR - 2013-09-02 12:13:09 --> 404 Page Not Found --> 
ERROR - 2013-09-02 12:14:32 --> 404 Page Not Found --> 
ERROR - 2013-09-02 12:15:31 --> 404 Page Not Found --> 
ERROR - 2013-09-02 12:30:49 --> 404 Page Not Found --> 
ERROR - 2013-09-02 12:30:51 --> 404 Page Not Found --> 
ERROR - 2013-09-02 12:30:53 --> 404 Page Not Found --> 
ERROR - 2013-09-02 12:30:54 --> 404 Page Not Found --> 
ERROR - 2013-09-02 12:31:16 --> 404 Page Not Found --> 
ERROR - 2013-09-02 12:59:18 --> 404 Page Not Found --> 
ERROR - 2013-09-02 13:01:22 --> 404 Page Not Found --> 
ERROR - 2013-09-02 13:01:43 --> 404 Page Not Found --> 
ERROR - 2013-09-02 13:01:44 --> 404 Page Not Found --> 
ERROR - 2013-09-02 13:02:27 --> 404 Page Not Found --> 
ERROR - 2013-09-02 13:06:21 --> 404 Page Not Found --> 
ERROR - 2013-09-02 13:14:55 --> 404 Page Not Found --> 
ERROR - 2013-09-02 13:14:56 --> 404 Page Not Found --> 
ERROR - 2013-09-02 13:17:34 --> 404 Page Not Found --> 
ERROR - 2013-09-02 13:17:39 --> 404 Page Not Found --> 
ERROR - 2013-09-02 13:19:00 --> 404 Page Not Found --> 
ERROR - 2013-09-02 13:21:36 --> 404 Page Not Found --> 
ERROR - 2013-09-02 13:22:47 --> 404 Page Not Found --> 
ERROR - 2013-09-02 13:26:33 --> 404 Page Not Found --> 
ERROR - 2013-09-02 13:29:54 --> 404 Page Not Found --> 
ERROR - 2013-09-02 13:30:07 --> 404 Page Not Found --> 
ERROR - 2013-09-02 13:30:36 --> 404 Page Not Found --> 
ERROR - 2013-09-02 13:30:42 --> 404 Page Not Found --> 
ERROR - 2013-09-02 13:31:01 --> 404 Page Not Found --> 
ERROR - 2013-09-02 13:31:08 --> 404 Page Not Found --> 
ERROR - 2013-09-02 13:31:23 --> 404 Page Not Found --> 
ERROR - 2013-09-02 13:31:28 --> 404 Page Not Found --> 
ERROR - 2013-09-02 13:31:35 --> 404 Page Not Found --> 
ERROR - 2013-09-02 13:31:51 --> 404 Page Not Found --> 
ERROR - 2013-09-02 13:32:02 --> 404 Page Not Found --> 
ERROR - 2013-09-02 13:32:07 --> 404 Page Not Found --> 
ERROR - 2013-09-02 13:32:19 --> 404 Page Not Found --> 
ERROR - 2013-09-02 13:32:26 --> 404 Page Not Found --> 
ERROR - 2013-09-02 13:35:09 --> 404 Page Not Found --> 
ERROR - 2013-09-02 13:35:47 --> 404 Page Not Found --> 
ERROR - 2013-09-02 13:36:53 --> 404 Page Not Found --> 
ERROR - 2013-09-02 13:36:58 --> 404 Page Not Found --> 
ERROR - 2013-09-02 13:37:54 --> 404 Page Not Found --> 
ERROR - 2013-09-02 13:42:39 --> 404 Page Not Found --> 
ERROR - 2013-09-02 13:43:33 --> 404 Page Not Found --> 
ERROR - 2013-09-02 13:43:37 --> 404 Page Not Found --> Profile/assets
ERROR - 2013-09-02 13:43:37 --> 404 Page Not Found --> Profile/assets
ERROR - 2013-09-02 13:44:12 --> 404 Page Not Found --> 
ERROR - 2013-09-02 13:46:14 --> 404 Page Not Found --> 
ERROR - 2013-09-02 13:46:38 --> 404 Page Not Found --> 
ERROR - 2013-09-02 13:46:50 --> 404 Page Not Found --> 
ERROR - 2013-09-02 13:47:35 --> 404 Page Not Found --> 
ERROR - 2013-09-02 13:48:39 --> 404 Page Not Found --> 
ERROR - 2013-09-02 13:50:08 --> 404 Page Not Found --> 
ERROR - 2013-09-02 13:53:32 --> 404 Page Not Found --> 
ERROR - 2013-09-02 15:32:51 --> 404 Page Not Found --> 
ERROR - 2013-09-02 15:35:45 --> 404 Page Not Found --> 
