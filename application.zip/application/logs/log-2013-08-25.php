<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-08-25 10:10:56 --> 404 Page Not Found --> 
ERROR - 2013-08-25 10:10:59 --> 404 Page Not Found --> 
ERROR - 2013-08-25 10:11:01 --> 404 Page Not Found --> 
ERROR - 2013-08-25 10:20:33 --> 404 Page Not Found --> User/auth
ERROR - 2013-08-25 10:24:23 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-25 10:24:23 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-25 10:24:26 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-25 10:24:26 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-25 10:24:29 --> 404 Page Not Found --> 
ERROR - 2013-08-25 10:24:30 --> 404 Page Not Found --> 
ERROR - 2013-08-25 11:40:59 --> 404 Page Not Found --> 
ERROR - 2013-08-25 11:40:59 --> 404 Page Not Found --> 
ERROR - 2013-08-25 11:41:13 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-25 11:51:23 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-25 11:51:23 --> 404 Page Not Found --> User/assets
ERROR - 2013-08-25 13:04:13 --> 404 Page Not Found --> User/logout
ERROR - 2013-08-25 13:23:02 --> 404 Page Not Found --> User/logout
ERROR - 2013-08-25 13:23:21 --> 404 Page Not Found --> User/logout
ERROR - 2013-08-25 13:24:30 --> 404 Page Not Found --> User/logout
ERROR - 2013-08-25 16:10:50 --> Severity: Warning  --> Illegal offset type in isset or empty D:\Zend\Apache2\htdocs\natp_barc\system\libraries\Session\Session.php 246
ERROR - 2013-08-25 16:10:52 --> Severity: Warning  --> Illegal offset type in isset or empty D:\Zend\Apache2\htdocs\natp_barc\system\libraries\Session\Session.php 246
ERROR - 2013-08-25 16:11:05 --> Severity: Warning  --> Illegal offset type in isset or empty D:\Zend\Apache2\htdocs\natp_barc\system\libraries\Session\Session.php 246
ERROR - 2013-08-25 16:11:07 --> Severity: Warning  --> Illegal offset type in isset or empty D:\Zend\Apache2\htdocs\natp_barc\system\libraries\Session\Session.php 246
