<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-10-07 09:44:49 --> 404 Page Not Found --> 
ERROR - 2013-10-07 09:44:49 --> 404 Page Not Found --> 
ERROR - 2013-10-07 11:35:05 --> 404 Page Not Found --> 
ERROR - 2013-10-07 11:35:06 --> 404 Page Not Found --> 
ERROR - 2013-10-07 11:35:09 --> 404 Page Not Found --> 
ERROR - 2013-10-07 11:35:37 --> 404 Page Not Found --> 
ERROR - 2013-10-07 11:49:10 --> 404 Page Not Found --> 
ERROR - 2013-10-07 11:49:33 --> 404 Page Not Found --> 
ERROR - 2013-10-07 11:57:13 --> 404 Page Not Found --> 
ERROR - 2013-10-07 17:31:53 --> Severity: Warning  --> trim() expects parameter 1 to be string, object given D:\Zend\Apache2\htdocs\natp_barc\system\libraries\Form_validation.php 718
ERROR - 2013-10-07 17:31:53 --> Severity: 4096  --> Object of class stdClass could not be converted to string D:\Zend\Apache2\htdocs\natp_barc\application\models\kendodatasource_model.php 499
