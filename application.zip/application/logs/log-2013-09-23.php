<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-09-23 10:34:08 --> 404 Page Not Found --> 
ERROR - 2013-09-23 10:34:08 --> 404 Page Not Found --> 
