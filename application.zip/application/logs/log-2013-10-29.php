<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-10-29 09:57:26 --> 404 Page Not Found --> 
ERROR - 2013-10-29 09:57:27 --> 404 Page Not Found --> 
ERROR - 2013-10-29 16:11:38 --> Severity: Warning  --> require_once(http://localhost:8088/JavaBridge/java/Java.inc): failed to open stream: No connection could be made because the target machine actively refused it.
 D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\controllers\Rptvehicle.php 34
ERROR - 2013-10-29 16:12:10 --> 404 Page Not Found --> Vmis/nullpx
ERROR - 2013-10-29 16:12:10 --> 404 Page Not Found --> Vmis/nullimg_0_0_0
ERROR - 2013-10-29 16:46:25 --> 404 Page Not Found --> 
ERROR - 2013-10-29 16:46:32 --> 404 Page Not Found --> 
ERROR - 2013-10-29 16:46:32 --> 404 Page Not Found --> 
ERROR - 2013-10-29 17:07:21 --> 404 Page Not Found --> Vmis/nullpx
ERROR - 2013-10-29 17:07:21 --> 404 Page Not Found --> Vmis/nullimg_0_0_0
ERROR - 2013-10-29 17:20:46 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\report\vehicle_info.php 27
ERROR - 2013-10-29 17:20:46 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\report\vehicle_info.php 42
ERROR - 2013-10-29 17:20:46 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\report\vehicle_info.php 59
ERROR - 2013-10-29 17:20:46 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\report\vehicle_info.php 76
ERROR - 2013-10-29 17:21:40 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\report\vehicle_info.php 27
ERROR - 2013-10-29 17:21:40 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\report\vehicle_info.php 42
ERROR - 2013-10-29 17:21:40 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\report\vehicle_info.php 59
ERROR - 2013-10-29 17:21:40 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\report\vehicle_info.php 76
ERROR - 2013-10-29 17:23:14 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-29 17:23:14 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-29 17:23:14 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-29 17:23:14 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-29 17:23:14 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-29 17:23:14 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-29 17:23:14 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-29 17:23:14 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-29 17:23:14 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-29 17:26:45 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\report\vehicle_info.php 27
ERROR - 2013-10-29 17:26:45 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\report\vehicle_info.php 42
ERROR - 2013-10-29 17:26:45 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\report\vehicle_info.php 59
ERROR - 2013-10-29 17:28:19 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\report\vehicle_info.php 27
ERROR - 2013-10-29 17:28:19 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\report\vehicle_info.php 42
ERROR - 2013-10-29 17:28:19 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\report\vehicle_info.php 59
ERROR - 2013-10-29 17:28:19 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\report\vehicle_info.php 76
ERROR - 2013-10-29 17:32:22 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\report\maintenance.php 60
ERROR - 2013-10-29 17:34:09 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\report\vehicle_info.php 27
ERROR - 2013-10-29 17:34:09 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\report\vehicle_info.php 42
ERROR - 2013-10-29 17:34:09 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\report\vehicle_info.php 59
ERROR - 2013-10-29 17:34:09 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\report\vehicle_info.php 76
ERROR - 2013-10-29 17:34:31 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\report\vehicle_info.php 27
ERROR - 2013-10-29 17:34:31 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\report\vehicle_info.php 42
ERROR - 2013-10-29 17:34:31 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\report\vehicle_info.php 59
ERROR - 2013-10-29 17:34:31 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\report\vehicle_info.php 76
ERROR - 2013-10-29 17:35:28 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-29 17:35:28 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-29 17:35:28 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-29 17:35:28 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-29 17:35:28 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-29 17:35:28 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-29 17:35:28 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-29 17:35:28 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-29 17:35:28 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-29 17:39:16 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\report\vehicle_bill.php 44
ERROR - 2013-10-29 17:40:26 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\report\vehicle_bill.php 49
ERROR - 2013-10-29 17:41:14 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\report\vehicle_bill.php 49
ERROR - 2013-10-29 18:04:47 --> 404 Page Not Found --> Vmis/nullimg_0_0_0
ERROR - 2013-10-29 18:04:47 --> 404 Page Not Found --> Vmis/nullpx
ERROR - 2013-10-29 18:10:31 --> 404 Page Not Found --> Vmis/nullpx
ERROR - 2013-10-29 18:10:31 --> 404 Page Not Found --> Vmis/nullimg_0_0_0
ERROR - 2013-10-29 19:09:28 --> 404 Page Not Found --> Vmis/nullpx
ERROR - 2013-10-29 19:09:28 --> 404 Page Not Found --> Vmis/nullimg_0_0_0
ERROR - 2013-10-29 19:10:35 --> 404 Page Not Found --> Vmis/nullimg_0_0_0
ERROR - 2013-10-29 19:10:35 --> 404 Page Not Found --> Vmis/nullpx
ERROR - 2013-10-29 19:30:46 --> 404 Page Not Found --> Vmis/nullimg_0_0_0
ERROR - 2013-10-29 19:30:46 --> 404 Page Not Found --> Vmis/nullpx
ERROR - 2013-10-29 19:32:41 --> 404 Page Not Found --> Vmis/nullpx
ERROR - 2013-10-29 19:32:41 --> 404 Page Not Found --> Vmis/nullimg_0_0_0
