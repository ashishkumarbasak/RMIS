<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-09-15 10:08:46 --> 404 Page Not Found --> 
ERROR - 2013-09-15 10:08:47 --> 404 Page Not Found --> 
ERROR - 2013-09-15 11:03:57 --> 404 Page Not Found --> Salaryscalefixation/index
ERROR - 2013-09-15 11:15:15 --> 404 Page Not Found --> 
ERROR - 2013-09-15 11:15:18 --> 404 Page Not Found --> 
ERROR - 2013-09-15 11:40:37 --> 404 Page Not Found --> 
ERROR - 2013-09-15 11:52:34 --> 404 Page Not Found --> 
ERROR - 2013-09-15 12:09:00 --> 404 Page Not Found --> 
ERROR - 2013-09-15 12:09:08 --> 404 Page Not Found --> 
ERROR - 2013-09-15 12:16:44 --> 404 Page Not Found --> 
ERROR - 2013-09-15 12:18:10 --> 404 Page Not Found --> 
ERROR - 2013-09-15 12:43:13 --> 404 Page Not Found --> 
ERROR - 2013-09-15 12:56:15 --> 404 Page Not Found --> 
ERROR - 2013-09-15 12:56:30 --> 404 Page Not Found --> 
ERROR - 2013-09-15 13:13:37 --> 404 Page Not Found --> 
ERROR - 2013-09-15 13:13:40 --> 404 Page Not Found --> 
ERROR - 2013-09-15 13:14:43 --> 404 Page Not Found --> 
ERROR - 2013-09-15 13:16:50 --> 404 Page Not Found --> 
ERROR - 2013-09-15 13:45:19 --> 404 Page Not Found --> Salaryscalefixation/index
ERROR - 2013-09-15 13:45:23 --> 404 Page Not Found --> Salaryscalefixation/index
ERROR - 2013-09-15 14:05:31 --> 404 Page Not Found --> Salaryscalefixation/index
ERROR - 2013-09-15 16:53:47 --> Query error: Duplicate entry '0-1' for key 'PRIMARY' - Invalid query: INSERT INTO `pmm_charge_allowance` (`organization_id`, `salary_head_id`, `employee_id`, `name_of_additional_charge`, `start_date`, `end_date`, `amount_of_charge_allowance`, `created_at`, `created_by`) VALUES (1, '1', '21', 'sas', '2013-09-03', '2013-09-11', '212', '2013-09-15 16:53:47', '2')
ERROR - 2013-09-15 16:54:23 --> Severity: 4096  --> Argument 1 passed to Illuminate\Database\Connection::__construct() must be an instance of PDO, instance of Template given, called in D:\Zend\Apache2\htdocs\natp_barc\vendor\cartalyst\sentry\src\Cartalyst\Sentry\Facades\ConnectionResolver.php on line 117 and defined D:\Zend\Apache2\htdocs\natp_barc\vendor\illuminate\database\Illuminate\Database\Connection.php 118
ERROR - 2013-09-15 18:01:24 --> 404 Page Not Found --> Salaryscalefixation/index
