<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-10-30 09:54:20 --> 404 Page Not Found --> 
ERROR - 2013-10-30 09:54:20 --> 404 Page Not Found --> 
ERROR - 2013-10-30 09:57:39 --> Severity: Warning  --> require_once(http://localhost:8088/JavaBridge/java/Java.inc): failed to open stream: No connection could be made because the target machine actively refused it.
 D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\controllers\Rptvehicle.php 51
ERROR - 2013-10-30 10:23:01 --> 404 Page Not Found --> Vmis/nullpx
ERROR - 2013-10-30 10:23:01 --> 404 Page Not Found --> Vmis/nullimg_0_0_0
ERROR - 2013-10-30 11:17:26 --> 404 Page Not Found --> Vmis/nullpx
ERROR - 2013-10-30 11:17:26 --> 404 Page Not Found --> Vmis/nullimg_0_0_0
ERROR - 2013-10-30 11:40:19 --> 404 Page Not Found --> Vmis/nullpx
ERROR - 2013-10-30 11:40:19 --> 404 Page Not Found --> Vmis/nullimg_0_0_0
ERROR - 2013-10-30 12:34:25 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-30 12:34:25 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-30 12:34:25 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-30 12:34:25 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-30 12:34:25 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-30 12:34:25 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-30 12:34:25 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-30 12:34:25 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-30 12:34:25 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-30 12:51:37 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-30 12:51:37 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-30 12:51:37 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-30 12:51:37 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-30 12:51:37 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-30 12:51:37 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-30 12:51:37 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-30 12:51:37 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-30 12:51:37 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-30 12:54:07 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-30 12:54:07 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-30 12:54:07 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-30 12:54:07 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-30 12:54:07 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-30 12:54:07 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-30 12:54:07 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-30 12:54:07 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-30 12:54:07 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-10-30 12:54:29 --> 404 Page Not Found --> Vmis/Reports
ERROR - 2013-10-30 17:04:58 --> 404 Page Not Found --> User/assets
ERROR - 2013-10-30 17:04:58 --> 404 Page Not Found --> User/assets
ERROR - 2013-10-30 17:55:14 --> 404 Page Not Found --> Profile/assets
ERROR - 2013-10-30 17:55:14 --> 404 Page Not Found --> Profile/assets
