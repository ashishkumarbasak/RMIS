<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-11-12 10:24:49 --> 404 Page Not Found --> 
ERROR - 2013-11-12 10:24:49 --> 404 Page Not Found --> 
ERROR - 2013-11-12 10:37:05 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-12 10:37:05 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-12 10:37:05 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-12 10:37:05 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-12 10:37:05 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-12 10:37:05 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-12 10:37:05 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-12 10:37:05 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-12 10:37:05 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-12 10:47:17 --> 404 Page Not Found --> User/assets
ERROR - 2013-11-12 10:47:17 --> 404 Page Not Found --> User/assets
ERROR - 2013-11-12 12:27:10 --> 404 Page Not Found --> 
ERROR - 2013-11-12 13:09:41 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-12 13:09:41 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-12 13:09:41 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-12 13:09:41 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-12 13:09:41 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-12 13:09:41 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-12 13:09:41 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-12 13:09:41 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-12 13:09:41 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given D:\Zend\Apache2\htdocs\natp_barc\application\modules\Vmis\views\transaction\application_form.php 218
ERROR - 2013-11-12 14:51:05 --> 404 Page Not Found --> 
