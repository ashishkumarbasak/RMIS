<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-10-06 10:17:26 --> 404 Page Not Found --> 
ERROR - 2013-10-06 10:17:26 --> 404 Page Not Found --> 
ERROR - 2013-10-06 11:06:23 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\helpers\general_helper.php 132
ERROR - 2013-10-06 11:06:23 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\helpers\general_helper.php 132
ERROR - 2013-10-06 11:06:23 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\helpers\general_helper.php 132
ERROR - 2013-10-06 11:06:24 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\Zend\Apache2\htdocs\natp_barc\application\helpers\general_helper.php 132
ERROR - 2013-10-06 11:36:43 --> Severity: Warning  --> Missing argument 1 for Process_Model::getAllEmployeeForSalaryProcess(), called in D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Processalary.php on line 93 and defined D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\models\process_model.php 59
ERROR - 2013-10-06 11:41:22 --> Query error: Column 'designation_id' cannot be null - Invalid query: INSERT INTO `pmm_earnings_deduction_for_group` (`organization_id`, `salary_head_id`, `start_date`, `end_date`, `designation_id`, `employee_category_id`, `employee_type_id`, `employee_class_id`, `grade_from_id`, `grade_to_id`, `amount`, `no_of_days_for_basic_deduction`, `remarks`, `created_at`, `created_by`) VALUES (1, '11', '2012-08-07', '2013-12-07', NULL, NULL, NULL, NULL, '1', '3', '3000', '', '', '2013-10-06 11:41:22', '2')
ERROR - 2013-10-06 11:41:25 --> Query error: Column 'designation_id' cannot be null - Invalid query: INSERT INTO `pmm_earnings_deduction_for_group` (`organization_id`, `salary_head_id`, `start_date`, `end_date`, `designation_id`, `employee_category_id`, `employee_type_id`, `employee_class_id`, `grade_from_id`, `grade_to_id`, `amount`, `no_of_days_for_basic_deduction`, `remarks`, `created_at`, `created_by`) VALUES (1, '11', '2012-08-07', '2013-12-07', NULL, NULL, NULL, NULL, '1', '3', '3000', '', '', '2013-10-06 11:41:25', '2')
ERROR - 2013-10-06 11:41:33 --> Query error: Column 'designation_id' cannot be null - Invalid query: INSERT INTO `pmm_earnings_deduction_for_group` (`organization_id`, `salary_head_id`, `start_date`, `end_date`, `designation_id`, `employee_category_id`, `employee_type_id`, `employee_class_id`, `grade_from_id`, `grade_to_id`, `amount`, `no_of_days_for_basic_deduction`, `remarks`, `created_at`, `created_by`) VALUES (1, '11', '2012-08-07', '2013-12-07', NULL, NULL, NULL, NULL, '1', '3', '3000', '', '', '2013-10-06 11:41:33', '2')
ERROR - 2013-10-06 18:51:11 --> 404 Page Not Found --> 
ERROR - 2013-10-06 18:51:16 --> 404 Page Not Found --> 
ERROR - 2013-10-06 19:06:09 --> 404 Page Not Found --> 
ERROR - 2013-10-06 19:06:15 --> 404 Page Not Found --> 
ERROR - 2013-10-06 19:06:43 --> 404 Page Not Found --> 
ERROR - 2013-10-06 19:06:54 --> 404 Page Not Found --> 
