<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-11-13 09:48:59 --> 404 Page Not Found --> 
ERROR - 2013-11-13 09:48:59 --> 404 Page Not Found --> 
ERROR - 2013-11-13 10:44:38 --> 404 Page Not Found --> User/assets
ERROR - 2013-11-13 10:44:38 --> 404 Page Not Found --> User/assets
ERROR - 2013-11-13 13:14:18 --> Query error: Table 'natp_barc.mytable' doesn't exist - Invalid query: DELETE FROM `mytable`
WHERE `id` = 1
ERROR - 2013-11-13 13:14:38 --> Severity: 4096  --> Argument 1 passed to Illuminate\Database\Connection::__construct() must be an instance of PDO, instance of Template given, called in D:\Zend\Apache2\htdocs\natp_barc\vendor\cartalyst\sentry\src\Cartalyst\Sentry\Facades\ConnectionResolver.php on line 117 and defined D:\Zend\Apache2\htdocs\natp_barc\vendor\illuminate\database\Illuminate\Database\Connection.php 118
ERROR - 2013-11-13 13:15:17 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`natp_barc`.`pmm_house_maintance_policy`, CONSTRAINT `FK_pmm_house_maintance_policy` FOREIGN KEY (`salary_head_id`) REFERENCES `pmm_salary_head` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE) - Invalid query: DELETE FROM `pmm_salary_head`
WHERE `id` = 1
ERROR - 2013-11-13 13:15:25 --> Severity: 4096  --> Argument 1 passed to Illuminate\Database\Connection::__construct() must be an instance of PDO, instance of Template given, called in D:\Zend\Apache2\htdocs\natp_barc\vendor\cartalyst\sentry\src\Cartalyst\Sentry\Facades\ConnectionResolver.php on line 117 and defined D:\Zend\Apache2\htdocs\natp_barc\vendor\illuminate\database\Illuminate\Database\Connection.php 118
ERROR - 2013-11-13 13:16:42 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`natp_barc`.`pmm_house_maintance_policy`, CONSTRAINT `FK_pmm_house_maintance_policy` FOREIGN KEY (`salary_head_id`) REFERENCES `pmm_salary_head` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE) - Invalid query: DELETE FROM `pmm_salary_head`
WHERE `id` = 1
ERROR - 2013-11-13 13:16:46 --> Severity: 4096  --> Argument 1 passed to Illuminate\Database\Connection::__construct() must be an instance of PDO, instance of Template given, called in D:\Zend\Apache2\htdocs\natp_barc\vendor\cartalyst\sentry\src\Cartalyst\Sentry\Facades\ConnectionResolver.php on line 117 and defined D:\Zend\Apache2\htdocs\natp_barc\vendor\illuminate\database\Illuminate\Database\Connection.php 118
ERROR - 2013-11-13 13:17:22 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`natp_barc`.`pmm_house_maintance_policy`, CONSTRAINT `FK_pmm_house_maintance_policy` FOREIGN KEY (`salary_head_id`) REFERENCES `pmm_salary_head` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE) - Invalid query: DELETE FROM `pmm_salary_head`
WHERE `id` = 1
ERROR - 2013-11-13 13:17:30 --> Severity: 4096  --> Argument 1 passed to Illuminate\Database\Connection::__construct() must be an instance of PDO, instance of Template given, called in D:\Zend\Apache2\htdocs\natp_barc\vendor\cartalyst\sentry\src\Cartalyst\Sentry\Facades\ConnectionResolver.php on line 117 and defined D:\Zend\Apache2\htdocs\natp_barc\vendor\illuminate\database\Illuminate\Database\Connection.php 118
ERROR - 2013-11-13 13:26:14 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`natp_barc`.`pmm_house_maintance_policy`, CONSTRAINT `FK_pmm_house_maintance_policy` FOREIGN KEY (`salary_head_id`) REFERENCES `pmm_salary_head` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE) - Invalid query: DELETE FROM `pmm_salary_head`
WHERE `id` = 1
ERROR - 2013-11-13 13:26:22 --> Severity: 4096  --> Argument 1 passed to Illuminate\Database\Connection::__construct() must be an instance of PDO, instance of Template given, called in D:\Zend\Apache2\htdocs\natp_barc\vendor\cartalyst\sentry\src\Cartalyst\Sentry\Facades\ConnectionResolver.php on line 117 and defined D:\Zend\Apache2\htdocs\natp_barc\vendor\illuminate\database\Illuminate\Database\Connection.php 118
