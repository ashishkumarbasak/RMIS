<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-10-31 10:27:59 --> 404 Page Not Found --> 
ERROR - 2013-10-31 10:27:59 --> 404 Page Not Found --> 
ERROR - 2013-10-31 10:35:00 --> Severity: Warning  --> require_once(http://localhost:8088/JavaBridge/java/Java.inc): failed to open stream: No connection could be made because the target machine actively refused it.
 D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Rptsalarysheet.php 41
ERROR - 2013-10-31 13:07:16 --> 404 Page Not Found --> User/assets
ERROR - 2013-10-31 13:07:16 --> 404 Page Not Found --> User/assets
ERROR - 2013-10-31 16:08:50 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-31 16:08:50 --> 404 Page Not Found --> Pmm/nullimg_0_0_0
ERROR - 2013-10-31 18:04:57 --> 404 Page Not Found --> Pmm/nullpx
ERROR - 2013-10-31 18:04:57 --> 404 Page Not Found --> Pmm/nullimg_0_0_0
