<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2013-11-14 10:07:06 --> 404 Page Not Found --> 
ERROR - 2013-11-14 10:07:06 --> 404 Page Not Found --> 
ERROR - 2013-11-14 10:07:22 --> 404 Page Not Found --> User/assets
ERROR - 2013-11-14 10:07:22 --> 404 Page Not Found --> User/assets
ERROR - 2013-11-14 15:34:43 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`natp_barc`.`pmm_salary_details`, CONSTRAINT `FK_pmm_salary_details` FOREIGN KEY (`salary_info_id`) REFERENCES `pmm_salary_info` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE) - Invalid query: DELETE FROM `pmm_salary_info`
WHERE `salary_process_id` = '20'
ERROR - 2013-11-14 15:36:05 --> Severity: 4096  --> Argument 1 passed to Illuminate\Database\Connection::__construct() must be an instance of PDO, instance of Template given, called in D:\Zend\Apache2\htdocs\natp_barc\vendor\cartalyst\sentry\src\Cartalyst\Sentry\Facades\ConnectionResolver.php on line 117 and defined D:\Zend\Apache2\htdocs\natp_barc\vendor\illuminate\database\Illuminate\Database\Connection.php 118
ERROR - 2013-11-14 15:41:47 --> Severity: Warning  --> require_once(http://localhost:8088/JavaBridge/java/Java.inc): failed to open stream: No connection could be made because the target machine actively refused it.
 D:\Zend\Apache2\htdocs\natp_barc\application\modules\Pmm\controllers\Rptsalarysheet.php 41
