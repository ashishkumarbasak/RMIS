<?php

namespace Kendo\Data;

class HierarchicalDataSource extends \Kendo\Data\DataSource {
//>> Properties
//<< Properties
}

?>
