<!-- content-body -->
<div class="content-body">    
    <div class="row-fluid">
        <?php echo $template['partials']['divInfoForm']; ?>
        <div style="margin:15px;">
        	<div class="row-fluid">
           		<?php //echo $grid_data; ?>
           		<div id="result"></div>
        	</div>
       	</div>
    </div> 
</div><!--/content-body -->
<div style="height:10px;"></div>
<script id="popup_editor" type="text/x-kendo-template">
</script>