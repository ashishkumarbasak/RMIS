<div id="breadcrumbs">
        <ul class="breadcrumb">
                <li>
                        <i class="icon-home"></i>
                        <a href="<?php echo site_url('Rmis');?>">RMIS</a>

                        <span class="divider">
                                <i class="icon-angle-right"></i>
                        </span>
                </li>
                <li class="active"><?php echo $breadcrumb; ?></li>
        </ul><!--.breadcrumb-->


</div>

    