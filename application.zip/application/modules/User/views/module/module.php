<div class="container">
  <div class="row">
    <div class="span12">
      <hr>
      <h4>MANAGE MODULE</h4>
      <br/>
      <?php echo $grid_data; ?> <br/>
    </div>
  </div>
  <!-- /row --> 
</div>
<!-- /container --> 
