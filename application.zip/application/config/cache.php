<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

$config['cache_dir'] = APPPATH.'cache/';

$config['cache_default_expires'] = 0;

