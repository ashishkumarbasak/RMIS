<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
* Name:  Minify
*
* Author: Slawomir Jasinski
*		  slav123@gmail.com
*         @slavomirj
*
* Location: http://www.spidersoft.com.au/projects/codeigniter-minify/
*
* Created:  07.02.2011
*
* Description:
*
*/

$config['assets_dir'] = 'assets';
$config['css_dir'] = 'assets/css';
$config['js_dir'] = '/js';

/* End of file minify.php */
/* Location: ./application/config/minify.php */
